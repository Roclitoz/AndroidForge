# HAZE MAPPER 0.1.7 — Global Keyboard Capture Lab

## Preserved from 0.1.6
- WASD keyboard-to-analog state handling, including normalized diagonals and release-to-center.
- Touch-operated analog pad and configurable HUD key bindings.
- Shizuku UserService diagnostics and safe uinput visibility/permission probe.

## New in 0.1.7
- Added an opt-in Android AccessibilityService requesting physical key-event filtering.
- Added a Global Keyboard Capture screen with a shortcut to Android Accessibility Settings.
- Records last physical key, DOWN/UP action, device ID, timestamp and event count in local preferences.
- The service deliberately returns `false` from `onKeyEvent`: it observes but does not consume or remap input. This allows a first validation pass while Free Fire remains in control of the keys.

## Test procedure
1. Install the debug APK built from this source.
2. Open HAZE MAPPER > Captura global de teclado.
3. Open Android Accessibility Settings and enable "HAZE MAPPER • Captura de teclado".
4. Return to HAZE and verify that the service is enabled.
5. Open Free Fire, press WASD on the physical keyboard, return to HAZE and tap "Atualizar diagnóstico".
6. Confirm that the event count and last key changed. Since events are observed only, Free Fire should still receive the original key events.

## Important limitations
- This is a global keyboard observation milestone, not a completed game mapper.
- No global mouse-motion capture, cursor overlay, camera-look injection, or persistent multitouch injection is implemented yet.
- The analog implementation from 0.1.6 is retained and still operates inside HAZE while the activity has focus.
- uinput access must be verified on the target firmware before selecting a native multitouch backend.
- Accessibility permission is sensitive and must be explicitly enabled by the user in Android Settings. The service does not read screen contents, retrieve window content, or send data off-device.

## Build
Open in AndroidForge / Android Studio and run `assembleDebug`. This source package has not been compiled in this environment.
