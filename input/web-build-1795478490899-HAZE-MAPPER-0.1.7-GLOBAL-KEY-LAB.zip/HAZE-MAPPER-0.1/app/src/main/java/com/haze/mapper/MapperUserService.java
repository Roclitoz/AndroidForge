package com.haze.mapper;

import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.util.Log;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

/** Shizuku UserService Binder. Uses a tiny explicit Binder protocol to avoid AIDL generation issues. */
public final class MapperUserService extends Binder {
    private static final String TAG = "HazeMapperService";
    public static final String DESCRIPTOR = "com.haze.mapper.IMapperService";
    public static final int TRANSACTION_DIAGNOSTIC = IBinder.FIRST_CALL_TRANSACTION;
    public static final int TRANSACTION_LIST_DEVICES = IBinder.FIRST_CALL_TRANSACTION + 1;
    public static final int TRANSACTION_TAP = IBinder.FIRST_CALL_TRANSACTION + 2;
    public static final int TRANSACTION_SWIPE = IBinder.FIRST_CALL_TRANSACTION + 3;
    public static final int TRANSACTION_PROBE_UINPUT = IBinder.FIRST_CALL_TRANSACTION + 4;
    // Shizuku UserService reserved destroy transaction (AIDL equivalent: 16777114).
    public static final int TRANSACTION_DESTROY = 16777114;

    public MapperUserService() { attachInterface(null, DESCRIPTOR); }

    private String command(String... args) {
        Process process = null;
        try {
            process = new ProcessBuilder(args).redirectErrorStream(true).start();
            StringBuilder out = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (out.length() < 12000) out.append(line).append('\n');
                }
            }
            if (!process.waitFor(8, TimeUnit.SECONDS)) {
                process.destroyForcibly();
                return "TIMEOUT: " + String.join(" ", args);
            }
            String result = out.toString().trim();
            return result.isEmpty() ? "Comando executado (sem saída). exit=" + process.exitValue() : result;
        } catch (Exception e) {
            Log.e(TAG, "Command failed", e);
            return "ERRO: " + e.getClass().getSimpleName() + ": " + e.getMessage();
        } finally {
            if (process != null) process.destroy();
        }
    }

    private String diagnostic() {
        return "HAZE MAPPER • SHIZUKU USER SERVICE\n" + command("id")
                + "\n\nAndroid:\n" + command("getprop", "ro.build.version.release")
                + "\nAPI:\n" + command("getprop", "ro.build.version.sdk")
                + "\n\nDisplay size:\n" + command("wm", "size")
                + "\nDensity:\n" + command("wm", "density")
                + "\n\nInput devices:\n" + command("getevent", "-lp");
    }

    @Override protected boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
        if (code == INTERFACE_TRANSACTION) {
            reply.writeString(DESCRIPTOR);
            return true;
        }
        if (code == TRANSACTION_DESTROY) {
            new Thread(() -> { try { Thread.sleep(100); } catch (InterruptedException ignored) {} System.exit(0); }).start();
            return true;
        }
        data.enforceInterface(DESCRIPTOR);
        String result;
        switch (code) {
            case TRANSACTION_DIAGNOSTIC:
                result = diagnostic();
                break;
            case TRANSACTION_LIST_DEVICES:
                result = command("getevent", "-lp");
                break;
            case TRANSACTION_TAP: {
                int x = data.readInt();
                int y = data.readInt();
                if (x < 0 || y < 0) result = "Coordenadas inválidas.";
                else result = command("input", "tap", String.valueOf(x), String.valueOf(y));
                break;
            }
            case TRANSACTION_SWIPE: {
                int x1 = data.readInt(), y1 = data.readInt(), x2 = data.readInt(), y2 = data.readInt();
                int duration = Math.max(1, Math.min(data.readInt(), 5000));
                if (x1 < 0 || y1 < 0 || x2 < 0 || y2 < 0) result = "Coordenadas inválidas.";
                else result = command("input", "swipe", String.valueOf(x1), String.valueOf(y1),
                        String.valueOf(x2), String.valueOf(y2), String.valueOf(duration));
                break;
            }
            case TRANSACTION_PROBE_UINPUT:
                result = "UINPUT PROBE (sem criar dispositivo ou alterar entradas):\n"
                        + command("sh", "-c", "id; ls -l /dev/uinput /dev/input/uinput 2>&1; "
                        + "if [ -r /dev/uinput ]; then echo READABLE=yes; else echo READABLE=no; fi; "
                        + "if [ -w /dev/uinput ]; then echo WRITABLE=yes; else echo WRITABLE=no; fi; "
                        + "ls -l /dev/input 2>&1");
                break;
            default:
                return super.onTransact(code, data, reply, flags);
        }
        reply.writeNoException();
        reply.writeString(result);
        return true;
    }
}
