package com.haze.mapper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

/**
 * Opt-in global physical-key observer. It deliberately returns false so keys
 * continue to the foreground app/game during this validation milestone.
 */
public final class GlobalKeyCaptureService extends AccessibilityService {
    private static final String PREFS = "haze_global_input";

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = getServiceInfo();
        if (info != null) {
            info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
            setServiceInfo(info);
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("service_connected", true)
                .putLong("connected_at", System.currentTimeMillis())
                .apply();
    }

    @Override protected boolean onKeyEvent(KeyEvent event) {
        if (event == null) return false;
        if (event.getAction() != KeyEvent.ACTION_DOWN && event.getAction() != KeyEvent.ACTION_UP) return false;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt("last_keycode", event.getKeyCode())
                .putInt("last_action", event.getAction())
                .putInt("last_device", event.getDeviceId())
                .putLong("last_event_at", System.currentTimeMillis())
                .putInt("event_count", getSharedPreferences(PREFS, MODE_PRIVATE).getInt("event_count", 0) + 1)
                .apply();
        // Observation only: never consume or remap input in this milestone.
        return false;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }

    @Override public boolean onUnbind(android.content.Intent intent) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("service_connected", false).apply();
        return super.onUnbind(intent);
    }
}
