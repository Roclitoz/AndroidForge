package com.haze.mapper;

import android.view.KeyEvent;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/** First mapping core: physical key -> normalized screen coordinate. */
public final class MappingEngine {
    public static final class Binding {
        public final int keyCode;
        public final float xRatio;
        public final float yRatio;
        public Binding(int keyCode, float xRatio, float yRatio) {
            this.keyCode = keyCode;
            this.xRatio = clamp(xRatio);
            this.yRatio = clamp(yRatio);
        }
        private static float clamp(float value) { return Math.max(0f, Math.min(1f, value)); }
    }

    private final Map<Integer, Binding> bindings = new HashMap<>();
    public MappingEngine() {
        // Safe demo bindings; coordinates are normalized and must be calibrated per game/HUD.
        bind(KeyEvent.KEYCODE_SPACE, 0.88f, 0.82f);
        bind(KeyEvent.KEYCODE_R, 0.92f, 0.18f);
        bind(KeyEvent.KEYCODE_F, 0.78f, 0.72f);
    }
    public synchronized void bind(int keyCode, float xRatio, float yRatio) {
        bindings.put(keyCode, new Binding(keyCode, xRatio, yRatio));
    }
    public synchronized Binding find(int keyCode) { return bindings.get(keyCode); }
    public synchronized Map<Integer, Binding> snapshot() {
        return Collections.unmodifiableMap(new HashMap<>(bindings));
    }
    public synchronized void remove(int keyCode) { bindings.remove(keyCode); }
    public static int toPixel(float ratio, int dimension) {
        return Math.max(0, Math.min(Math.round(ratio * dimension), Math.max(0, dimension - 1)));
    }
}
