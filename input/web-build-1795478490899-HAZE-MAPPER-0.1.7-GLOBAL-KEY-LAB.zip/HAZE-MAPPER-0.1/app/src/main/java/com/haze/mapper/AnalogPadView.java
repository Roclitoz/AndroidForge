package com.haze.mapper;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/** Local analog-axis calibration surface. Emits normalized axes and returns to center on release. */
public final class AnalogPadView extends View {
    public interface Listener { void onAxis(float x, float y, float magnitude); }
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Listener listener;
    private float cx, cy, baseRadius, knobX, knobY;
    private boolean active;
    private float axisX, axisY, magnitude;
    private static final float DEADZONE = .12f;
    public AnalogPadView(Context context, Listener listener) { super(context); this.listener = listener; setFocusable(true); }
    @Override protected void onDraw(Canvas c) {
        super.onDraw(c); c.drawColor(0xFF171923);
        cx=getWidth()/2f; cy=getHeight()/2f; baseRadius=Math.max(50,Math.min(getWidth(),getHeight())*.34f);
        if(!active){knobX=cx + axisX*baseRadius;knobY=cy - axisY*baseRadius;}
        p.setStyle(Paint.Style.FILL); p.setColor(0xFF263149); c.drawCircle(cx,cy,baseRadius,p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(0xFF64748B); c.drawCircle(cx,cy,baseRadius,p);
        p.setColor(0xFF8B5CF6); p.setStrokeWidth(2); c.drawCircle(cx,cy,baseRadius*DEADZONE,p);
        p.setStyle(Paint.Style.FILL); p.setColor(active?0xFFB69AFF:0xFF718096); c.drawCircle(knobX,knobY,baseRadius*.28f,p);
        p.setColor(0xFFCFD6E5); p.setTextSize(14); p.setTextAlign(Paint.Align.CENTER); c.drawText("ANALÓGICO • ARRASTE",cx,Math.max(28,cy-baseRadius-24),p);
    }
    @Override public boolean onTouchEvent(MotionEvent e) {
        if(e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE) {
            active=true; float dx=e.getX()-cx, dy=e.getY()-cy; float len=(float)Math.hypot(dx,dy); float scale=len>baseRadius?baseRadius/len:1f;
            knobX=cx+dx*scale; knobY=cy+dy*scale;
            float nx=(knobX-cx)/baseRadius, ny=(knobY-cy)/baseRadius; float mag=(float)Math.hypot(nx,ny);
            if(mag<DEADZONE){nx=0;ny=0;mag=0;} else {float adjusted=(mag-DEADZONE)/(1f-DEADZONE); float factor=adjusted/mag; nx*=factor;ny*=factor;mag=adjusted;}
            axisX=nx; axisY=-ny; magnitude=mag;
            if(listener!=null) listener.onAxis(axisX,axisY,magnitude); invalidate(); return true;
        }
        if(e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL) {
            active=false; axisX=axisY=magnitude=0; knobX=cx;knobY=cy; if(listener!=null)listener.onAxis(0,0,0); invalidate(); return true;
        }
        return true;
    }

    /** Updates the same virtual stick from keyboard state (WASD). */
    public void setKeyboardAxes(float x, float y) {
        if (active) return; // Physical touch takes priority while the pad is being dragged.
        float len = (float) Math.hypot(x, y);
        if (len > 1f) { x /= len; y /= len; len = 1f; }
        if (len < DEADZONE) { x = 0f; y = 0f; len = 0f; }
        else {
            float adjusted = (len - DEADZONE) / (1f - DEADZONE);
            float factor = adjusted / len;
            x *= factor; y *= factor; len = adjusted;
        }
        axisX = x; axisY = y; magnitude = len;
        if (listener != null) listener.onAxis(axisX, axisY, magnitude);
        invalidate();
    }
}
