# HAZE SENSI BETA 0.7.0 — Build

Este ZIP contém o projeto-fonte Android (Kotlin + Jetpack Compose), não um APK.

## Build no AndroidForge
1. Envie o ZIP completo para o fluxo AndroidForge.
2. Execute a tarefa `assembleDebug` / build Debug.
3. Baixe o APK Debug somente se a execução terminar com sucesso.

Configuração: AGP 8.7.3, Kotlin 2.0.21, JDK 17, compileSdk 35, minSdk 29.

## Alterações da versão
- Abas independentes: Mouse, GG Mouse, Second Screen, Laboratório e Histórico.
- Campos para anti-tremer, resolução da second screen, taxa de atualização, orientação e escala.
- Configurações novas salvas localmente junto ao perfil existente.

Observação: Anti-tremer é um registro da configuração selecionada pelo usuário. O HAZE não tem integração remota com o GG para ativar/desativar esse recurso. Campos de configuração devem refletir opções reais presentes na versão instalada do mapeador.
