package com.haze.sensi

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haze.sensi.engine.*
import com.haze.sensi.model.MappingProfile
import com.haze.sensi.model.MotionSample
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF09090F)
private val Panel = Color(0xFF151520)
private val Violet = Color(0xFFAA8BFF)
private val Muted = Color(0xFFAAA7BA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { HazeApp() } }
}

@Composable
fun HazeApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val store = remember { MappingProfileStore(context) }
    val saved = remember { store.loadMapping() }
    val history = remember { mutableStateListOf<String>().apply { addAll(store.loadHistory()) } }
    var tab by remember { mutableIntStateOf(0) }
    var appVersion by remember { mutableStateOf(saved.appVersion) }
    var mouseDpi by remember { mutableStateOf(saved.mouseDpi) }
    var phoneDpi by remember { mutableStateOf(saved.phoneDpi) }
    var acceleration by remember { mutableStateOf(saved.acceleration) }
    var horizontal by remember { mutableStateOf(saved.sensitivityX) }
    var vertical by remember { mutableStateOf(saved.sensitivityY) }
    var switched by remember { mutableStateOf(saved.switchedSensitivity) }
    var switchedEnabled by remember { mutableStateOf(saved.switchedEnabled) }
    var maxScale by remember { mutableStateOf(saved.sensitivityMaximum.ifBlank { "100" }) }
    var step by remember { mutableStateOf("1") }
    var smoothing by remember { mutableStateOf(saved.smoothing) }
    var deadzone by remember { mutableStateOf(saved.deadzone) }
    var curve by remember { mutableStateOf(saved.responseCurve) }
    var aimButton by remember { mutableStateOf(saved.aimButtonBehavior) }
    var controlProfile by remember { mutableStateOf(saved.controlProfile) }
    var message by remember { mutableStateOf("") }
    var axis by remember { mutableStateOf(MobiladorAxis.HORIZONTAL) }
    var proposal by remember { mutableStateOf<TuningProposal?>(null) }
    var feedback by remember { mutableStateOf<GameFeedback?>(null) }
    var samples by remember { mutableStateOf(listOf<MotionSample>()) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    var lastMotion by remember { mutableStateOf("Nenhum movimento registrado ainda.") }
    var motionDetail by remember { mutableStateOf("A análise mede somente a trajetória recebida pelo HAZE, não a câmera do Free Fire.") }
    val profile = MappingProfile(appVersion=appVersion, sensitivityX=horizontal, sensitivityY=vertical,
        acceleration=acceleration, smoothing=smoothing, deadzone=deadzone, responseCurve=curve,
        aimButtonBehavior=aimButton, controlProfile=controlProfile, switchedSensitivity=switched,
        sensitivityMaximum=maxScale, switchedEnabled=switchedEnabled, mouseDpi=mouseDpi, phoneDpi=phoneDpi)
    val settings = MobiladorSettings(mouseDpi=mouseDpi.toIntOrNull(), phoneDpi=phoneDpi.toIntOrNull(),
        counterAcceleration=acceleration, horizontal=horizontal.replace(",", ".").toDoubleOrNull(), vertical=vertical.replace(",", ".").toDoubleOrNull(),
        switched=switched.replace(",", ".").toDoubleOrNull(), switchedEnabled=switchedEnabled,
        sensitivityMaximum=maxScale.replace(",", ".").toDoubleOrNull() ?: 100.0, adjustmentStep=step.replace(",", ".").toDoubleOrNull() ?: 1.0)

    MaterialTheme(colorScheme = darkColorScheme(primary=Violet, background=Ink, surface=Panel, onBackground=Color.White, onSurface=Color.White)) {
        Surface(Modifier.fillMaxSize(), color=Ink) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(horizontal=20.dp, vertical=17.dp), verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("HAZE", color=Color.White, fontSize=31.sp, fontWeight=FontWeight.Black, letterSpacing=3.sp)
                        Text("MOBILADOR LAB  •  GG MOUSE PRO 3 VIP", color=Muted, fontSize=9.sp, letterSpacing=1.2.sp)
                    }
                    Surface(color=Violet.copy(alpha=.14f), shape=RoundedCornerShape(30.dp)) {
                        Text("BETA 0.6", color=Violet, modifier=Modifier.padding(horizontal=12.dp, vertical=7.dp), style=MaterialTheme.typography.labelSmall)
                    }
                }
                TabRow(selectedTabIndex=tab, containerColor=Ink, contentColor=Violet, divider={ HorizontalDivider(color=Color(0xFF282635)) }) {
                    listOf("Setup", "Laboratório", "Histórico").forEachIndexed { i, label ->
                        Tab(selected=tab==i, onClick={tab=i}, text={ Text(label, fontSize=12.sp, maxLines=1) })
                    }
                }
                when(tab) {
                    0 -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement=Arrangement.spacedBy(13.dp)) {
                        CardBlock("PERFIL DO MAPEADOR") {
                            Field("Versão do GG Mouse Pro 3", appVersion, { appVersion=it }, false)
                            Text("Preencha apenas o que aparece na sua versão do GG. O HAZE não presume que todos os controles existam.", color=Muted, style=MaterialTheme.typography.bodySmall)
                        }
                        CardBlock("HARDWARE") {
                            Field("DPI físico do mouse", mouseDpi, { mouseDpi=it }, true)
                            Field("DPI / densidade da tela Android", phoneDpi, { phoneDpi=it }, true)
                            Field("Aceleração do contador (valor exibido no GG)", acceleration, { acceleration=it }, false)
                        }
                        CardBlock("SENSIBILIDADE DO GG MOUSE PRO 3") {
                            Field("Sensibilidade horizontal", horizontal, { horizontal=it }, true)
                            Field("Sensibilidade vertical", vertical, { vertical=it }, true)
                            Row(verticalAlignment=Alignment.CenterVertically) {
                                Text("Sensibilidade comutada", color=Color.White, modifier=Modifier.weight(1f))
                                Switch(checked=switchedEnabled, onCheckedChange={switchedEnabled=it})
                            }
                            if (switchedEnabled) Field("Valor da sensibilidade comutada", switched, { switched=it }, true)
                            Field("Limite máximo da escala mostrado no GG", maxScale, { maxScale=it }, true)
                            Field("Passo por ajuste", step, { step=it }, true)
                            Text("100 é apenas o limite inicial sugerido para preencher o perfil. Confirme o máximo exibido na sua versão do GG. O HAZE não presume escalas nem altera DPI ou aceleração automaticamente.", color=Muted, style=MaterialTheme.typography.bodySmall)
                        }
                        CardBlock("OUTROS CONTROLES (OPCIONAIS)") {
                            Field("Suavização", smoothing, { smoothing=it }, false)
                            Field("Zona morta", deadzone, { deadzone=it }, false)
                            Field("Curva de resposta", curve, { curve=it }, false)
                            Field("Comportamento do botão de mira", aimButton, { aimButton=it }, false)
                            Field("Perfil / layout do controle", controlProfile, { controlProfile=it }, false)
                        }
                        Button(onClick={ store.saveMapping(profile); message="Perfil do mobilador salvo neste aparelho." }, modifier=Modifier.fillMaxWidth()) { Text("SALVAR PERFIL") }
                        if(message.isNotBlank()) Text(message, color=Violet, style=MaterialTheme.typography.bodySmall)
                        Text("Importante: DPI do mouse e DPI do celular são parâmetros diferentes. Informe o valor do seu setup; não converta automaticamente para a densidade de exibição Android.", color=Muted, style=MaterialTheme.typography.labelSmall)
                    }
                    1 -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement=Arrangement.spacedBy(13.dp)) {
                        CardBlock("01 / TESTE DE MOVIMENTO") {
                            Text("Faça uma puxada com o mouse dentro da área. O HAZE registra o movimento recebido enquanto está aberto; isso não mede diretamente a câmera do Free Fire.", color=Muted, style=MaterialTheme.typography.bodySmall)
                            val target = Offset(canvasSize.width*.76f, canvasSize.height*.35f)
                            Canvas(Modifier.fillMaxWidth().height(210.dp).background(Color(0xFF090910), RoundedCornerShape(14.dp)).onSizeChanged { canvasSize=it }
                                .pointerInput(canvasSize) {
                                    val buffer=ArrayList<MotionSample>(256)
                                    detectDragGestures(onDragStart={ p -> buffer.clear(); buffer.add(MotionSample(p.x,p.y,System.currentTimeMillis())) },
                                        onDrag={ change, _ -> if(change.type==PointerType.Mouse) { buffer.add(MotionSample(change.position.x,change.position.y,System.currentTimeMillis())); change.consume() } },
                                        onDragEnd={ samples=buffer.toList(); val result=MotionAnalyzer.analyze(samples, target.x, target.y, 30f); if(result!=null) { lastMotion="${result.sampleCount} pontos • ${result.durationMs} ms • trajeto ${result.pathLengthPx.toInt()} px"; motionDetail="Velocidade média ${result.averageSpeedPxPerSecond.toInt()} px/s • pico ${result.peakSpeedPxPerSecond.toInt()} px/s • linearidade ${(result.straightness*100).toInt()}% • distância do alvo ${result.endpointErrorPx.toInt()} px" } else { lastMotion="Movimento curto demais. Faça uma puxada mais longa."; motionDetail="São necessários pelo menos dois pontos de movimento." } },
                                        onDragCancel={ samples=buffer.toList() })
                                }) {
                                for(x in 0..size.width.toInt() step 28) drawLine(Color(0xFF292638),Offset(x.toFloat(),0f),Offset(x.toFloat(),size.height),1f)
                                for(y in 0..size.height.toInt() step 28) drawLine(Color(0xFF292638),Offset(0f,y.toFloat()),Offset(size.width,y.toFloat()),1f)
                                drawCircle(Violet.copy(alpha=.2f),43f,target); drawCircle(Violet,30f,target,style=Stroke(2f))
                                if(samples.isNotEmpty()) { val p=Path().apply{moveTo(samples.first().x,samples.first().y); samples.drop(1).forEach{lineTo(it.x,it.y)}}; drawPath(p,Color.White,style=Stroke(3f)) }
                            }
                            Text(lastMotion, color=Violet, style=MaterialTheme.typography.labelSmall)
                            Text(motionDetail, color=Muted, style=MaterialTheme.typography.bodySmall)
                            Text("Mantenha a mesma superfície e o mesmo DPI durante os testes. Compare trajetórias curtas e longas separadamente.", color=Muted, style=MaterialTheme.typography.bodySmall)
                        }
                        CardBlock("02 / FEEDBACK NO JOGO") {
                            Text("Agora teste no modo treinamento do Free Fire. Repita a mesma puxada, com o mesmo DPI e a mesma aceleração. Escolha somente o eixo que está ajustando e registre o resultado.", color=Muted, style=MaterialTheme.typography.bodySmall)
                            ChoiceRow(MobiladorAxis.entries.map{it.label}, axis.label) { selected -> axis=MobiladorAxis.entries.first{entry -> entry.label==selected}; proposal=null }
                            if(axis==MobiladorAxis.SWITCHED && !switchedEnabled) Text("Ative e configure a sensibilidade comutada no GG antes de ajustar este campo.", color=Muted, style=MaterialTheme.typography.bodySmall)
                            GameFeedback.entries.forEach { item ->
                                OutlinedButton(onClick={ feedback=item; proposal=SensitivityOptimizer.refine(settings,axis,item); message=when(item){ GameFeedback.HIT->"Acertou: mantenha o valor atual."; GameFeedback.UNSTABLE->"Resultado instável: repita o teste sem alterar nada."; else-> if(proposal==null) "Não foi possível gerar ajuste. Confira valor atual e limite máximo." else "Prévia pronta. Confira antes de aplicar." } }, modifier=Modifier.fillMaxWidth()) { Text(item.label) }
                            }
                        }
                        proposal?.let { p -> CardBlock("03 / AJUSTE PROPOSTO") {
                            Text("${p.axis.label}: ${format(p.before)}  →  ${format(p.after)}", color=Violet, style=MaterialTheme.typography.titleMedium, fontWeight=FontWeight.Bold)
                            Text(p.reason, color=Muted, style=MaterialTheme.typography.bodySmall)
                            Text("Só este eixo será alterado. Não mexa no DPI ou na aceleração durante a comparação.", color=Color.White, style=MaterialTheme.typography.bodySmall)
                            Button(onClick={
                                when(p.axis){ MobiladorAxis.HORIZONTAL->horizontal=format(p.after); MobiladorAxis.VERTICAL->vertical=format(p.after); MobiladorAxis.SWITCHED->switched=format(p.after) }
                                val updated=profile.copy(sensitivityX=horizontal,sensitivityY=vertical,switchedSensitivity=switched)
                                store.saveMapping(updated)
                                val stamp=SimpleDateFormat("dd/MM HH:mm",Locale("pt","BR")).format(Date())
                                val log="$stamp • ${p.axis.label} ${format(p.before)} → ${format(p.after)} • ${feedback?.label ?: "ajuste"}"
                                store.addHistory(log); history.add(0,log); while(history.size>40) history.removeAt(history.lastIndex)
                                message="Ajuste aplicado e salvo. Faça o mesmo teste novamente."; proposal=null
                            }, modifier=Modifier.fillMaxWidth()) { Text("APLICAR E SALVAR") }
                        } }
                        if(message.isNotBlank()) Text(message,color=Violet,style=MaterialTheme.typography.bodySmall)
                    }
                    else -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        CardBlock("HISTÓRICO DE CALIBRAÇÃO") {
                            if(history.isEmpty()) Text("Seus ajustes aplicados aparecerão aqui.",color=Muted,style=MaterialTheme.typography.bodySmall)
                            history.forEach { Text(it,color=Color.White,style=MaterialTheme.typography.bodySmall); HorizontalDivider(color=Color(0xFF302B40)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun CardBlock(title:String, content:@Composable ColumnScope.()->Unit) {
    Column(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(20.dp)).padding(16.dp), verticalArrangement=Arrangement.spacedBy(11.dp)) {
        Text(title,color=Color(0xFFC4AEFF),style=MaterialTheme.typography.labelLarge,letterSpacing=1.1.sp,fontWeight=FontWeight.Bold); content()
    }
}

@Composable private fun Field(label:String,value:String,onValue:(String)->Unit,numeric:Boolean) {
    Column(verticalArrangement=Arrangement.spacedBy(4.dp)) {
        Text(label,color=Muted,style=MaterialTheme.typography.labelSmall)
        OutlinedTextField(value=value,onValueChange={raw->onValue(if(numeric) raw.filter{it.isDigit()||it=='.'||it==','}.take(12) else raw.take(50))},modifier=Modifier.fillMaxWidth(),singleLine=true,shape=RoundedCornerShape(13.dp),colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=Violet,unfocusedBorderColor=Color(0xFF393448),focusedTextColor=Color.White,unfocusedTextColor=Color.White,cursorColor=Violet))
    }
}

@Composable private fun ChoiceRow(options:List<String>,selected:String,onSelect:(String)->Unit) {
    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) { options.forEach { item -> FilterChip(selected=item==selected,onClick={onSelect(item)},label={Text(item,fontSize=11.sp)}) } }
}

private fun format(value:Double):String = if(value%1.0==0.0) value.toInt().toString() else String.format(Locale.US,"%.1f",value)
