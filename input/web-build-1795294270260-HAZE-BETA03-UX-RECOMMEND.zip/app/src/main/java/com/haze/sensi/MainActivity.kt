package com.haze.sensi

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haze.sensi.engine.GameFeedback
import com.haze.sensi.engine.SensitivityOptimizer
import com.haze.sensi.model.*
import com.haze.sensi.ui.CalibrationLab
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF09090F)
private val Panel = Color(0xFF151520)
private val Violet = Color(0xFFAA8BFF)
private val Muted = Color(0xFFAAA7BA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { HazeApp() } }
}

@Composable
fun HazeApp() {
    val context = LocalContext.current
    val store = remember { MappingProfileStore(context) }
    val savedMapping = remember { store.loadMapping() }
    val history = remember { mutableStateListOf<String>().apply { addAll(store.loadHistory()) } }
    var tab by remember { mutableIntStateOf(0) }
    var category by remember { mutableIntStateOf(0) }
    var device by remember { mutableStateOf("") }
    var dpiMouse by remember { mutableStateOf("") }
    var polling by remember { mutableStateOf("") }
    var dpiScreen by remember { mutableStateOf("") }
    var pointerSpeed by remember { mutableStateOf("0") }
    var width by remember { mutableStateOf("") }
    var height by remember { mutableStateOf("") }
    var refresh by remember { mutableStateOf("") }
    var mappingVersion by remember { mutableStateOf(savedMapping.appVersion) }
    var mappingSensitivity by remember { mutableStateOf(savedMapping.sensitivity) }
    var mappingX by remember { mutableStateOf(savedMapping.sensitivityX) }
    var mappingY by remember { mutableStateOf(savedMapping.sensitivityY) }
    var mappingAcceleration by remember { mutableStateOf(savedMapping.acceleration) }
    var mappingSmoothing by remember { mutableStateOf(savedMapping.smoothing) }
    var mappingDeadzone by remember { mutableStateOf(savedMapping.deadzone) }
    var mappingCurve by remember { mutableStateOf(savedMapping.responseCurve) }
    var mappingAimButton by remember { mutableStateOf(savedMapping.aimButtonBehavior) }
    var mappingControlProfile by remember { mutableStateOf(savedMapping.controlProfile) }
    var mappingSaved by remember { mutableStateOf(false) }
    var goal by remember { mutableStateOf(AimGoal.BALANCED) }
    var drag by remember { mutableStateOf(DragProfile.SMOOTH) }
    var sensitivity by remember { mutableStateOf(store.loadSensitivity()) }
    var lastResult by remember { mutableStateOf<com.haze.sensi.model.CalibrationResult?>(null) }
    var feedbackMessage by remember { mutableStateOf("") }
    var pendingSensitivity by remember { mutableStateOf<SensitivityValues?>(null) }
    var pendingFeedback by remember { mutableStateOf<GameFeedback?>(null) }

    val deviceProfile = DeviceProfile(deviceName = device, mouseDpi = dpiMouse.toIntOrNull(), pollingRateHz = polling.toIntOrNull(), androidDisplayDpi = dpiScreen.toIntOrNull(), pointerSpeed = pointerSpeed.toIntOrNull(), screenWidthPx = width.toIntOrNull(), screenHeightPx = height.toIntOrNull(), refreshRateHz = refresh.toIntOrNull())

    MaterialTheme(colorScheme = darkColorScheme(primary = Violet, background = Ink, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            Column(Modifier.fillMaxSize()) {
                Column(Modifier.fillMaxWidth().background(Ink).padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("HAZE", color = Color.White, fontSize = 31.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                            Text("SENSI LAB  •  FREE FIRE", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                        }
                        Surface(color = Violet.copy(alpha = .13f), shape = RoundedCornerShape(30.dp)) { Text("BETA 0.2", color = Violet, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), style = MaterialTheme.typography.labelSmall) }
                    }
                }
                TabRow(selectedTabIndex = tab, containerColor = Ink, contentColor = Violet, divider = { HorizontalDivider(color = Color(0xFF282635)) }) {
                    listOf("Configuração", "Calibração", "Resultados").forEachIndexed { i, label ->
                        Tab(selected = tab == i, onClick = { tab = i }, text = { Text(label, fontSize = 12.sp, maxLines = 1) })
                    }
                }
                when (tab) {
                    0 -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("Seu equipamento", color = Color.White, style = MaterialTheme.typography.titleLarge)
                        Text("Organize os dados por categoria. Preencha apenas o que souber.", color = Muted, style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Dispositivo", "Mouse", "GG Mouse").forEachIndexed { i, label ->
                                FilterChip(selected = category == i, onClick = { category = i }, label = { Text(label, fontSize = 11.sp) })
                            }
                        }
                        when (category) {
                            0 -> HazeCard("DISPOSITIVO") {
                                ProfileField("Modelo do celular", device, { device = it })
                                ProfileField("DPI da tela Android (opcional)", dpiScreen, { dpiScreen = it }, true)
                                ProfileField("Velocidade do ponteiro Android", pointerSpeed, { pointerSpeed = it }, true)
                                ProfileField("Resolução — largura (px)", width, { width = it }, true)
                                ProfileField("Resolução — altura (px)", height, { height = it }, true)
                                ProfileField("Taxa de atualização (Hz)", refresh, { refresh = it }, true)
                            }
                            1 -> HazeCard("MOUSE") {
                                ProfileField("DPI do mouse", dpiMouse, { dpiMouse = it }, true)
                                ProfileField("Polling rate (Hz)", polling, { polling = it }, true)
                            }
                            else -> HazeCard("GG MOUSE PRO 3 VIP") {
                                Text("Informe as opções que aparecem na sua versão. O que não existir pode ficar em branco.", color = Muted, style = MaterialTheme.typography.bodySmall)
                                ProfileField("Versão do aplicativo", mappingVersion, { mappingVersion = it })
                                ProfileField("Sensibilidade geral", mappingSensitivity, { mappingSensitivity = it })
                                ProfileField("Sensibilidade eixo X", mappingX, { mappingX = it })
                                ProfileField("Sensibilidade eixo Y", mappingY, { mappingY = it })
                                ProfileField("Aceleração", mappingAcceleration, { mappingAcceleration = it })
                                ProfileField("Suavização", mappingSmoothing, { mappingSmoothing = it })
                                ProfileField("Zona morta", mappingDeadzone, { mappingDeadzone = it })
                                ProfileField("Curva de resposta", mappingCurve, { mappingCurve = it })
                                ProfileField("Comportamento do botão de mira", mappingAimButton, { mappingAimButton = it })
                                ProfileField("Perfil de controle do Free Fire", mappingControlProfile, { mappingControlProfile = it })
                                Button(onClick = {
                                    store.saveMapping(MappingProfile(mappingVersion, mappingSensitivity, mappingX, mappingY, mappingAcceleration, mappingSmoothing, mappingDeadzone, mappingCurve, mappingAimButton, mappingControlProfile))
                                    mappingSaved = true
                                }, modifier = Modifier.fillMaxWidth()) { Text("SALVAR PERFIL DO MAPPING") }
                                if (mappingSaved) Text("Perfil salvo neste dispositivo.", color = Violet, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        HazeCard("PREFERÊNCIAS DE MIRA") {
                            Text("Objetivo", color = Muted, style = MaterialTheme.typography.labelSmall)
                            ChoiceChips(AimGoal.entries.map { it.label }, goal.label) { goal = AimGoal.entries.first { e -> e.label == it } }
                            Text("Estilo de puxada", color = Muted, style = MaterialTheme.typography.labelSmall)
                            ChoiceChips(DragProfile.entries.map { it.label }, drag.label) { drag = DragProfile.entries.first { e -> e.label == it } }
                        }
                        Text("Escala interna HAZE: 0–100 • Mapping de referência: GG Mouse Pro 3 VIP", color = Muted, style = MaterialTheme.typography.labelSmall)
                    }
                    1 -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        HazeCard("ETAPA 01  /  PERFIL ATUAL") {
                            Text("Informe seus valores atuais do Free Fire na aba Resultados antes de começar. A calibração registra seu movimento; o ajuste depende também do teste real no jogo.", color = Muted, style = MaterialTheme.typography.bodySmall)
                            Button(onClick = { tab = 2 }, modifier = Modifier.fillMaxWidth()) { Text("CONFIGURAR SENSIBILIDADE ATUAL") }
                        }
                        CalibrationLab(deviceProfile, AimPreferences(goal, drag), sensitivity) { result -> lastResult = result }
                    }
                    else -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        HazeCard("SENSIBILIDADE ATUAL DO FREE FIRE") {
                            Text("Digite os valores que estão aplicados no jogo. O HAZE usa esses números como ponto de partida.", color = Muted, style = MaterialTheme.typography.bodySmall)
                            SensitivityField("Geral", sensitivity.general) { sensitivity = sensitivity.copy(general = it).also(store::saveSensitivity) }
                            SensitivityField("Red Dot", sensitivity.redDot) { sensitivity = sensitivity.copy(redDot = it).also(store::saveSensitivity) }
                            SensitivityField("Mira 2x", sensitivity.scope2x) { sensitivity = sensitivity.copy(scope2x = it).also(store::saveSensitivity) }
                            SensitivityField("Mira 4x", sensitivity.scope4x) { sensitivity = sensitivity.copy(scope4x = it).also(store::saveSensitivity) }
                            SensitivityField("AWM / Sniper", sensitivity.sniper) { sensitivity = sensitivity.copy(sniper = it).also(store::saveSensitivity) }
                            SensitivityField("Olhadinha", sensitivity.freeLook) { sensitivity = sensitivity.copy(freeLook = it).also(store::saveSensitivity) }
                        }
                        HazeCard("ETAPA 02  /  FEEDBACK DO JOGO") {
                            Text("Depois de testar sua sensibilidade no Free Fire, escolha o que aconteceu. O ajuste é pequeno e pode ser repetido após outro teste.", color = Muted, style = MaterialTheme.typography.bodySmall)
                            GameFeedback.entries.forEach { item ->
                                OutlinedButton(onClick = {
                                    pendingFeedback = item
                                    pendingSensitivity = SensitivityOptimizer.refine(sensitivity, item, AimPreferences(goal, drag))
                                    feedbackMessage = "Prévia gerada. Confira os valores antes de aplicar."
                                }, modifier = Modifier.fillMaxWidth()) { Text(item.label) }
                                Text(item.description, color = Muted, style = MaterialTheme.typography.labelSmall)
                            }
                            if (feedbackMessage.isNotBlank()) Text(feedbackMessage, color = Violet, style = MaterialTheme.typography.bodySmall)
                        }
                        pendingSensitivity?.let { proposed ->
                            HazeCard("PRÉVIA DA RECOMENDAÇÃO") {
                                val before = sensitivity
                                Text("${pendingFeedback?.label ?: "Feedback"} • ajuste conservador", color = Violet, style = MaterialTheme.typography.labelMedium)
                                RecommendationLine("Geral", before.general, proposed.general)
                                RecommendationLine("Red Dot", before.redDot, proposed.redDot)
                                RecommendationLine("Mira 2x", before.scope2x, proposed.scope2x)
                                RecommendationLine("Mira 4x", before.scope4x, proposed.scope4x)
                                RecommendationLine("Sniper", before.sniper, proposed.sniper)
                                RecommendationLine("Olhadinha", before.freeLook, proposed.freeLook)
                                Button(onClick = {
                                    sensitivity = proposed.also(store::saveSensitivity)
                                    val item = pendingFeedback
                                    val stamp = SimpleDateFormat("dd/MM HH:mm", Locale("pt", "BR")).format(Date())
                                    val entry = "$stamp • ${item?.label ?: "Ajuste"} • Geral ${proposed.general} / Red Dot ${proposed.redDot}"
                                    store.addHistory(entry); history.add(0, entry); while (history.size > 20) history.removeAt(history.lastIndex)
                                    feedbackMessage = "Configuração aplicada e salva. Teste novamente no Free Fire."
                                    pendingSensitivity = null; pendingFeedback = null
                                }, modifier = Modifier.fillMaxWidth()) { Text("APLICAR RECOMENDAÇÃO") }
                                TextButton(onClick = { pendingSensitivity = null; pendingFeedback = null }) { Text("Descartar prévia") }
                            }
                        }
                        HazeCard("RECOMENDAÇÃO HAZE") {
                            if (lastResult == null) Text("Faça uma tentativa na aba Calibração para ver a análise do movimento.", color = Muted, style = MaterialTheme.typography.bodySmall)
                            else {
                                Text(lastResult!!.confidenceLabel, color = Violet, style = MaterialTheme.typography.labelMedium)
                                Text(lastResult!!.explanation, color = Color.White, style = MaterialTheme.typography.bodySmall)
                            }
                            Text("Geral ${sensitivity.general}  •  Red Dot ${sensitivity.redDot}", color = Color.White, style = MaterialTheme.typography.bodyMedium)
                            Text("2x ${sensitivity.scope2x}  •  4x ${sensitivity.scope4x}  •  Sniper ${sensitivity.sniper}  •  Olhadinha ${sensitivity.freeLook}", color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                        if (history.isNotEmpty()) HazeCard("HISTÓRICO RECENTE") {
                            history.take(10).forEach { Text(it, color = Muted, style = MaterialTheme.typography.bodySmall); HorizontalDivider(color = Color(0xFF302B40)) }
                        }
                        Text("O HAZE não lê nem altera dados do Free Fire ou do GG Mouse. As sugestões são baseadas nos valores informados e no seu feedback após testar no jogo.", color = Muted, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun HazeCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp)).padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp), content = {
        Text(title, color = Color(0xFFC4AEFF), style = MaterialTheme.typography.labelLarge, letterSpacing = 1.4.sp, fontWeight = FontWeight.Bold)
        content()
    })
}

@Composable
private fun ProfileField(label: String, value: String, onValue: (String) -> Unit, numeric: Boolean = false) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, color = Muted, style = MaterialTheme.typography.labelSmall)
        OutlinedTextField(value = value, onValueChange = { onValue(if (numeric) it.filter(Char::isDigit).take(6) else it) }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(14.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Violet, unfocusedBorderColor = Color(0xFF393448), focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Violet))
    }
}

@Composable
private fun SensitivityField(label: String, value: Int, onValue: (Int) -> Unit) {
    var input by remember(value) { mutableStateOf(value.toString()) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color.White, style = MaterialTheme.typography.bodyMedium)
        OutlinedTextField(value = input, onValueChange = { raw ->
            input = raw.filter(Char::isDigit).take(3)
            input.toIntOrNull()?.let { onValue(it.coerceIn(0, 100)) }
        }, modifier = Modifier.width(92.dp), singleLine = true, shape = RoundedCornerShape(12.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Violet, unfocusedBorderColor = Color(0xFF393448), focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Violet))
    }
}

@Composable
private fun RecommendationLine(label: String, before: Int, after: Int) {
    val delta = after - before
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Text(before.toString(), color = Color.White, style = MaterialTheme.typography.bodyMedium)
        Text("  →  ", color = Muted, style = MaterialTheme.typography.bodySmall)
        Text(after.toString(), color = if (delta == 0) Muted else Violet, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
        if (delta != 0) Text("  (${if (delta > 0) "+" else ""}$delta)", color = Violet, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun ChoiceChips(options: List<String>, selected: String, onSelected: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        options.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                pair.forEach { option -> FilterChip(selected = option == selected, onClick = { onSelected(option) }, label = { Text(option, fontSize = 11.sp) }) }
            }
        }
    }
}
