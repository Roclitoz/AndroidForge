# Haze Mapper Pro 0.3.1

Android keyboard/mouse mapping research project. Current release adds a landscape Coordinate Lab to measure the app viewport and persist touch samples before any new uinput coordinate transform is selected.

## 0.3.1
- Landscape-only Coordinate Lab with safe insets and display rotation/density capture.
- Five-point touch sampling persisted locally.
- Explicitly keeps the old Samsung/uinput axis transform classified as legacy and unverified; no new axis guess is introduced.
- Existing Shizuku bridge and global keyboard capture are retained.

## Build
Android Gradle Plugin 8.7.3, Gradle 8.9, Android SDK 35, NDK/CMake, Java 17. Build with `gradle :app:assembleDebug` in a configured Android environment.

This source package is not an APK. The 0.3.1 source was validated with pure Java smoke tests only; Android/NDK build and Galaxy A17 runtime tests remain pending.
