# Haze Mapper Pro roadmap

## 0.3.0 — Architecture pivot
- [x] Model WASD as one virtual stick/contact, not independent key touches.
- [x] Add a landscape-only normalized viewport contract.
- [x] Add direct launch actions for Free Fire and Free Fire MAX.
- [x] Document what remains incomplete and define target architecture.
- [ ] Integrate measured landscape viewport with actual game overlay.
- [ ] Replace inferred native transform with a measured calibration matrix.

## 0.3.1 — Coordinate Lab
- [ ] Landscape-first calibration screen with an accurate 16:9/actual-aspect game canvas.
- [ ] Record rotation, display size, insets and viewport bounds.
- [ ] Draw joystick center, dead zone and radius as editable geometry.
- [ ] Verify each cardinal direction and diagonals with on-screen diagnostics.
- [ ] Save calibration per display/game profile.

## 0.3.2 — Touch Session
- [ ] Centralized native touch-slot state machine and mutex.
- [ ] Strict DOWN/MOVE/UP lifecycle and SYN_REPORT validation.
- [ ] Per-slot ownership and cleanup on all lifecycle exits.
- [ ] Verify actual multi-touch behavior and coordinate ranges on Galaxy A17.

## 0.3.3 — Live HUD editor
- [ ] Accessibility overlay editor above the game, not a portrait-only preview.
- [ ] Drag, resize, select, bind, opacity and save controls.
- [ ] Separate EDIT and PLAY modes.
- [ ] Test Android 12+ overlay touch pass-through restrictions.

## 0.3.4 — Game session and controls
- [x] Launch Free Fire / Free Fire MAX from mapper.
- [ ] Detect active game package and restore profile.
- [ ] Button controls: tap and hold semantics.
- [ ] Vista state machine, mouse-look and cursor/click behavior.
- [ ] Persistent session recovery and fail-safe release.

## 0.3.5 — Input quality
- [ ] Mouse relative-motion capture research and device compatibility matrix.
- [ ] Sensitivity, acceleration and dead-zone calibration for camera look.
- [ ] Latency profiling and event backlog monitoring.
- [ ] Permission, UID, Binder and native error hardening.
