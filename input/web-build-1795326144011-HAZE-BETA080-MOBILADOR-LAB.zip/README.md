# HAZE SENSI — Beta 0.6 (Mobilador)

HAZE é dedicado ao Free Fire em setup mobilador: mouse + teclado via GG Mouse Pro 3 VIP. Não há perfil touchscreen/mobile.

## Referências consultadas

1. **FALL90HZ — Gerador de Mobilador**: separa explicitamente a plataforma Mobilador e lista DPI do mouse, DPI do celular, aceleração do contador, sensibilidade horizontal/vertical e sensibilidade comutada opcional. É uma referência comunitária de nomenclatura e fluxo, não uma documentação oficial do GG nem prova de limites numéricos universais. https://fall90hz.github.io/Fall90hz-site/
2. **GG Mouse Pro 3 — Google Play**: identifica o aplicativo como ferramenta para usar mouse e teclado em jogos Android. A listagem não publica um esquema técnico completo dos controles de sensibilidade. https://play.google.com/store/apps/details?id=com.zjx.ztezscreenshot
3. **GG Mouse Pro 3 — guia de configuração Free Fire**: recomenda salvar o HUD, alinhar o mapeamento ao HUD e testar movimento, câmera e botões separadamente; DPI constante durante os testes. É um guia público, não documentação técnica oficial de todos os parâmetros. https://www.ggmousepro.in/free-fire-settings
4. **GG Mouse Pro 3 — guia de calibração**: recomenda manter DPI fixo, repetir o mesmo movimento, alterar uma variável por vez e separar problemas de sensibilidade de falhas de conexão/entrada. https://www.ggmousepro.in/sensitivity-guide

## O que mudou na 0.6
- Projeto dedicado ao mobilador e ao GG Mouse Pro 3 VIP.
- Sem presets de touchscreen e sem copiar valores gerais de sensibilidade mobile do Free Fire.
- Campos do mobilador: DPI físico do mouse, densidade/DPI Android (informação contextual), aceleração do contador, sensibilidade horizontal/vertical e comutada opcional.
- Campos adicionais (suavização, zona morta, curva, comportamento do botão e layout) são opcionais: preencher somente se aparecerem na versão instalada.
- Escala de sensibilidade configurável pelo usuário. 100 é somente o valor inicial editável; confirmar o limite real no GG antes de calibrar.
- Ajuste conservador por feedback real do jogador: passou do alvo diminui; ficou abaixo aumenta; acertou/instável não altera. Apenas um eixo por vez.
- DPI e aceleração são contexto e nunca são alterados automaticamente.
- Laboratório mostra estatísticas da trajetória do mouse recebida pelo HAZE (distância, velocidade, linearidade e erro do ponto final). Isso não mede a resposta da câmera dentro do Free Fire.
- Histórico local de ajustes.

## Limites técnicos importantes
- O HAZE não lê nem modifica o estado interno do Free Fire ou do GG Mouse Pro 3.
- O gesto dentro do HAZE não equivale ao movimento da câmera dentro do jogo. As estatísticas servem para comparar consistência da trajetória, não para calcular diretamente uma sensibilidade perfeita.
- O motor é determinístico e baseado em feedback, não é IA treinada.
- Não existe preset universal verificável. A interface exige que o usuário confirme o limite numérico e os campos disponíveis na versão instalada.
- Se houver perda de entrada, desconexão ou travamento, primeiro corrigir conexão/ativação; sensibilidade não resolve esses problemas.

## Build
Projeto Android Kotlin + Jetpack Compose. AGP 8.7.3, Kotlin 2.0.21, JDK 17, compileSdk 35, minSdk 29. Fonte; não é APK compilado.


## BETA 0.6.1 — build fix
- Corrigida a inicialização do campo de DPI/densidade Android para ler `MappingProfile.phoneDpi` (o modelo não possui `androidDisplayDpi`).
- Incrementado versionCode para 7 e versionName para 0.6.1.

## BETA 0.7.0 — abas dedicadas e setup ampliado
- Navegação reorganizada em abas separadas: Mouse, GG Mouse, Second Screen, Laboratório e Histórico.
- Mouse: DPI físico, polling rate e velocidade do ponteiro.
- GG Mouse: versão do app, modo de mapeamento, aceleração, sensibilidades X/Y/comutada, limite e passo de ajuste.
- Incluído seletor Anti-tremer ativo (sim/não). Ele registra o estado escolhido pelo usuário; não controla remotamente o GG Mouse Pro 3.
- Second Screen: largura, altura, taxa de atualização, orientação e escala/zoom opcional.
- Preservadas as configurações existentes e adicionada persistência local dos novos campos.
- Campos que podem variar entre versões são opcionais e devem ser preenchidos somente quando existirem no app/driver utilizado.
- A resolução da second screen é informativa/contextual; o HAZE não muda a resolução do Android nem do GG.

## BETA 0.7.1 — Dashboard visual
- Home screen redesigned as a card dashboard inspired by the user's reference image.
- Five large clickable cards: Mouse, GG Mouse, Second Screen, Laboratório and Histórico.
- Tapping a card opens its dedicated settings area; a back chevron returns to the dashboard.
- Removed the always-visible horizontal tab row to keep the home screen clean.

## BETA 0.8.0 — HAZE SENSI

- Added the supplied HAZE SENSI cover as the dashboard hero artwork.
- Reworked dashboard cards with violet/purple gradients, line borders, Material icons, and Cabin typography.
- Added a selectable mapping-app edition list: GG Mouse Pro 3 (default), GG Mouse Pro 2, GG Mouse Pro 3 modified (RQZ/PRZ/RED), and GG Mouse Pro 2 modified (EV4X/KID/Lite), plus a custom option.
- The default is preselected as GG Mouse Pro 3; Android does not silently detect which third-party mapper variant is installed. The user confirms/changes it.
- Expanded the laboratory with guided short/long drag, micro-adjustment, lateral tracking, diagonal, and repeatability test choices.
- Added a dedicated, larger drag workspace and a five-part in-game feedback questionnaire. Feedback records are saved to local history.
- Added Cabin font resources and horizontal scrolling for compact choice groups.

### Research and scope

The Google Play listing identifies GG Mouse Pro 3 as a mouse-and-keyboard mapping app, and its official listing is the source for the product identity and publisher. The public setup guide recommends keeping mouse DPI fixed, aligning the keymap to the current HUD, and testing camera movement separately from individual buttons. The sensitivity guide recommends repeatable movements and changing one variable at a time. These informed the guided lab.

Sources:
- https://play.google.com/store/apps/details?id=com.zjx.ztezscreenshot
- https://www.ggmousepro.in/free-fire-settings
- https://www.ggmousepro.in/sensitivity-guide

The named modified editions (RQZ, PRZ, RED, EV4X, KID, Lite) are presented as user-selectable labels based on the user's requested ecosystem. They are not asserted as official GG Mouse releases. The app does not access or change GG Mouse settings directly, cannot reliably detect the installed variant, and does not read Free Fire camera movement. It stores the user's declared setup and analyses pointer trajectories delivered to HAZE while it is in the foreground; in-game feedback remains player-reported.
