package com.haze.sensi

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Mouse
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.Monitor
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Science
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haze.sensi.engine.*
import com.haze.sensi.model.MappingProfile
import com.haze.sensi.model.MotionSample
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink=Color(0xFF09090F)
private val Panel=Color(0xFF151520)
private val Violet=Color(0xFFB18CFF)
private val Magenta=Color(0xFFDA4DFF)
private val DeepPurple=Color(0xFF5526A8)
private val HazeFont=FontFamily(Font(R.font.cabin_regular,FontWeight.Normal),Font(R.font.cabin_bold,FontWeight.Bold))
private val Muted=Color(0xFFAAA7BA)

class MainActivity:ComponentActivity(){ override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState); setContent { HazeApp() } } }

@Composable
fun HazeApp(){
    val context=androidx.compose.ui.platform.LocalContext.current
    val store=remember { MappingProfileStore(context) }
    val saved=remember { store.loadMapping() }
    val history=remember { mutableStateListOf<String>().apply { addAll(store.loadHistory()) } }
    var tab by remember { mutableIntStateOf(-1) }
    var appVersion by remember { mutableStateOf(saved.appVersion.ifBlank { "GG Mouse Pro 3 (padrão)" }) }
    var versionMenu by remember { mutableStateOf(false) }
    var feedbackStability by remember { mutableStateOf("Oscila / treme") }
    var feedbackDirection by remember { mutableStateOf("Horizontal e vertical") }
    var feedbackDistance by remember { mutableStateOf("Puxada média") }
    var feedbackScope by remember { mutableStateOf("Mira livre / geral") }
    var feedbackConsistency by remember { mutableStateOf("Varia entre tentativas") }
    var testType by remember { mutableStateOf("Puxada curta") }
    var mouseDpi by remember { mutableStateOf(saved.mouseDpi) }
    var phoneDpi by remember { mutableStateOf(saved.phoneDpi) }
    var pollingRate by remember { mutableStateOf(saved.pollingRate) }
    var pointerSpeed by remember { mutableStateOf(saved.pointerSpeed) }
    var acceleration by remember { mutableStateOf(saved.acceleration) }
    var horizontal by remember { mutableStateOf(saved.sensitivityX) }
    var vertical by remember { mutableStateOf(saved.sensitivityY) }
    var switched by remember { mutableStateOf(saved.switchedSensitivity) }
    var switchedEnabled by remember { mutableStateOf(saved.switchedEnabled) }
    var maxScale by remember { mutableStateOf(saved.sensitivityMaximum.ifBlank { "100" }) }
    var step by remember { mutableStateOf("1") }
    var smoothing by remember { mutableStateOf(saved.smoothing) }
    var deadzone by remember { mutableStateOf(saved.deadzone) }
    var curve by remember { mutableStateOf(saved.responseCurve) }
    var aimButton by remember { mutableStateOf(saved.aimButtonBehavior) }
    var controlProfile by remember { mutableStateOf(saved.controlProfile) }
    var antiShake by remember { mutableStateOf(saved.antiShakeActive) }
    var secondWidth by remember { mutableStateOf(saved.secondScreenWidth) }
    var secondHeight by remember { mutableStateOf(saved.secondScreenHeight) }
    var secondRefresh by remember { mutableStateOf(saved.secondScreenRefreshRate) }
    var orientation by remember { mutableStateOf(saved.screenOrientation) }
    var mappingMode by remember { mutableStateOf(saved.mappingMode) }
    var screenScale by remember { mutableStateOf(saved.screenScale) }
    var extraNotes by remember { mutableStateOf(saved.extraNotes) }
    var message by remember { mutableStateOf("") }
    var axis by remember { mutableStateOf(MobiladorAxis.HORIZONTAL) }
    var proposal by remember { mutableStateOf<TuningProposal?>(null) }
    var feedback by remember { mutableStateOf<GameFeedback?>(null) }
    var samples by remember { mutableStateOf(listOf<MotionSample>()) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    var lastMotion by remember { mutableStateOf("Nenhum movimento registrado ainda.") }
    var motionDetail by remember { mutableStateOf("A análise mede somente a trajetória recebida pelo HAZE, não a câmera do Free Fire.") }

    val profile=MappingProfile(appVersion=appVersion,sensitivityX=horizontal,sensitivityY=vertical,
        acceleration=acceleration,smoothing=smoothing,deadzone=deadzone,responseCurve=curve,
        aimButtonBehavior=aimButton,controlProfile=controlProfile,switchedSensitivity=switched,
        sensitivityMaximum=maxScale,switchedEnabled=switchedEnabled,mouseDpi=mouseDpi,phoneDpi=phoneDpi,
        antiShakeActive=antiShake,antiShakeConfigured=true,pollingRate=pollingRate,pointerSpeed=pointerSpeed,
        secondScreenWidth=secondWidth,secondScreenHeight=secondHeight,secondScreenRefreshRate=secondRefresh,
        screenOrientation=orientation,mappingMode=mappingMode,screenScale=screenScale,extraNotes=extraNotes)
    val settings=MobiladorSettings(mouseDpi=mouseDpi.toIntOrNull(),phoneDpi=phoneDpi.toIntOrNull(),
        counterAcceleration=acceleration,horizontal=horizontal.replace(",",".").toDoubleOrNull(),
        vertical=vertical.replace(",",".").toDoubleOrNull(),switched=switched.replace(",",".").toDoubleOrNull(),
        switchedEnabled=switchedEnabled,sensitivityMaximum=maxScale.replace(",",".").toDoubleOrNull()?:100.0,
        adjustmentStep=step.replace(",",".").toDoubleOrNull()?:1.0)

    MaterialTheme(colorScheme=darkColorScheme(primary=Violet,background=Ink,surface=Panel,onBackground=Color.White,onSurface=Color.White), typography=Typography(defaultFontFamily=HazeFont)){
        Surface(Modifier.fillMaxSize(),color=Ink){
            Column(Modifier.fillMaxSize()){
                Row(Modifier.fillMaxWidth().padding(horizontal=20.dp,vertical=17.dp),verticalAlignment=Alignment.CenterVertically){
                    if(tab >= 0){
                        Text("‹",color=Color.White,fontSize=34.sp,fontWeight=FontWeight.Light,modifier=Modifier.clickable { tab = -1 }.padding(end=14.dp))
                    }
                    Column(Modifier.weight(1f)){
                        Text("HAZE",color=Color.White,fontSize=29.sp,fontWeight=FontWeight.Black,letterSpacing=2.sp,fontFamily=HazeFont)
                        Text("MOBILADOR LAB  •  GG MOUSE PRO 3 VIP",color=Muted,fontSize=9.sp,letterSpacing=1.2.sp)
                    }
                    Surface(color=Violet.copy(alpha=.14f),shape=RoundedCornerShape(30.dp)){ Text("BETA 0.8.0",color=Violet,modifier=Modifier.padding(horizontal=12.dp,vertical=7.dp),style=MaterialTheme.typography.labelSmall) }
                }
                if(tab == -1){
                    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal=16.dp, vertical=8.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
                        Image(painterResource(R.drawable.haze_cover),contentDescription="HAZE SENSI",modifier=Modifier.fillMaxWidth().height(224.dp),contentScale=androidx.compose.ui.layout.ContentScale.Crop)
                        Text("CENTRAL DE CONTROLE",color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold,letterSpacing=2.sp)
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)){
                            DashboardCard("Mouse","DPI, polling rate e\nvelocidade do ponteiro.",Icons.Outlined.Mouse,Modifier.weight(1f)){tab=0}
                            DashboardCard("GG Mouse","Versão, mira, resposta\ne estabilidade.",Icons.Outlined.Tune,Modifier.weight(1f)){tab=1}
                        }
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)){
                            DashboardCard("Second Screen","Resolução, orientação,\nescala e Hz.",Icons.Outlined.Monitor,Modifier.weight(1f)){tab=2}
                            DashboardCard("Laboratório","Calibração, testes e\nfeedback guiado.",Icons.Outlined.Science,Modifier.weight(1f)){tab=3}
                        }
                        DashboardCard("Histórico","Registro dos ajustes realizados.",Icons.Outlined.History,Modifier.fillMaxWidth(),wide=true){tab=4}
                    }
                } else when(tab){
                    0 -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(13.dp)){
                        CardBlock("HARDWARE DO MOUSE"){
                            Field("DPI físico do mouse",mouseDpi,{mouseDpi=it},true)
                            Field("Polling rate / taxa de atualização (Hz)",pollingRate,{pollingRate=it},true)
                            Field("Velocidade do ponteiro (se configurável)",pointerSpeed,{pointerSpeed=it},true)
                            Text("Use os valores reais do mouse/driver. Não altere DPI ou polling rate durante uma sequência de comparação.",color=Muted,style=MaterialTheme.typography.bodySmall)
                        }
                        CardBlock("DISPOSITIVO ANDROID"){
                            Field("DPI / densidade da tela Android",phoneDpi,{phoneDpi=it},true)
                            Text("Este campo registra a densidade do aparelho como referência. Não é o DPI físico do mouse.",color=Muted,style=MaterialTheme.typography.bodySmall)
                        }
                        SaveButton { store.saveMapping(profile); message="Configurações do mouse salvas." }
                        SaveMessage(message)
                    }
                    1 -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(13.dp)){
                        CardBlock("VERSÃO E MODO DE MAPEAMENTO"){
                            Text("Versão / edição do mapeador",color=Muted,style=MaterialTheme.typography.labelSmall)
                            Box {
                                OutlinedButton(onClick={versionMenu=true},modifier=Modifier.fillMaxWidth(),border=BorderStroke(1.dp,Violet.copy(alpha=.55f))) { Text(appVersion,color=Color.White); Spacer(Modifier.weight(1f)); Text("⌄",color=Violet) }
                                DropdownMenu(expanded=versionMenu,onDismissRequest={versionMenu=false}) {
                                    listOf("GG Mouse Pro 3 (padrão)","GG Mouse Pro 2","GG Mouse Pro 3 modificado — RQZ","GG Mouse Pro 3 modificado — PRZ","GG Mouse Pro 3 modificado — RED","GG Mouse Pro 2 modificado — EV4X","GG Mouse Pro 2 modificado — KID","GG Mouse Pro 2 modificado — Lite","Outro / versão personalizada").forEach { option -> DropdownMenuItem(text={Text(option)},onClick={appVersion=option;versionMenu=false}) }
                                }
                            }
                            if(appVersion.startsWith("Outro")) Field("Nome / versão exata",appVersion,{appVersion=it},false)
                            Text("O padrão inicia no GG Mouse Pro 3. Selecione a edição que realmente está instalada; versões modificadas podem alterar nomes e faixas dos controles.",color=Muted,style=MaterialTheme.typography.bodySmall)
                            Text("Modo de entrada",color=Muted,style=MaterialTheme.typography.labelSmall)
                            ChoiceRow(listOf("Mouse + teclado","Somente mouse","Outro"),mappingMode){mappingMode=it}
                        }
                        CardBlock("SENSIBILIDADE DO GG"){
                            Field("Aceleração do contador (valor exibido no GG)",acceleration,{acceleration=it},false)
                            Field("Sensibilidade horizontal",horizontal,{horizontal=it},true)
                            Field("Sensibilidade vertical",vertical,{vertical=it},true)
                            Row(verticalAlignment=Alignment.CenterVertically){ Text("Sensibilidade comutada",color=Color.White,modifier=Modifier.weight(1f)); Switch(checked=switchedEnabled,onCheckedChange={switchedEnabled=it}) }
                            if(switchedEnabled) Field("Valor da sensibilidade comutada",switched,{switched=it},true)
                            Field("Limite máximo da escala mostrado no GG",maxScale,{maxScale=it},true)
                            Field("Passo por ajuste no laboratório",step,{step=it},true)
                        }
                        CardBlock("ESTABILIDADE E RESPOSTA"){
                            Row(verticalAlignment=Alignment.CenterVertically){
                                Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(2.dp)){
                                    Text("Anti-tremer ativo",color=Color.White,fontWeight=FontWeight.Medium)
                                    Text(if(antiShake) "Ativado no GG / mapeador" else "Desativado no GG / mapeador",color=Muted,style=MaterialTheme.typography.bodySmall)
                                }
                                Switch(checked=antiShake,onCheckedChange={antiShake=it})
                            }
                            Text("Este controle registra a opção do seu mapeador. O HAZE não consegue ligar/desligar o anti-tremer dentro do GG.",color=Muted,style=MaterialTheme.typography.bodySmall)
                            Field("Suavização (se existir na sua versão)",smoothing,{smoothing=it},false)
                            Field("Zona morta (se existir)",deadzone,{deadzone=it},false)
                            Field("Curva de resposta (se existir)",curve,{curve=it},false)
                            Field("Comportamento do botão de mira",aimButton,{aimButton=it},false)
                            Field("Perfil / layout do controle",controlProfile,{controlProfile=it},false)
                        }
                        CardBlock("OBSERVAÇÕES DO SEU PRESET") { Field("Anotações livres",extraNotes,{extraNotes=it},false) }
                        SaveButton { store.saveMapping(profile); message="Configurações do GG salvas." }
                        SaveMessage(message)
                    }
                    2 -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(13.dp)){
                        CardBlock("RESOLUÇÃO DA SECOND SCREEN"){
                            Field("Largura (px)",secondWidth,{secondWidth=it},true)
                            Field("Altura (px)",secondHeight,{secondHeight=it},true)
                            Field("Taxa de atualização da tela (Hz)",secondRefresh,{secondRefresh=it},true)
                            Text("Informe a resolução efetiva da tela usada pelo mapeador/second screen. Ex.: largura e altura exibidas nas configurações do app ou da tela. Não vamos presumir um padrão.",color=Muted,style=MaterialTheme.typography.bodySmall)
                        }
                        CardBlock("FORMATO E ESCALA"){
                            Text("Orientação da tela",color=Muted,style=MaterialTheme.typography.labelSmall)
                            ChoiceRow(listOf("Paisagem","Retrato","Automática"),orientation){orientation=it}
                            Field("Escala / zoom da second screen (se houver)",screenScale,{screenScale=it},false)
                        }
                        CardBlock("NOTA DE COMPATIBILIDADE"){
                            Text("A resolução pode mudar a área útil e o alinhamento do mapeamento. Depois de alterar resolução, confira novamente HUD, posição dos botões e escala do mapa de teclas no GG.",color=Muted,style=MaterialTheme.typography.bodySmall)
                        }
                        SaveButton { store.saveMapping(profile); message="Configurações da second screen salvas." }
                        SaveMessage(message)
                    }
                    3 -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(13.dp)){
                        CardBlock("LABORATÓRIO DE CALIBRAÇÃO") {
                            Text("Siga uma sequência de testes. Faça cada etapa sem alterar DPI, resolução ou aceleração entre tentativas.",color=Muted,style=MaterialTheme.typography.bodySmall)
                            listOf("Puxada curta","Puxada longa","Microajuste","Rastreamento lateral","Diagonal","Repetibilidade").forEachIndexed { i, label ->
                                Row(Modifier.fillMaxWidth().background(if(testType==label) DeepPurple.copy(alpha=.28f) else Color(0xFF211C2D),RoundedCornerShape(14.dp)).clickable { testType=label }.padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                                    Text("0${i+1}",color=Violet,fontWeight=FontWeight.Bold,modifier=Modifier.padding(end=12.dp)); Text(label,color=Color.White,modifier=Modifier.weight(1f)); if(testType==label) Text("SELECIONADO",color=Violet,fontSize=9.sp)
                                }
                            }
                            Button(onClick={tab=5},modifier=Modifier.fillMaxWidth()) { Text("ABRIR ÁREA DE ARRASTO AMPLIADA") }
                        }
                        CardBlock("FEEDBACK DETALHADO DO JOGO") {
                            Text("Responda com base no que acontece no Free Fire, não apenas na sensação do movimento dentro do HAZE.",color=Muted,style=MaterialTheme.typography.bodySmall)
                            Text("1. Como a mira se comporta?",color=Color.White,fontWeight=FontWeight.Medium); ChoiceRow(listOf("Oscila / treme","Estável","Pesada / lenta"),feedbackStability){feedbackStability=it}
                            Text("2. Em qual direção percebe o problema?",color=Color.White,fontWeight=FontWeight.Medium); ChoiceRow(listOf("Horizontal","Vertical","Horizontal e vertical"),feedbackDirection){feedbackDirection=it}
                            Text("3. Em qual distância?",color=Color.White,fontWeight=FontWeight.Medium); ChoiceRow(listOf("Puxada curta","Puxada média","Puxada longa"),feedbackDistance){feedbackDistance=it}
                            Text("4. Em qual situação?",color=Color.White,fontWeight=FontWeight.Medium); ChoiceRow(listOf("Mira livre / geral","Red Dot","2x / 4x","AWM / sniper"),feedbackScope){feedbackScope=it}
                            Text("5. O resultado se repete?",color=Color.White,fontWeight=FontWeight.Medium); ChoiceRow(listOf("Varia entre tentativas","Quase sempre igual","Só falha às vezes"),feedbackConsistency){feedbackConsistency=it}
                            Text("Resumo: $feedbackStability • $feedbackDirection • $feedbackDistance • $feedbackScope • $feedbackConsistency",color=Violet,style=MaterialTheme.typography.bodySmall)
                        }
                        CardBlock("TESTE DE MOVIMENTO (PRÉVIA)"){
                            Text("Faça uma puxada com o mouse dentro da área. O HAZE registra o movimento recebido enquanto está aberto; isso não mede diretamente a câmera do Free Fire.",color=Muted,style=MaterialTheme.typography.bodySmall)
                            val target=Offset(canvasSize.width*.76f,canvasSize.height*.35f)
                            Canvas(Modifier.fillMaxWidth().height(220.dp).background(Color(0xFF090910),RoundedCornerShape(14.dp)).onSizeChanged{canvasSize=it}.pointerInput(canvasSize){
                                val buffer=ArrayList<MotionSample>(256)
                                detectDragGestures(onDragStart={p->buffer.clear();buffer.add(MotionSample(p.x,p.y,System.currentTimeMillis()))},
                                    onDrag={change,_->if(change.type==PointerType.Mouse){buffer.add(MotionSample(change.position.x,change.position.y,System.currentTimeMillis()));change.consume()}},
                                    onDragEnd={samples=buffer.toList();val r=MotionAnalyzer.analyze(samples,target.x,target.y,30f);if(r!=null){lastMotion="${r.sampleCount} pontos • ${r.durationMs} ms • trajeto ${r.pathLengthPx.toInt()} px";motionDetail="Velocidade média ${r.averageSpeedPxPerSecond.toInt()} px/s • pico ${r.peakSpeedPxPerSecond.toInt()} px/s • linearidade ${(r.straightness*100).toInt()}% • distância do alvo ${r.endpointErrorPx.toInt()} px"}else{lastMotion="Movimento curto demais. Faça uma puxada mais longa.";motionDetail="São necessários pelo menos dois pontos de movimento."}},onDragCancel={samples=buffer.toList()})
                            }){
                                for(x in 0..size.width.toInt() step 28) drawLine(Color(0xFF292638),Offset(x.toFloat(),0f),Offset(x.toFloat(),size.height),1f)
                                for(y in 0..size.height.toInt() step 28) drawLine(Color(0xFF292638),Offset(0f,y.toFloat()),Offset(size.width,y.toFloat()),1f)
                                drawCircle(Violet.copy(alpha=.2f),43f,target);drawCircle(Violet,30f,target,style=Stroke(2f))
                                if(samples.isNotEmpty()){val p=Path().apply{moveTo(samples.first().x,samples.first().y);samples.drop(1).forEach{lineTo(it.x,it.y)}};drawPath(p,Color.White,style=Stroke(3f))}
                            }
                            Text(lastMotion,color=Violet,style=MaterialTheme.typography.labelSmall)
                            Text(motionDetail,color=Muted,style=MaterialTheme.typography.bodySmall)
                            Text("Mantenha DPI, polling rate, resolução e aceleração iguais durante testes comparativos.",color=Muted,style=MaterialTheme.typography.bodySmall)
                        }
                        CardBlock("AJUSTE COM BASE NO FEEDBACK") {
                            Text("Repita a mesma puxada no modo treinamento. Escolha somente o eixo que está ajustando e registre o resultado.",color=Muted,style=MaterialTheme.typography.bodySmall)
                            ChoiceRow(MobiladorAxis.entries.map{it.label},axis.label){selected->axis=MobiladorAxis.entries.first{it.label==selected};proposal=null}
                            if(axis==MobiladorAxis.SWITCHED&&!switchedEnabled) Text("Ative e configure a sensibilidade comutada no GG antes de ajustar este campo.",color=Muted,style=MaterialTheme.typography.bodySmall)
                            GameFeedback.entries.forEach{item->OutlinedButton(onClick={feedback=item;proposal=SensitivityOptimizer.refine(settings,axis,item);val stamp=SimpleDateFormat("dd/MM HH:mm",Locale("pt","BR")).format(Date());val report="$stamp • Feedback ${item.label} • $feedbackStability • $feedbackDirection • $feedbackDistance • $feedbackScope • $feedbackConsistency";store.addHistory(report);history.add(0,report);message=when(item){GameFeedback.HIT->"Acertou: mantenha o valor atual.";GameFeedback.UNSTABLE->"Resultado instável: repita sem alterar nada.";else->if(proposal==null)"Não foi possível gerar ajuste. Confira valor e limite máximo." else "Prévia pronta. Confira antes de aplicar."}},modifier=Modifier.fillMaxWidth()){Text(item.label)}}
                        }
                        proposal?.let{p->CardBlock("03 / AJUSTE PROPOSTO"){
                            Text("${p.axis.label}: ${format(p.before)}  →  ${format(p.after)}",color=Violet,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
                            Text(p.reason,color=Muted,style=MaterialTheme.typography.bodySmall)
                            Text("Só este eixo será alterado. Não mexa no DPI, polling rate ou aceleração durante a comparação.",color=Color.White,style=MaterialTheme.typography.bodySmall)
                            Button(onClick={
                                when(p.axis){MobiladorAxis.HORIZONTAL->horizontal=format(p.after);MobiladorAxis.VERTICAL->vertical=format(p.after);MobiladorAxis.SWITCHED->switched=format(p.after)}
                                val updated=profile.copy(sensitivityX=horizontal,sensitivityY=vertical,switchedSensitivity=switched)
                                store.saveMapping(updated)
                                val stamp=SimpleDateFormat("dd/MM HH:mm",Locale("pt","BR")).format(Date())
                                val log="$stamp • ${p.axis.label} ${format(p.before)} → ${format(p.after)} • ${feedback?.label?:"ajuste"}"
                                store.addHistory(log);history.add(0,log);while(history.size>40)history.removeAt(history.lastIndex)
                                message="Ajuste aplicado e salvo. Faça o mesmo teste novamente.";proposal=null
                            },modifier=Modifier.fillMaxWidth()){Text("APLICAR E SALVAR")}
                        }}
                        SaveMessage(message)
                    }
                    5 -> Column(Modifier.weight(1f).fillMaxSize().padding(horizontal=12.dp, vertical=8.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                        Text("ÁREA DE ARRASTO • ${testType.uppercase()}",color=Violet,fontWeight=FontWeight.Bold,letterSpacing=1.sp)
                        Text("Faça o movimento com o mouse. A área ampliada mede a trajetória recebida pelo HAZE; para avaliar a câmera, repita o mesmo gesto no modo treinamento do Free Fire.",color=Muted,style=MaterialTheme.typography.bodySmall)
                        val target=Offset(canvasSize.width*.78f,canvasSize.height*.42f)
                        Canvas(Modifier.weight(1f).fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF171124),Color(0xFF08070D))),RoundedCornerShape(22.dp)).border(1.dp,Violet.copy(alpha=.45f),RoundedCornerShape(22.dp)).onSizeChanged{canvasSize=it}.pointerInput(canvasSize,testType){
                            val buffer=ArrayList<MotionSample>(512)
                            detectDragGestures(onDragStart={p->buffer.clear();buffer.add(MotionSample(p.x,p.y,System.currentTimeMillis()))},onDrag={change,_->if(change.type==PointerType.Mouse){buffer.add(MotionSample(change.position.x,change.position.y,System.currentTimeMillis()));change.consume()}},onDragEnd={samples=buffer.toList();val r=MotionAnalyzer.analyze(samples,target.x,target.y,38f);if(r!=null){lastMotion="${r.sampleCount} pontos • ${r.durationMs} ms • ${r.pathLengthPx.toInt()} px";motionDetail="Média ${r.averageSpeedPxPerSecond.toInt()} px/s • pico ${r.peakSpeedPxPerSecond.toInt()} px/s • linearidade ${(r.straightness*100).toInt()}% • erro ${r.endpointErrorPx.toInt()} px"}else{lastMotion="Movimento insuficiente";motionDetail="Tente novamente com uma puxada mais longa."}},onDragCancel={samples=buffer.toList()})
                        }) {
                            for(x in 0..size.width.toInt() step 32) drawLine(Color(0xFF332A47),Offset(x.toFloat(),0f),Offset(x.toFloat(),size.height),1f)
                            for(y in 0..size.height.toInt() step 32) drawLine(Color(0xFF332A47),Offset(0f,y.toFloat()),Offset(size.width,y.toFloat()),1f)
                            drawCircle(Magenta.copy(alpha=.18f),54f,target);drawCircle(Violet,35f,target,style=Stroke(3f))
                            if(samples.isNotEmpty()){val path=Path().apply{moveTo(samples.first().x,samples.first().y);samples.drop(1).forEach{lineTo(it.x,it.y)}};drawPath(path,Color.White,style=Stroke(4f))}
                        }
                        Text(lastMotion,color=Violet,fontWeight=FontWeight.Bold);Text(motionDetail,color=Muted,style=MaterialTheme.typography.bodySmall)
                        OutlinedButton(onClick={samples=emptyList();lastMotion="Faça uma nova puxada";motionDetail="Aguardando movimento."},modifier=Modifier.fillMaxWidth()){Text("LIMPAR TESTE")}
                        Button(onClick={tab=3},modifier=Modifier.fillMaxWidth()){Text("VOLTAR AO LABORATÓRIO")}
                    }
                    else -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
                        CardBlock("HISTÓRICO DE CALIBRAÇÃO"){
                            if(history.isEmpty()) Text("Seus ajustes aplicados aparecerão aqui.",color=Muted,style=MaterialTheme.typography.bodySmall)
                            history.forEach{Text(it,color=Color.White,style=MaterialTheme.typography.bodySmall);HorizontalDivider(color=Color(0xFF302B40))}
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun DashboardCard(title:String,description:String,icon:androidx.compose.ui.graphics.vector.ImageVector,modifier:Modifier,wide:Boolean=false,onClick:()->Unit){
    Column(modifier.height(if(wide) 148.dp else 178.dp).background(Brush.linearGradient(listOf(Color(0xFF302044),Color(0xFF21182F),Color(0xFF17151F))),RoundedCornerShape(22.dp)).border(1.dp,Brush.linearGradient(listOf(Violet.copy(alpha=.48f),Magenta.copy(alpha=.18f))),RoundedCornerShape(22.dp)).clickable(onClick=onClick).padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp),horizontalAlignment=Alignment.Start){
        Box(Modifier.size(42.dp).background(Brush.linearGradient(listOf(DeepPurple,Magenta.copy(alpha=.75f))),CircleShape),contentAlignment=Alignment.Center){Icon(icon,contentDescription=null,tint=Color.White,modifier=Modifier.size(23.dp))}
        Text(title,color=Color.White,fontSize=20.sp,fontWeight=FontWeight.Bold,fontFamily=HazeFont)
        Text(description,color=Color(0xFFD0C7DF),fontSize=13.sp,lineHeight=18.sp)
    }
}

@Composable private fun SaveButton(onClick:()->Unit){Button(onClick=onClick,modifier=Modifier.fillMaxWidth()){Text("SALVAR CONFIGURAÇÕES")}}
@Composable private fun SaveMessage(message:String){if(message.isNotBlank())Text(message,color=Violet,style=MaterialTheme.typography.bodySmall)}
@Composable private fun CardBlock(title:String,content:@Composable ColumnScope.()->Unit){Column(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(20.dp)).padding(16.dp),verticalArrangement=Arrangement.spacedBy(11.dp)){Text(title,color=Color(0xFFC4AEFF),style=MaterialTheme.typography.labelLarge,letterSpacing=1.1.sp,fontWeight=FontWeight.Bold);content()}}
@Composable private fun Field(label:String,value:String,onValue:(String)->Unit,numeric:Boolean){Column(verticalArrangement=Arrangement.spacedBy(4.dp)){Text(label,color=Muted,style=MaterialTheme.typography.labelSmall);OutlinedTextField(value=value,onValueChange={raw->onValue(if(numeric)raw.filter{it.isDigit()||it=='.'||it==','}.take(12)else raw.take(120))},modifier=Modifier.fillMaxWidth(),singleLine=true,shape=RoundedCornerShape(13.dp),colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=Violet,unfocusedBorderColor=Color(0xFF393448),focusedTextColor=Color.White,unfocusedTextColor=Color.White,cursorColor=Violet))}}
@Composable private fun ChoiceRow(options:List<String>,selected:String,onSelect:(String)->Unit){Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){options.forEach{item->FilterChip(selected=item==selected,onClick={onSelect(item)},label={Text(item,fontSize=11.sp)})}}}
private fun format(value:Double):String=if(value%1.0==0.0)value.toInt().toString()else String.format(Locale.US,"%.1f",value)
