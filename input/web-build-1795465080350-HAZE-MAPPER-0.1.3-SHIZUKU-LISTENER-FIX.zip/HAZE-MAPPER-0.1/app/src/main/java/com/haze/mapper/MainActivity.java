package com.haze.mapper;

import android.app.Activity;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private TextView status, output, liveInput;
    private IBinder remote;
    private final int requestCode = 4201;
    private boolean binding = false;

    private final Shizuku.OnBinderReceivedListener binderReceived = this::refreshShizuku;
    private final Shizuku.OnBinderDeadListener binderDead = () -> runOnUiThread(() -> {
        remote = null; binding = false;
        if (status != null) { status.setText("Shizuku desconectado. Aguardando Binder…"); status.setTextColor(Color.RED); }
    });

    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder binder) {
            remote = binder; binding = false;
            runOnUiThread(() -> {
                status.setText("UserService conectado • UID " + safeUid());
                status.setTextColor(Color.rgb(100, 220, 140));
                log("Binder do motor conectado. Execute o diagnóstico para validar o UID shell/ADB.");
            });
        }
        @Override public void onServiceDisconnected(ComponentName name) {
            remote = null; binding = false;
            runOnUiThread(() -> { status.setText("UserService desconectado"); status.setTextColor(Color.RED); });
        }
    };

    private final Shizuku.OnRequestPermissionResultListener permissionListener = (code, result) -> {
        if (code != requestCode) return;
        if (result == PackageManager.PERMISSION_GRANTED) {
            status.setText("Autorizado pelo Shizuku. Iniciando motor…");
            startUserService();
        } else status.setText("Autorização recusada no Shizuku.");
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        Shizuku.addBinderReceivedListenerSticky(binderReceived);
        Shizuku.addBinderDeadListener(binderDead);
        Shizuku.addRequestPermissionResultListener(permissionListener);
        refreshShizuku();
    }

    @Override protected void onResume() { super.onResume(); refreshShizuku(); }
    private int safeUid() { try { return Shizuku.getUid(); } catch (Throwable t) { return -1; } }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 28); root.setBackgroundColor(Color.rgb(16,16,24)); scroll.addView(root);
        TextView title = text("HAZE MAPPER 0.1.3", 26, Color.WHITE); root.addView(title);
        root.addView(text("SHIZUKU BRIDGE • INPUT ENGINE TEST", 12, 0xFFB58AFF));
        status = text("Aguardando Shizuku…", 15, Color.YELLOW); gap(root); root.addView(status);
        addButton(root, "1. Solicitar autorização do Shizuku", this::requestPermissionOrStart);
        addButton(root, "2. Iniciar UserService", this::startUserService);
        addButton(root, "3. Diagnóstico ADB + dispositivos", () -> callRemote(0));
        addButton(root, "4. Listar dispositivos de entrada", () -> callRemote(1));
        addButton(root, "5. Testar toque no centro da tela", () -> {
            int x = getResources().getDisplayMetrics().widthPixels / 2;
            int y = getResources().getDisplayMetrics().heightPixels / 2;
            callRemote(2, x, y);
        });
        addButton(root, "6. Testar swipe horizontal", () -> {
            int x = getResources().getDisplayMetrics().widthPixels;
            int y = getResources().getDisplayMetrics().heightPixels / 2;
            callRemote(3, x/4, y, x*3/4, y, 350);
        });
        gap(root); root.addView(text("CAPTURA LOCAL (com esta tela aberta)", 16, Color.WHITE));
        liveInput = text("Mova o mouse ou pressione uma tecla…", 14, Color.LTGRAY); root.addView(liveInput);
        gap(root); root.addView(text("LOG", 16, Color.WHITE)); output = text("Aguardando teste.", 12, 0xFFD0D0D0); root.addView(output);
        setContentView(scroll);
    }

    private TextView text(String value, int size, int color) {
        TextView v = new TextView(this); v.setText(value); v.setTextSize(size); v.setTextColor(color); v.setPadding(0,8,0,8); return v;
    }
    private void gap(LinearLayout root) { View gap = new View(this); root.addView(gap, new LinearLayout.LayoutParams(1,12)); }
    private void addButton(LinearLayout root, String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0,6,0,6); root.addView(b,p);
    }

    private void refreshShizuku() {
        if (status == null) return;
        try {
            if (!Shizuku.pingBinder()) {
                status.setText("Binder do Shizuku indisponível. Confirme se o serviço está iniciado e volte ao app.");
                status.setTextColor(Color.YELLOW); return;
            }
            if (Shizuku.isPreV11()) { status.setText("Shizuku API anterior à v11: UserService não é suportado."); return; }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                status.setText("Shizuku conectado e autorizado • UID " + safeUid());
                status.setTextColor(Color.rgb(100,220,140));
            } else {
                status.setText("Shizuku encontrado. Toque para solicitar autorização.");
                status.setTextColor(Color.YELLOW);
            }
        } catch (Throwable t) {
            status.setText("Falha ao consultar Shizuku: " + t.getClass().getSimpleName() + " — " + t.getMessage());
            status.setTextColor(Color.RED);
        }
    }

    private void requestPermissionOrStart() {
        try {
            if (!Shizuku.pingBinder()) { refreshShizuku(); return; }
            if (Shizuku.isPreV11()) { log("Atualize o Shizuku: UserService exige API v11 ou superior."); return; }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) { startUserService(); return; }
            Shizuku.requestPermission(requestCode);
        } catch (Throwable t) { log("Solicitação Shizuku falhou: " + t); }
    }

    private void startUserService() {
        try {
            if (!Shizuku.pingBinder()) { refreshShizuku(); return; }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) { requestPermissionOrStart(); return; }
            if (binding || (remote != null && remote.isBinderAlive())) { log("Motor já está conectado ou iniciando."); return; }
            Shizuku.UserServiceArgs args = new Shizuku.UserServiceArgs(
                    new ComponentName(getPackageName(), MapperUserService.class.getName()))
                    .daemon(false).tag("haze-mapper-input-engine").version(3).processNameSuffix("engine");
            binding = true;
            status.setText("Solicitando inicialização do UserService…");
            Shizuku.bindUserService(args, connection);
        } catch (Throwable t) { binding = false; log("Falha ao iniciar UserService: " + t.getClass().getSimpleName() + ": " + t.getMessage()); }
    }

    private void callRemote(int action, int... values) {
        IBinder binder = remote;
        if (binder == null || !binder.isBinderAlive()) { log("Motor não conectado. Autorize o Shizuku e inicie o UserService."); return; }
        new Thread(() -> {
            Parcel data = Parcel.obtain(), reply = Parcel.obtain();
            String result;
            try {
                data.writeInterfaceToken(MapperUserService.DESCRIPTOR);
                int code;
                if (action == 0) code = MapperUserService.TRANSACTION_DIAGNOSTIC;
                else if (action == 1) code = MapperUserService.TRANSACTION_LIST_DEVICES;
                else if (action == 2) { code = MapperUserService.TRANSACTION_TAP; data.writeInt(values[0]); data.writeInt(values[1]); }
                else { code = MapperUserService.TRANSACTION_SWIPE; for (int value : values) data.writeInt(value); }
                boolean handled = binder.transact(code, data, reply, 0);
                if (!handled) result = "O Binder não reconheceu a operação (" + code + ").";
                else { reply.readException(); result = reply.readString(); }
            } catch (Throwable t) { result = "ERRO IPC: " + t.getClass().getSimpleName() + ": " + t.getMessage(); }
            finally { data.recycle(); reply.recycle(); }
            final String out = result;
            runOnUiThread(() -> log(out));
        }).start();
    }

    private void log(String value) { if (output != null) output.setText(value); }
    @Override public boolean dispatchGenericMotionEvent(MotionEvent event) {
        if ((event.getSource() & InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE && liveInput != null)
            liveInput.setText("MOUSE • x=" + event.getX() + " y=" + event.getY() + " • action=" + event.getAction());
        return super.dispatchGenericMotionEvent(event);
    }
    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (liveInput != null) liveInput.setText("TECLADO • " + KeyEvent.keyCodeToString(event.getKeyCode()) + " • " + (event.getAction()==KeyEvent.ACTION_DOWN?"DOWN":"UP"));
        return super.dispatchKeyEvent(event);
    }

    @Override protected void onDestroy() {
        Shizuku.removeBinderReceivedListener(binderReceived);
        Shizuku.removeBinderDeadListener(binderDead);
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        try {
            Shizuku.UserServiceArgs args = new Shizuku.UserServiceArgs(
                    new ComponentName(getPackageName(), MapperUserService.class.getName()))
                    .daemon(false).tag("haze-mapper-input-engine").version(3).processNameSuffix("engine");
            Shizuku.unbindUserService(args, connection, true);
        } catch (Throwable ignored) {}
        super.onDestroy();
    }
}
