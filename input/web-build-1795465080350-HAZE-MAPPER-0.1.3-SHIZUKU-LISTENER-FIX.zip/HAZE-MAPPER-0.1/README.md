# HAZE MAPPER 0.1.2 — Shizuku bridge rebuild

This build replaces the failing generated-AIDL dependency with a small explicit Binder protocol. It follows the official Shizuku UserService contract: the service class implements `IBinder`, is started with `Shizuku.bindUserService`, and exposes the reserved destroy transaction (`16777114`).

## Shizuku integration
- Official `ShizukuProvider` authority: `${applicationId}.shizuku`.
- Provider protected by `android.permission.INTERACT_ACROSS_USERS_FULL`.
- Sticky Binder-received and Binder-dead listeners keep UI state synchronized with Shizuku lifecycle.
- Permission result listener is registered for the Activity lifecycle.
- UserService binding is guarded against duplicate starts and uses a stable tag/version.
- Permission checks are only performed after `Shizuku.pingBinder()` succeeds.

## Test functions
- Shizuku connection and permission request.
- Start UserService and show remote Binder connection.
- Run `id`, Android release/API, `wm size`, `wm density`, and `getevent -lp` diagnostics.
- List input devices.
- Explicit tap and swipe test using the Android shell `input` command.
- Foreground-only mouse/keyboard event display.

## Important limits
- This is an integration/diagnostic build, not yet a complete game mapper.
- `input tap` and `input swipe` are discrete test commands, not continuous mouse-to-touch translation.
- Mouse/keyboard capture shown in the UI only observes events delivered to HAZE while it is foregrounded.
- Shizuku ADB identity is UID 2000, not root. Access to `/dev/input` and `/dev/uinput` is device/OS/SELinux dependent. A successful Shizuku connection does not guarantee virtual input device creation.
- No anti-cheat bypass, game memory access, or game-file modification.

## Build
Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17, compileSdk 35, minSdk 26, Shizuku API/provider 13.1.5.
Build `:app:assembleDebug`.
