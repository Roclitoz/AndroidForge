package com.haze.sensi

import android.content.Context
import com.haze.sensi.model.MappingProfile
import com.haze.sensi.model.SensitivityValues
import org.json.JSONArray
import org.json.JSONObject

/** Local-only storage for the user's mapping setup and calibration log. */
class MappingProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("haze_sensi_profiles", Context.MODE_PRIVATE)

    fun saveMapping(profile: MappingProfile) {
        val json = JSONObject().apply {
            put("appVersion", profile.appVersion)
            put("sensitivity", profile.sensitivity)
            put("sensitivityX", profile.sensitivityX)
            put("sensitivityY", profile.sensitivityY)
            put("acceleration", profile.acceleration)
            put("smoothing", profile.smoothing)
            put("deadzone", profile.deadzone)
            put("responseCurve", profile.responseCurve)
            put("aimButtonBehavior", profile.aimButtonBehavior)
            put("controlProfile", profile.controlProfile)
        }
        prefs.edit().putString("mapping_profile", json.toString()).apply()
    }

    fun loadMapping(): MappingProfile {
        val json = runCatching { JSONObject(prefs.getString("mapping_profile", "{}") ?: "{}") }.getOrDefault(JSONObject())
        return MappingProfile(
            appVersion = json.optString("appVersion"),
            sensitivity = json.optString("sensitivity"),
            sensitivityX = json.optString("sensitivityX"),
            sensitivityY = json.optString("sensitivityY"),
            acceleration = json.optString("acceleration"),
            smoothing = json.optString("smoothing"),
            deadzone = json.optString("deadzone"),
            responseCurve = json.optString("responseCurve"),
            aimButtonBehavior = json.optString("aimButtonBehavior"),
            controlProfile = json.optString("controlProfile")
        )
    }


    fun saveSensitivity(values: SensitivityValues) {
        val json = JSONObject().apply {
            put("general", values.general)
            put("redDot", values.redDot)
            put("scope2x", values.scope2x)
            put("scope4x", values.scope4x)
            put("sniper", values.sniper)
            put("freeLook", values.freeLook)
        }
        prefs.edit().putString("free_fire_sensitivity", json.toString()).apply()
    }

    fun loadSensitivity(): SensitivityValues {
        val json = runCatching { JSONObject(prefs.getString("free_fire_sensitivity", "{}") ?: "{}") }.getOrDefault(JSONObject())
        return SensitivityValues(
            general = json.optInt("general", 80),
            redDot = json.optInt("redDot", 75),
            scope2x = json.optInt("scope2x", 70),
            scope4x = json.optInt("scope4x", 60),
            sniper = json.optInt("sniper", 45),
            freeLook = json.optInt("freeLook", 65)
        ).bounded()
    }

    fun addHistory(summary: String) {
        val entries = runCatching { JSONArray(prefs.getString("calibration_history", "[]") ?: "[]") }.getOrDefault(JSONArray())
        val updated = JSONArray().put(summary).also { out ->
            for (i in 0 until minOf(entries.length(), 19)) out.put(entries.getString(i))
        }
        prefs.edit().putString("calibration_history", updated.toString()).apply()
    }

    fun loadHistory(): List<String> {
        val entries = runCatching { JSONArray(prefs.getString("calibration_history", "[]") ?: "[]") }.getOrDefault(JSONArray())
        return (0 until entries.length()).mapNotNull { i -> entries.optString(i).takeIf(String::isNotBlank) }
    }
}
