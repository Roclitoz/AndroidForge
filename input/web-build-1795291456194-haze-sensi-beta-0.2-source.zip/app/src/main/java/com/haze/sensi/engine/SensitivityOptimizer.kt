package com.haze.sensi.engine

import com.haze.sensi.model.*

enum class GameFeedback(val label: String, val description: String) {
    OVERSHOOT("Passou do alvo", "A mira ultrapassou o ponto desejado."),
    UNDERSHOOT("Ficou abaixo", "A mira não chegou ao ponto desejado."),
    HIT("Acertou", "A mira chegou ao ponto desejado."),
    UNSTABLE("Instável", "O resultado variou entre as tentativas.")
}

object SensitivityOptimizer {
    /** Analisa a entrada no laboratório. Não altera valores sem feedback obtido no jogo. */
    fun recommend(
        current: SensitivityValues,
        metrics: MotionMetrics,
        preferences: AimPreferences
    ): CalibrationResult {
        val sufficient = metrics.sampleCount >= 8 && metrics.durationMs >= 100
        val explanation = when {
            !sufficient -> "Amostra curta. Faça uma puxada mais longa para registrar um perfil de movimento confiável."
            metrics.straightness < 0.55f -> "Sua trajetória teve bastante desvio. Repita tentando manter uma linha mais consistente."
            metrics.peakSpeedPxPerSecond > 0 && metrics.peakSpeedPxPerSecond > metrics.averageSpeedPxPerSecond * 2.5f -> "Foi detectado um pico de velocidade. Tente repetir a puxada com aceleração mais controlada."
            else -> "Movimento registrado. Agora teste sua configuração atual no Free Fire e informe como a mira se comportou para gerar um ajuste real."
        }
        return CalibrationResult(metrics, current.bounded(), explanation,
            if (sufficient) "Perfil de movimento registrado" else "Insuficiente — repita")
    }

    /** Ajuste heurístico pequeno, baseado no retorno explícito do jogador dentro do Free Fire. */
    fun refine(current: SensitivityValues, feedback: GameFeedback, preferences: AimPreferences): SensitivityValues {
        val step = when (preferences.goal) {
            AimGoal.PRECISION -> 1
            AimGoal.SPEED, AimGoal.AGGRESSIVE -> 3
            AimGoal.BALANCED -> 2
        }
        fun tune(value: Int): Int = when (feedback) {
            GameFeedback.OVERSHOOT -> (value - step).coerceIn(0, 100)
            GameFeedback.UNDERSHOOT -> (value + step).coerceIn(0, 100)
            GameFeedback.HIT, GameFeedback.UNSTABLE -> value.coerceIn(0, 100)
        }
        return when (feedback) {
            GameFeedback.HIT, GameFeedback.UNSTABLE -> current.bounded()
            else -> current.copy(
                general = tune(current.general),
                redDot = tune(current.redDot),
                scope2x = tune(current.scope2x),
                scope4x = tune(current.scope4x),
                sniper = tune(current.sniper),
                freeLook = current.freeLook.coerceIn(0, 100)
            )
        }
    }
}
