package com.haze.sensi.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.haze.sensi.engine.MotionAnalyzer
import com.haze.sensi.engine.SensitivityOptimizer
import com.haze.sensi.model.*

private val LabViolet = Color(0xFFAA8BFF)
private val LabMuted = Color(0xFFAAA7BA)

@Composable
fun CalibrationLab(
    deviceProfile: DeviceProfile,
    preferences: AimPreferences,
    current: SensitivityValues,
    onResult: (CalibrationResult) -> Unit
) {
    var samples by remember { mutableStateOf(listOf<MotionSample>()) }
    var result by remember { mutableStateOf<CalibrationResult?>(null) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    var recording by remember { mutableStateOf(false) }
    val target = Offset(canvasSize.width * 0.76f, canvasSize.height * 0.32f)
    val radius = 31f

    Column(Modifier.fillMaxWidth().background(Color(0xFF14131D), RoundedCornerShape(20.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("HAZE LAB  /  MOVIMENTO", color = LabViolet, style = MaterialTheme.typography.labelLarge)
        Text("Faça uma puxada com o mouse", color = Color.White, style = MaterialTheme.typography.titleLarge)
        Text("Arraste do ponto inicial até o alvo. O laboratório registra somente os movimentos recebidos pelo HAZE.", color = LabMuted, style = MaterialTheme.typography.bodySmall)
        Canvas(Modifier.fillMaxWidth().height(220.dp).background(Color(0xFF090910), RoundedCornerShape(14.dp)).onSizeChanged { canvasSize = it }
            .pointerInput(canvasSize, current, preferences) {
                val buffer = ArrayList<MotionSample>(256)
                detectDragGestures(
                    onDragStart = { p -> buffer.clear(); buffer.add(MotionSample(p.x, p.y, System.currentTimeMillis())); samples = buffer.toList(); recording = true; result = null },
                    onDrag = { change, _ ->
                        if (change.type == PointerType.Mouse && recording) {
                            buffer.add(MotionSample(change.position.x, change.position.y, System.currentTimeMillis()))
                            // Atualiza o desenho em lotes para evitar recomposição em cada evento do mouse.
                            if (buffer.size % 4 == 0) samples = buffer.toList()
                            change.consume()
                        }
                    },
                    onDragEnd = {
                        recording = false
                        samples = buffer.toList()
                        MotionAnalyzer.analyze(samples, target.x, target.y, radius)?.let { metrics ->
                            SensitivityOptimizer.recommend(current, metrics, preferences).also { result = it; onResult(it) }
                        }
                    },
                    onDragCancel = { recording = false; samples = buffer.toList() }
                )
            }
        ) {
            val grid = Color(0xFF292638)
            for (x in 0..size.width.toInt() step 28) drawLine(grid, Offset(x.toFloat(), 0f), Offset(x.toFloat(), size.height), 1f)
            for (y in 0..size.height.toInt() step 28) drawLine(grid, Offset(0f, y.toFloat()), Offset(size.width, y.toFloat()), 1f)
            drawCircle(LabViolet.copy(alpha = .16f), radius + 13f, target)
            drawCircle(LabViolet, radius, target, style = androidx.compose.ui.graphics.drawscope.Stroke(2f))
            drawCircle(LabViolet, 3f, target)
            if (samples.isNotEmpty()) {
                val path = Path().apply { moveTo(samples.first().x, samples.first().y); samples.drop(1).forEach { lineTo(it.x, it.y) } }
                drawPath(path, Color.White, style = androidx.compose.ui.graphics.drawscope.Stroke(3f))
                drawCircle(Color.White, 5f, Offset(samples.first().x, samples.first().y))
                drawCircle(LabViolet, 5f, Offset(samples.last().x, samples.last().y))
            }
        }
        Text(if (recording) "Capturando movimento…" else "Mapping: ${deviceProfile.mappingApp}  •  ${samples.size} pontos", color = LabMuted, style = MaterialTheme.typography.labelSmall)
        result?.let { r ->
            HorizontalDivider(color = Color(0xFF302B40))
            Text("ANÁLISE DA TENTATIVA", color = LabViolet, style = MaterialTheme.typography.labelLarge)
            MetricLine("Distância percorrida", "${r.metrics.pathLengthPx.toInt()} px")
            MetricLine("Velocidade média", "${r.metrics.averageSpeedPxPerSecond.toInt()} px/s")
            MetricLine("Retidão da trajetória", "${(r.metrics.straightness * 100).toInt()}%")
            MetricLine("Erro até o alvo", "${r.metrics.endpointErrorPx.toInt()} px")
            Text(r.explanation, color = Color.White, style = MaterialTheme.typography.bodySmall)
            Text("Próximo passo: teste no Free Fire e registre o resultado na aba Resultados.", color = LabViolet, style = MaterialTheme.typography.bodySmall)
        }
        OutlinedButton(onClick = { samples = emptyList(); result = null }, modifier = Modifier.fillMaxWidth()) { Text("LIMPAR TESTE") }
    }
}

@Composable
private fun MetricLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = LabMuted, style = MaterialTheme.typography.bodySmall)
        Text(value, color = Color.White, style = MaterialTheme.typography.bodySmall)
    }
}
