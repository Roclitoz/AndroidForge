# HAZE SENSI — HAZE AI Architecture 1.0

Android app starter in Kotlin + Jetpack Compose.

## Implemented
- Domain models for device, mapping, aim goals, drag profiles, motion samples and sensitivity values (0–100).
- Calibration laboratory UI with mouse-drag capture while HAZE is foregrounded.
- Motion analysis: path length, net displacement, duration, average/peak speed, straightness and endpoint error.
- Device-profile fields and basic input validation component.
- Optimizer interface with a conservative baseline that does not fabricate a sensitivity correction from cursor position alone.

## Technical limitations and next work
- The laboratory captures mouse drags delivered to HAZE while it is foregrounded. It does not intercept GG Mouse Pro VIP or Free Fire input.
- GG Mouse Pro 3 VIP is the reference mapping environment, not an integrated SDK or confirmed compatibility integration.
- The current optimizer is an architecture baseline, not a trained AI model. Mouse movement measured on HAZE's own canvas is not equivalent to in-game camera movement.
- To calculate meaningful sensitivity recommendations, the next iteration needs controlled in-game validation or a user-reported outcome (undershoot / overshoot / stable), repeated trials, and mapping-specific scale calibration.
- Values use an internal 0–100 scale. Any conversion to the game's scale must be checked against the installed game version.
- No hidden input capture, accessibility interception, game-file modification, or anti-cheat bypass is used.

## Build
Open the project in Android Studio with JDK 17, Android SDK 35 and Android Gradle Plugin 8.7.3 support, then use Build > Build APK(s).

## Mapping profile and local calibration history (increment 1.1)

The setup screen now includes a dedicated GG Mouse Pro 3 VIP profile with optional fields for app version, overall/X/Y mapping sensitivity, acceleration, smoothing, deadzone, response curve, aim-button behavior, and Free Fire control profile. These labels are descriptive fields: the user should enter the values/options actually shown by their installed mapping-app version; unavailable settings can remain blank.

The mapping profile and the latest 20 HAZE laboratory sessions are stored locally using Android SharedPreferences. No account or cloud sync is implemented. The history currently records HAZE laboratory measurements, not automatically observed Free Fire outcomes. In-game feedback and device-profile persistence remain future work.


## BETA 0.2

- Navegação principal em três abas: Configuração, Calibração e Resultados.
- Categorias separadas para dispositivo, mouse e GG Mouse Pro 3 VIP.
- Sensibilidades atuais do Free Fire salvas localmente no aparelho.
- Ajustes pequenos baseados no feedback informado após testar no jogo.
- Laboratório registra o movimento recebido pelo próprio HAZE e apresenta métricas.

**Limitação importante:** o HAZE não captura a câmera do Free Fire nem altera o GG Mouse. A puxada feita dentro do laboratório não representa diretamente a resposta da mira no jogo; por isso, os ajustes dependem do feedback real do jogador.
