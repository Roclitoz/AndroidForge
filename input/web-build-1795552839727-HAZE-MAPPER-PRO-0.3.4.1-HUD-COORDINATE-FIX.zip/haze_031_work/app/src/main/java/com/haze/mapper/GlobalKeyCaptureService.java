package com.haze.mapper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.view.KeyEvent;
import android.hardware.input.InputManager;
import android.view.accessibility.AccessibilityEvent;
import android.os.Handler;
import android.os.Looper;
import android.graphics.PixelFormat;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.MotionEvent;
import android.view.View;
import android.util.DisplayMetrics;
import java.util.HashSet;
import java.util.Set;

/** Global physical-key observer and normalized control-state calculator.
 * Events are deliberately not consumed: the foreground game keeps receiving them.
 */
public final class GlobalKeyCaptureService extends AccessibilityService {
    private static final String PREFS = "haze_global_input";
    private static final String PROFILE = "haze_profile";
    private final Set<Integer> held = new HashSet<>();
    private final java.util.Map<Integer, Integer> keyDeviceIds = new java.util.HashMap<>();
    private final KeyStateManager keyStateManager = new KeyStateManager();
    private InputManager inputManager;
    private final InputManager.InputDeviceListener inputDeviceListener = new InputManager.InputDeviceListener() {
        @Override public void onInputDeviceAdded(int deviceId) { }
        @Override public void onInputDeviceChanged(int deviceId) { }
        @Override public void onInputDeviceRemoved(int deviceId) { releaseDeviceKeys(deviceId); }
    };
    private float lastJoystickX = 0f, lastJoystickY = 0f;
    private boolean lastJoystickActive = false;
    private boolean lastVistaMode = false;
    private static volatile GlobalKeyCaptureService instance;
    private final Handler heartbeat = new Handler(Looper.getMainLooper());
    private final Runnable heartbeatTask = new Runnable() { @Override public void run() {
        android.content.SharedPreferences p=getSharedPreferences(PREFS,MODE_PRIVATE);
        if(p.getBoolean("joystick_enabled",false) && !p.getBoolean("vista_mode",false)) {
            float x=p.getFloat("global_x",0f), y=p.getFloat("global_y",0f);
            if(x!=0f || y!=0f) {
                android.content.SharedPreferences c=getSharedPreferences("haze_joystick",MODE_PRIVATE);
                String backend=MainActivity.pushGlobalJoystick(x,y,true,c.getFloat("cx",.16f),c.getFloat("cy",.78f),c.getFloat("rx",.055f),c.getFloat("ry",.085f),c.getInt("transform",0));
                getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString("last_backend_result",backend).apply();
                heartbeat.postDelayed(this,45);
            }
        }
    }};
    private WindowManager windowManager;
    private final java.util.Map<String,View> hudViews = new java.util.HashMap<>();

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        instance=this;
        inputManager = (InputManager)getSystemService(INPUT_SERVICE);
        if (inputManager != null) inputManager.registerInputDeviceListener(inputDeviceListener, heartbeat);
        AccessibilityServiceInfo info = getServiceInfo();
        if (info != null) {
            info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
            setServiceInfo(info);
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("service_connected", true)
                .putLong("connected_at", System.currentTimeMillis())
                .putFloat("global_x", 0f).putFloat("global_y", 0f)
                .putString("held_keys", "").apply();
        held.clear();
        if(getSharedPreferences("haze_hud",MODE_PRIVATE).getBoolean("overlay_enabled",false)) showHudOverlay();
    }

    public static void setHudOverlayEnabled(boolean enabled) {
        GlobalKeyCaptureService s=instance;
        if(s==null)return;
        s.getSharedPreferences("haze_hud",MODE_PRIVATE).edit().putBoolean("overlay_enabled",enabled).apply();
        if(enabled)s.showHudOverlay();else s.hideHudOverlay();
    }
    public static void refreshHudOverlay() {
        GlobalKeyCaptureService s=instance;
        if(s!=null && s.getSharedPreferences("haze_hud",MODE_PRIVATE).getBoolean("overlay_enabled",false)) {
            s.hideHudOverlay(); s.showHudOverlay();
        }
    }

    private void showHudOverlay() {
        if(windowManager==null)windowManager=(WindowManager)getSystemService(WINDOW_SERVICE);
        if(windowManager==null || !hudViews.isEmpty())return;
        String[] ids={"FIRE","JUMP","RELOAD","VISTA"};
        int[] defaultsX={86,75,88,50}, defaultsY={76,62,48,90};
        DisplayMetrics dm=new DisplayMetrics();windowManager.getDefaultDisplay().getRealMetrics(dm);
        android.content.SharedPreferences p=getSharedPreferences("haze_hud",MODE_PRIVATE);
        float scale=p.getFloat("global_scale",1f), opacity=p.getFloat("global_opacity",.85f);
        for(int i=0;i<ids.length;i++){
            final String id=ids[i];
            float xr=p.getFloat(id+"_x",defaultsX[i]/100f), yr=p.getFloat(id+"_y",defaultsY[i]/100f);
            int[] mapped = HudCoordinateMapper.toScreen(p, windowManager, xr, yr);
            int size=Math.max(44,Math.round(74*scale));
            TextView v=new TextView(this);v.setText(id);v.setTextColor(Color.WHITE);v.setTextSize(11);v.setGravity(Gravity.CENTER);
            GradientDrawable bg=new GradientDrawable();bg.setShape(GradientDrawable.OVAL);bg.setColor(0xCC252B3A);bg.setStroke(2,0xFFB69AFF);v.setBackground(bg);v.setAlpha(opacity);
            WindowManager.LayoutParams lp=new WindowManager.LayoutParams(size,size,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
            lp.gravity=Gravity.TOP|Gravity.LEFT;lp.x=Math.max(0,Math.min(dm.widthPixels-size,mapped[0]-size/2));lp.y=Math.max(0,Math.min(dm.heightPixels-size,mapped[1]-size/2));
            v.setOnTouchListener((view,event)->{
                int sx=Math.round(lp.x+size/2f), sy=Math.round(lp.y+size/2f);
                if(event.getAction()==MotionEvent.ACTION_DOWN){
                    if("VISTA".equals(id))return true;
                    MainActivity.pushHudTouch(0,sx,sy,dm.widthPixels,dm.heightPixels,getSharedPreferences("haze_joystick",MODE_PRIVATE).getInt("transform",0));return true;
                }
                if(event.getAction()==MotionEvent.ACTION_UP||event.getAction()==MotionEvent.ACTION_CANCEL){
                    if("VISTA".equals(id)){toggleVistaMode();return true;}
                    MainActivity.pushHudTouch(1,sx,sy,dm.widthPixels,dm.heightPixels,getSharedPreferences("haze_joystick",MODE_PRIVATE).getInt("transform",0));return true;
                }
                return true;
            });
            try{windowManager.addView(v,lp);hudViews.put(id,v);}catch(Throwable ignored){}
        }
    }

    private void hideHudOverlay(){
        if(windowManager!=null)for(View v:new java.util.ArrayList<>(hudViews.values()))try{windowManager.removeView(v);}catch(Throwable ignored){}
        hudViews.clear();
    }

    private void toggleVistaMode() {
        android.content.SharedPreferences state=getSharedPreferences(PREFS,MODE_PRIVATE);
        boolean next=!state.getBoolean("vista_mode",false);
        state.edit().putBoolean("vista_mode",next).apply();
        if(next){heartbeat.removeCallbacks(heartbeatTask);MainActivity.pushGlobalJoystick(0f,0f,false);}
        else {
            int w=getSharedPreferences(PROFILE,MODE_PRIVATE).getInt("key_W",KeyEvent.KEYCODE_W);
            int a=getSharedPreferences(PROFILE,MODE_PRIVATE).getInt("key_A",KeyEvent.KEYCODE_A);
            int s=getSharedPreferences(PROFILE,MODE_PRIVATE).getInt("key_S",KeyEvent.KEYCODE_S);
            int d=getSharedPreferences(PROFILE,MODE_PRIVATE).getInt("key_D",KeyEvent.KEYCODE_D);
            VirtualStickController.State stick = VirtualStickController.evaluate(held, w, a, s, d);
            float x = stick.x, y = stick.y;
            android.content.SharedPreferences c=getSharedPreferences("haze_joystick",MODE_PRIVATE);
            MainActivity.pushGlobalJoystick(x,y,x!=0f||y!=0f,c.getFloat("cx",.16f),c.getFloat("cy",.78f),c.getFloat("rx",.055f),c.getFloat("ry",.085f),c.getInt("transform",0));
            if(x!=0f||y!=0f)heartbeat.postDelayed(heartbeatTask,45);
        }
    }

    private int actionControlId(String id) {
        switch (id) {
            case "FIRE": return 0;
            case "JUMP": return 1;
            case "RELOAD": return 2;
            default: return -1;
        }
    }

    private void sendActionContact(String id, int action) {
        int controlId = actionControlId(id);
        if (controlId < 0) return;
        android.content.SharedPreferences hud = getSharedPreferences("haze_hud", MODE_PRIVATE);
        DisplayMetrics dm = new DisplayMetrics();
        if (windowManager == null) windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
        if (windowManager == null) return;
        windowManager.getDefaultDisplay().getRealMetrics(dm);
        if (dm.widthPixels <= 0 || dm.heightPixels <= 0) return;
        float defaultX = "FIRE".equals(id) ? .86f : ("JUMP".equals(id) ? .75f : .88f);
        float defaultY = "FIRE".equals(id) ? .76f : ("JUMP".equals(id) ? .62f : .48f);
        float nx = hud.getFloat(id + "_x", defaultX);
        float ny = hud.getFloat(id + "_y", defaultY);
        int[] mapped = HudCoordinateMapper.toScreen(hud, windowManager, nx, ny);
        int x = mapped[0], y = mapped[1], screenW = mapped[2], screenH = mapped[3];
        int transform = getSharedPreferences("haze_joystick", MODE_PRIVATE).getInt("transform", 0);
        String result = MainActivity.pushGlobalKeyTouch(controlId, action, x, y, screenW, screenH, transform);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString("last_key_backend_result", result)
                .putString("last_action_control", id)
                .putString("last_action_phase", action == 0 ? "DOWN" : "UP")
                .putInt("last_action_x", x).putInt("last_action_y", y)
                .putInt("last_action_screen_w", screenW).putInt("last_action_screen_h", screenH)
                .apply();
    }

    private String actionIdForControl(int controlId) {
        switch (controlId) {
            case 0: return "FIRE";
            case 1: return "JUMP";
            case 2: return "RELOAD";
            default: return null;
        }
    }

    private void processActionKey(int code, boolean down, int repeatCount) {
        if (down) {
            if (repeatCount > 0) return;
            android.content.SharedPreferences profile = getSharedPreferences(PROFILE, MODE_PRIVATE);
            String[] ids = {"FIRE", "JUMP", "RELOAD"};
            java.util.ArrayList<Integer> mapped = new java.util.ArrayList<>();
            for (String id : ids) if (profile.getInt("key_" + id, defaultActionKey(id)) == code) mapped.add(actionControlId(id));
            int[] controls = new int[mapped.size()];
            for (int i = 0; i < mapped.size(); i++) controls[i] = mapped.get(i);
            StringBuilder mappedNames = new StringBuilder();
            for (int controlId : controls) {
                String name = actionIdForControl(controlId);
                if (name != null) { if (mappedNames.length() > 0) mappedNames.append(','); mappedNames.append(name); }
            }
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString("last_action_mapping", mappedNames.length() == 0 ? "SEM MAPEAMENTO" : mappedNames.toString())
                    .apply();
            for (int controlId : keyStateManager.press(code, controls, false)) {
                String id = actionIdForControl(controlId);
                if (id != null) sendActionContact(id, 0);
            }
        } else {
            for (int controlId : keyStateManager.release(code)) {
                String id = actionIdForControl(controlId);
                if (id != null) sendActionContact(id, 1);
            }
        }
    }

    private int defaultActionKey(String id) {
        if ("JUMP".equals(id)) return KeyEvent.KEYCODE_SPACE;
        if ("RELOAD".equals(id)) return KeyEvent.KEYCODE_R;
        if ("FIRE".equals(id)) return KeyEvent.KEYCODE_BUTTON_R1;
        return KeyEvent.KEYCODE_UNKNOWN;
    }

    @Override protected boolean onKeyEvent(KeyEvent event) {
        if (event == null || (event.getAction() != KeyEvent.ACTION_DOWN && event.getAction() != KeyEvent.ACTION_UP)) return false;
        final int code = event.getKeyCode();
        final boolean down = event.getAction() == KeyEvent.ACTION_DOWN;
        boolean newlyPressed = false;
        if (down) {
            newlyPressed = held.add(code);
            keyDeviceIds.put(code, event.getDeviceId());
        } else {
            held.remove(code);
            keyDeviceIds.remove(code);
        }

        android.content.SharedPreferences profile = getSharedPreferences(PROFILE, MODE_PRIVATE);
        int w = profile.getInt("key_W", KeyEvent.KEYCODE_W);
        int a = profile.getInt("key_A", KeyEvent.KEYCODE_A);
        int s = profile.getInt("key_S", KeyEvent.KEYCODE_S);
        int d = profile.getInt("key_D", KeyEvent.KEYCODE_D);
        int vista = profile.getInt("vista_key", KeyEvent.KEYCODE_F1);
        boolean movementKey = code == w || code == a || code == s || code == d;
        boolean vistaToggled = down && newlyPressed && code == vista;

        // Action contacts are independent from the joystick contact and from one another.
        processActionKey(code, down, event.getRepeatCount());

        android.content.SharedPreferences state = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (vistaToggled) state.edit().putBoolean("vista_mode", !state.getBoolean("vista_mode", false)).apply();
        VirtualStickController.State stick = VirtualStickController.evaluate(held, w, a, s, d);
        float x = stick.x, y = stick.y;
        boolean vistaMode = state.getBoolean("vista_mode", false);
        boolean joystickEnabled = state.getBoolean("joystick_enabled", false);

        // Physical action keys must never restart the joystick heartbeat or resend its vector.
        if (joystickEnabled && (movementKey || vistaToggled)) {
            boolean active = !vistaMode && (x != 0f || y != 0f);
            boolean changed = x != lastJoystickX || y != lastJoystickY || active != lastJoystickActive || vistaMode != lastVistaMode;
            if (changed) {
                android.content.SharedPreferences c = getSharedPreferences("haze_joystick", MODE_PRIVATE);
                String backend = MainActivity.pushGlobalJoystick(x, y, active,
                        c.getFloat("cx", .16f), c.getFloat("cy", .78f),
                        c.getFloat("rx", .055f), c.getFloat("ry", .085f), c.getInt("transform", 0));
                state.edit().putString("last_backend_result", backend).apply();
                lastJoystickX = x; lastJoystickY = y; lastJoystickActive = active; lastVistaMode = vistaMode;
                heartbeat.removeCallbacks(heartbeatTask);
                if (active) heartbeat.postDelayed(heartbeatTask, 45);
            }
        }

        StringBuilder keys = new StringBuilder();
        for (Integer key : held) {
            if (keys.length() > 0) keys.append(',');
            keys.append(KeyEvent.keyCodeToString(key));
        }
        int count = state.getInt("event_count", 0) + 1;
        state.edit().putInt("last_keycode", code)
                .putInt("last_action", event.getAction())
                .putInt("last_device", event.getDeviceId())
                .putInt("event_count", count)
                .putLong("last_event_at", System.currentTimeMillis())
                .putFloat("global_x", x).putFloat("global_y", y)
                .putString("held_keys", keys.toString())
                .putBoolean("movement_active", x != 0f || y != 0f)
                .apply();
        // Observation/calculation only. Do not swallow the physical event.
        return false;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence packageName = event.getPackageName();
        if (packageName == null) return;
        String pkg = packageName.toString();
        boolean freeFire = "com.dts.freefireth".equals(pkg) || "com.dts.freefiremax".equals(pkg);
        if (!freeFire) releaseActionContacts();
    }

    private void releaseActionContacts() {
        for (int controlId : keyStateManager.releaseAll()) {
            String id = actionIdForControl(controlId);
            if (id != null) sendActionContact(id, 1);
        }
    }

    private void releaseDeviceKeys(int deviceId) {
        java.util.ArrayList<Integer> removed = new java.util.ArrayList<>();
        for (java.util.Map.Entry<Integer, Integer> entry : keyDeviceIds.entrySet()) {
            if (entry.getValue() == deviceId) removed.add(entry.getKey());
        }
        if (removed.isEmpty()) return;
        android.content.SharedPreferences movementProfile = getSharedPreferences(PROFILE, MODE_PRIVATE);
        int mappedW = movementProfile.getInt("key_W", KeyEvent.KEYCODE_W);
        int mappedA = movementProfile.getInt("key_A", KeyEvent.KEYCODE_A);
        int mappedS = movementProfile.getInt("key_S", KeyEvent.KEYCODE_S);
        int mappedD = movementProfile.getInt("key_D", KeyEvent.KEYCODE_D);
        boolean movementChanged = false;
        for (int code : removed) {
            keyDeviceIds.remove(code);
            held.remove(code);
            if (code == mappedW || code == mappedA || code == mappedS || code == mappedD) movementChanged = true;
            for (int controlId : keyStateManager.release(code)) {
                String id = actionIdForControl(controlId);
                if (id != null) sendActionContact(id, 1);
            }
        }
        if (movementChanged) {
            android.content.SharedPreferences profile = getSharedPreferences(PROFILE, MODE_PRIVATE);
            int w = profile.getInt("key_W", KeyEvent.KEYCODE_W), a = profile.getInt("key_A", KeyEvent.KEYCODE_A);
            int s = profile.getInt("key_S", KeyEvent.KEYCODE_S), d = profile.getInt("key_D", KeyEvent.KEYCODE_D);
            VirtualStickController.State stick = VirtualStickController.evaluate(held, w, a, s, d);
            float x = stick.x, y = stick.y;
            boolean vistaMode = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("vista_mode", false);
            boolean active = !vistaMode && (x != 0f || y != 0f);
            if (x != lastJoystickX || y != lastJoystickY || active != lastJoystickActive) {
                android.content.SharedPreferences c = getSharedPreferences("haze_joystick", MODE_PRIVATE);
                MainActivity.pushGlobalJoystick(x, y, active, c.getFloat("cx", .16f), c.getFloat("cy", .78f),
                        c.getFloat("rx", .055f), c.getFloat("ry", .085f), c.getInt("transform", 0));
                lastJoystickX = x; lastJoystickY = y; lastJoystickActive = active;
                heartbeat.removeCallbacks(heartbeatTask);
                if (active) heartbeat.postDelayed(heartbeatTask, 45);
            }
            StringBuilder remaining = new StringBuilder();
            for (Integer key : held) {
                if (remaining.length() > 0) remaining.append(',');
                remaining.append(KeyEvent.keyCodeToString(key));
            }
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putFloat("global_x", x).putFloat("global_y", y)
                    .putBoolean("movement_active", x != 0f || y != 0f)
                    .putString("held_keys", remaining.toString()).apply();
        }
    }

    @Override public void onInterrupt() { clearHeldState(); }

    private void clearHeldState() {
        held.clear();
        keyDeviceIds.clear();
        heartbeat.removeCallbacks(heartbeatTask);
        releaseActionContacts();
        MainActivity.pushGlobalJoystick(0f, 0f, false);
        lastJoystickX = 0f; lastJoystickY = 0f; lastJoystickActive = false;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putFloat("global_x", 0f).putFloat("global_y", 0f)
                .putBoolean("movement_active", false).putString("held_keys", "").apply();
    }

    private void unregisterInputDeviceListener() {
        if (inputManager != null) {
            try { inputManager.unregisterInputDeviceListener(inputDeviceListener); } catch (Throwable ignored) { }
            inputManager = null;
        }
    }

    @Override public void onDestroy() {
        clearHeldState(); unregisterInputDeviceListener(); hideHudOverlay(); instance=null; super.onDestroy();
    }

    @Override public boolean onUnbind(android.content.Intent intent) {
        clearHeldState(); unregisterInputDeviceListener(); hideHudOverlay(); instance=null;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("service_connected", false).apply();
        return super.onUnbind(intent);
    }
}
