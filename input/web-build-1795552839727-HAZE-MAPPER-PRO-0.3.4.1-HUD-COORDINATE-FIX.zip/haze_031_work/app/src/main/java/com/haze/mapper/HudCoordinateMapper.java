package com.haze.mapper;

import android.content.SharedPreferences;
import android.util.DisplayMetrics;
import android.view.WindowManager;

/** Converts normalized positions from the HUD editor preview into real display coordinates. */
public final class HudCoordinateMapper {
    private HudCoordinateMapper() {}

    public static int[] toScreen(SharedPreferences hud, WindowManager wm, float nx, float ny) {
        DisplayMetrics dm = new DisplayMetrics();
        if (wm != null) wm.getDefaultDisplay().getRealMetrics(dm);
        int screenW = Math.max(1, dm.widthPixels);
        int screenH = Math.max(1, dm.heightPixels);

        boolean valid = hud.getBoolean("editor_geometry_valid", false);
        int left = hud.getInt("editor_left", 0);
        int top = hud.getInt("editor_top", 0);
        int width = hud.getInt("editor_width", 0);
        int height = hud.getInt("editor_height", 0);
        if (valid && width > 0 && height > 0) {
            int x = left + Math.round(clamp(nx) * width);
            int y = top + Math.round(clamp(ny) * height);
            return new int[]{clamp(x, 0, screenW - 1), clamp(y, 0, screenH - 1), screenW, screenH};
        }
        // Safe fallback for layouts created before preview geometry was recorded.
        return new int[]{clamp(Math.round(clamp(nx) * screenW), 0, screenW - 1),
                clamp(Math.round(clamp(ny) * screenH), 0, screenH - 1), screenW, screenH};
    }

    private static float clamp(float v) { return Math.max(0f, Math.min(1f, v)); }
    private static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
}
