package com.haze.sensi.model

data class DeviceProfile(
    val deviceName: String = "",
    val mouseDpi: Int? = null,
    val pollingRateHz: Int? = null,
    val androidDisplayDpi: Int? = null,
    val pointerSpeed: Int? = null,
    val screenWidthPx: Int? = null,
    val screenHeightPx: Int? = null,
    val refreshRateHz: Int? = null,
    val mappingApp: String = "GG Mouse Pro 3 VIP"
)

data class MotionSample(
    val x: Float,
    val y: Float,
    val timeMs: Long
)

data class MotionMetrics(
    val sampleCount: Int,
    val pathLengthPx: Float,
    val netDistancePx: Float,
    val durationMs: Long,
    val averageSpeedPxPerSecond: Float,
    val peakSpeedPxPerSecond: Float,
    val straightness: Float,
    val endpointErrorPx: Float,
    val hitTarget: Boolean
)

data class AimPreferences(
    val goal: AimGoal = AimGoal.BALANCED,
    val dragProfile: DragProfile = DragProfile.SMOOTH
)

enum class AimGoal(val label: String) {
    PRECISION("Precisão"),
    SPEED("Velocidade"),
    BALANCED("Equilíbrio"),
    AGGRESSIVE("Puxada agressiva")
}

enum class DragProfile(val label: String) {
    SHORT("Short Drag"),
    SMOOTH("Smooth Drag"),
    LONG("Long Drag"),
    CUSTOM("Custom Drag")
}

data class SensitivityValues(
    val general: Int = 150,
    val redDot: Int = 135,
    val scope2x: Int = 120,
    val scope4x: Int = 100,
    val sniper: Int = 70,
    val freeLook: Int = 100
) {
    fun bounded() = copy(
        general = general.coerceIn(0, 200),
        redDot = redDot.coerceIn(0, 200),
        scope2x = scope2x.coerceIn(0, 200),
        scope4x = scope4x.coerceIn(0, 200),
        sniper = sniper.coerceIn(0, 200),
        freeLook = freeLook.coerceIn(0, 200)
    )
}

data class CalibrationResult(
    val metrics: MotionMetrics,
    val recommended: SensitivityValues,
    val explanation: String,
    val confidenceLabel: String
)

data class MappingProfile(
    val appVersion: String = "",
    val sensitivity: String = "",
    val sensitivityX: String = "",
    val sensitivityY: String = "",
    val acceleration: String = "",
    val smoothing: String = "",
    val deadzone: String = "",
    val responseCurve: String = "",
    val aimButtonBehavior: String = "",
    val controlProfile: String = "",
    val switchedSensitivity: String = "",
    val sensitivityMaximum: String = "100",
    val switchedEnabled: Boolean = false,
    val mouseDpi: String = "",
    val phoneDpi: String = ""
)
