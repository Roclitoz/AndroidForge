package com.haze.sensi.engine

/** Feedback observed by the player after testing the same movement in Free Fire. */
enum class GameFeedback(val label: String) { OVERSHOOT("Passou do alvo"), UNDERSHOOT("Ficou abaixo"), HIT("Acertou"), UNSTABLE("Instável") }
enum class MobiladorAxis(val label: String) { HORIZONTAL("Horizontal"), VERTICAL("Vertical"), SWITCHED("Comutada") }

data class MobiladorSettings(
    val mouseDpi: Int? = null,
    val phoneDpi: Int? = null,
    val counterAcceleration: String = "",
    val horizontal: Double? = null,
    val vertical: Double? = null,
    val switched: Double? = null,
    val switchedEnabled: Boolean = false,
    val sensitivityMaximum: Double = 100.0,
    val adjustmentStep: Double = 1.0
)

data class TuningProposal(val axis: MobiladorAxis, val before: Double, val after: Double, val reason: String)

/**
 * Conservative, feedback-driven tuner. It deliberately does not invent a universal GG Mouse preset.
 * Only the selected sensitivity field is changed; DPI and acceleration remain contextual inputs.
 */
object SensitivityOptimizer {
    fun refine(settings: MobiladorSettings, axis: MobiladorAxis, feedback: GameFeedback): TuningProposal? {
        if (feedback == GameFeedback.HIT || feedback == GameFeedback.UNSTABLE) return null
        if (axis == MobiladorAxis.SWITCHED && !settings.switchedEnabled) return null
        val current = when (axis) {
            MobiladorAxis.HORIZONTAL -> settings.horizontal
            MobiladorAxis.VERTICAL -> settings.vertical
            MobiladorAxis.SWITCHED -> settings.switched
        } ?: return null
        val max = settings.sensitivityMaximum
        if (!max.isFinite() || max <= 0.0 || current < 0.0 || current > max) return null
        val step = settings.adjustmentStep.coerceIn(0.1, max)
        val delta = if (feedback == GameFeedback.OVERSHOOT) -step else step
        val next = (current + delta).coerceIn(0.0, max)
        if (next == current) return null
        val reason = if (feedback == GameFeedback.OVERSHOOT)
            "Redução pequena: a mira ultrapassou o alvo. Mantenha DPI e aceleração iguais durante a comparação."
        else "Aumento pequeno: a mira ficou abaixo do alvo. Mantenha DPI e aceleração iguais durante a comparação."
        return TuningProposal(axis, current, next, reason)
    }
}
