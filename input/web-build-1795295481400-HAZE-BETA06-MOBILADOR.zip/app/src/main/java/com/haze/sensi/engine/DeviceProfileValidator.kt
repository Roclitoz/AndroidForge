package com.haze.sensi.engine

import com.haze.sensi.model.DeviceProfile

object DeviceProfileValidator {
    fun validate(profile: DeviceProfile): List<String> = buildList {
        if (profile.mouseDpi != null && profile.mouseDpi !in 100..32000) add("DPI do mouse fora da faixa esperada.")
        if (profile.pollingRateHz != null && profile.pollingRateHz !in 125..8000) add("Polling rate fora da faixa esperada.")
        if (profile.androidDisplayDpi != null && profile.androidDisplayDpi !in 80..1000) add("DPI de tela fora da faixa esperada.")
        if (profile.pointerSpeed != null && profile.pointerSpeed !in -7..7) add("Velocidade do ponteiro fora da faixa esperada.")
        if (profile.screenWidthPx != null && profile.screenWidthPx <= 0) add("Largura de tela inválida.")
        if (profile.screenHeightPx != null && profile.screenHeightPx <= 0) add("Altura de tela inválida.")
    }
}
