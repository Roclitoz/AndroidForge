package com.haze.sensi.engine

import com.haze.sensi.model.MotionMetrics
import com.haze.sensi.model.MotionSample
import kotlin.math.hypot
import kotlin.math.max

object MotionAnalyzer {
    fun analyze(
        samples: List<MotionSample>,
        targetX: Float,
        targetY: Float,
        targetRadiusPx: Float
    ): MotionMetrics? {
        if (samples.size < 2) return null

        // Pointer events are already received in chronological order; avoid sorting on every attempt.
        val ordered = samples
        var path = 0f
        var peakSpeed = 0f

        for (i in 1 until ordered.size) {
            val a = ordered[i - 1]
            val b = ordered[i]
            val distance = hypot(b.x - a.x, b.y - a.y)
            path += distance
            val elapsed = (b.timeMs - a.timeMs).coerceAtLeast(1L)
            peakSpeed = max(peakSpeed, distance / elapsed * 1000f)
        }

        val first = ordered.first()
        val last = ordered.last()
        val net = hypot(last.x - first.x, last.y - first.y)
        val duration = (last.timeMs - first.timeMs).coerceAtLeast(1L)
        val endpointError = hypot(targetX - last.x, targetY - last.y)

        return MotionMetrics(
            sampleCount = ordered.size,
            pathLengthPx = path,
            netDistancePx = net,
            durationMs = duration,
            averageSpeedPxPerSecond = path / duration * 1000f,
            peakSpeedPxPerSecond = peakSpeed,
            straightness = if (path > 0f) (net / path).coerceIn(0f, 1f) else 0f,
            endpointErrorPx = endpointError,
            hitTarget = endpointError <= targetRadiusPx
        )
    }
}
