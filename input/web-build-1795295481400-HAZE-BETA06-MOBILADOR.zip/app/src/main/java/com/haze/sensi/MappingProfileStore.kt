package com.haze.sensi

import android.content.Context
import com.haze.sensi.model.MappingProfile
import org.json.JSONArray
import org.json.JSONObject

/** Local-only storage for mobilador setup and calibration history. */
class MappingProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("haze_sensi_profiles", Context.MODE_PRIVATE)

    fun saveMapping(profile: MappingProfile) {
        val json = JSONObject().apply {
            put("appVersion", profile.appVersion)
            put("sensitivity", profile.sensitivity)
            put("sensitivityX", profile.sensitivityX)
            put("sensitivityY", profile.sensitivityY)
            put("acceleration", profile.acceleration)
            put("smoothing", profile.smoothing)
            put("deadzone", profile.deadzone)
            put("responseCurve", profile.responseCurve)
            put("aimButtonBehavior", profile.aimButtonBehavior)
            put("controlProfile", profile.controlProfile)
            put("switchedSensitivity", profile.switchedSensitivity)
            put("sensitivityMaximum", profile.sensitivityMaximum)
            put("switchedEnabled", profile.switchedEnabled)
            put("mouseDpi", profile.mouseDpi)
            put("phoneDpi", profile.phoneDpi)
        }
        prefs.edit().putString("mapping_profile", json.toString()).apply()
    }

    fun loadMapping(): MappingProfile {
        val j = runCatching { JSONObject(prefs.getString("mapping_profile", "{}") ?: "{}") }.getOrDefault(JSONObject())
        return MappingProfile(
            appVersion=j.optString("appVersion"), sensitivity=j.optString("sensitivity"),
            sensitivityX=j.optString("sensitivityX"), sensitivityY=j.optString("sensitivityY"),
            acceleration=j.optString("acceleration"), smoothing=j.optString("smoothing"),
            deadzone=j.optString("deadzone"), responseCurve=j.optString("responseCurve"),
            aimButtonBehavior=j.optString("aimButtonBehavior"), controlProfile=j.optString("controlProfile"),
            switchedSensitivity=j.optString("switchedSensitivity"),
            sensitivityMaximum=j.optString("sensitivityMaximum", "100"),
            switchedEnabled=j.optBoolean("switchedEnabled", false),
            mouseDpi=j.optString("mouseDpi"), phoneDpi=j.optString("phoneDpi", j.optString("androidDisplayDpi"))
        )
    }

    fun addHistory(summary: String) {
        val entries = runCatching { JSONArray(prefs.getString("calibration_history", "[]") ?: "[]") }.getOrDefault(JSONArray())
        val updated = JSONArray().put(summary).also { out -> for (i in 0 until minOf(entries.length(), 39)) out.put(entries.optString(i)) }
        prefs.edit().putString("calibration_history", updated.toString()).apply()
    }

    fun loadHistory(): List<String> {
        val a = runCatching { JSONArray(prefs.getString("calibration_history", "[]") ?: "[]") }.getOrDefault(JSONArray())
        return (0 until a.length()).mapNotNull { a.optString(it).takeIf(String::isNotBlank) }
    }
}
