# HAZE SENSI — Beta 0.6 (Mobilador)

HAZE é dedicado ao Free Fire em setup mobilador: mouse + teclado via GG Mouse Pro 3 VIP. Não há perfil touchscreen/mobile.

## Referências consultadas

1. **FALL90HZ — Gerador de Mobilador**: separa explicitamente a plataforma Mobilador e lista DPI do mouse, DPI do celular, aceleração do contador, sensibilidade horizontal/vertical e sensibilidade comutada opcional. É uma referência comunitária de nomenclatura e fluxo, não uma documentação oficial do GG nem prova de limites numéricos universais. https://fall90hz.github.io/Fall90hz-site/
2. **GG Mouse Pro 3 — Google Play**: identifica o aplicativo como ferramenta para usar mouse e teclado em jogos Android. A listagem não publica um esquema técnico completo dos controles de sensibilidade. https://play.google.com/store/apps/details?id=com.zjx.ztezscreenshot
3. **GG Mouse Pro 3 — guia de configuração Free Fire**: recomenda salvar o HUD, alinhar o mapeamento ao HUD e testar movimento, câmera e botões separadamente; DPI constante durante os testes. É um guia público, não documentação técnica oficial de todos os parâmetros. https://www.ggmousepro.in/free-fire-settings
4. **GG Mouse Pro 3 — guia de calibração**: recomenda manter DPI fixo, repetir o mesmo movimento, alterar uma variável por vez e separar problemas de sensibilidade de falhas de conexão/entrada. https://www.ggmousepro.in/sensitivity-guide

## O que mudou na 0.6
- Projeto dedicado ao mobilador e ao GG Mouse Pro 3 VIP.
- Sem presets de touchscreen e sem copiar valores gerais de sensibilidade mobile do Free Fire.
- Campos do mobilador: DPI físico do mouse, densidade/DPI Android (informação contextual), aceleração do contador, sensibilidade horizontal/vertical e comutada opcional.
- Campos adicionais (suavização, zona morta, curva, comportamento do botão e layout) são opcionais: preencher somente se aparecerem na versão instalada.
- Escala de sensibilidade configurável pelo usuário. 100 é somente o valor inicial editável; confirmar o limite real no GG antes de calibrar.
- Ajuste conservador por feedback real do jogador: passou do alvo diminui; ficou abaixo aumenta; acertou/instável não altera. Apenas um eixo por vez.
- DPI e aceleração são contexto e nunca são alterados automaticamente.
- Laboratório mostra estatísticas da trajetória do mouse recebida pelo HAZE (distância, velocidade, linearidade e erro do ponto final). Isso não mede a resposta da câmera dentro do Free Fire.
- Histórico local de ajustes.

## Limites técnicos importantes
- O HAZE não lê nem modifica o estado interno do Free Fire ou do GG Mouse Pro 3.
- O gesto dentro do HAZE não equivale ao movimento da câmera dentro do jogo. As estatísticas servem para comparar consistência da trajetória, não para calcular diretamente uma sensibilidade perfeita.
- O motor é determinístico e baseado em feedback, não é IA treinada.
- Não existe preset universal verificável. A interface exige que o usuário confirme o limite numérico e os campos disponíveis na versão instalada.
- Se houver perda de entrada, desconexão ou travamento, primeiro corrigir conexão/ativação; sensibilidade não resolve esses problemas.

## Build
Projeto Android Kotlin + Jetpack Compose. AGP 8.7.3, Kotlin 2.0.21, JDK 17, compileSdk 35, minSdk 29. Fonte; não é APK compilado.
