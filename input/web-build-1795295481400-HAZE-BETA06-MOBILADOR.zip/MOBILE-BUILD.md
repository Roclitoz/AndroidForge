# HAZE SENSI — gerar APK pelo celular

Este projeto inclui GitHub Actions para compilar o APK na nuvem, sem Android Studio no celular.

## Passos
1. No navegador do celular, entre em https://github.com e crie uma conta ou entre na sua.
2. Crie um repositório novo chamado `haze-sensi-beta` e deixe-o **Private**.
3. Envie o conteúdo desta pasta para a raiz do repositório (não envie a pasta externa `haze-sensi` como uma subpasta). O arquivo `.github/workflows/android-beta.yml` precisa ficar exatamente nesse caminho.
4. Abra a aba **Actions** do repositório.
5. Se aparecer uma confirmação para habilitar workflows, confirme.
6. Abra **HAZE SENSI - Android Beta APK** e toque em **Run workflow**. O primeiro build também inicia após o envio para a branch `main`.
7. Aguarde o job ficar verde. Abra a execução concluída, desça até **Artifacts** e baixe `haze-sensi-beta-debug`.
8. Extraia o ZIP baixado e instale `app-debug.apk`. Se o Android perguntar, permita a instalação dessa origem.

## Se o build falhar
Abra a execução em Actions e expanda a etapa vermelha. Copie a mensagem completa do erro e envie para que possamos corrigir o projeto.

## Observações
- Este é um APK `debug`, adequado para testes internos, não uma versão de publicação.
- O workflow usa JDK 17, Gradle 8.9 e Android SDK 35.
- O APK só estará disponível se a compilação terminar com sucesso.
