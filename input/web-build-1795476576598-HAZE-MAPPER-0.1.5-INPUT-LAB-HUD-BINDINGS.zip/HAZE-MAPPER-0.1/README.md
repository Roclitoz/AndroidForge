# HAZE MAPPER 0.1.5 — Input Lab & HUD bindings

## Added in 0.1.5
- Per-control key binding capture for W/A/S/D, FIRE, JUMP, RELOAD and VISTA.
- Vista toggle key is persisted across app restarts.
- Analog calibration surface reports normalized X/Y axes, magnitude, 12% deadzone and returns to center on release.
- HUD editor displays the configured key next to each control.
- Safe Shizuku probe reports `/dev/uinput` visibility and read/write access without creating a virtual device.

## Important current limitations
This release is an input/configuration prototype, not yet a complete in-game mapper. The analog surface currently validates local axis handling only. Vista currently toggles the local camera/cursor state while HAZE is focused; it does not yet capture raw mouse movement globally or inject a cursor/touch stream into Free Fire.

The existing Shizuku UserService still provides diagnostics and discrete `input tap` / `input swipe` test commands. Those commands do not provide persistent multi-touch pointer IDs, so they are not suitable as the final analog/camera backend.

## Next engineering milestone
Use the new uinput probe on the target Samsung firmware. If access is available, implement a native `uinput` multitouch backend and safe physical-device capture with guaranteed release on disconnect. Do not enable EVIOCGRAB by default.

## Build
Open this project in AndroidForge / Android Studio and run `assembleDebug`. The source has not been compiled in this environment.
