# HAZE MAPPER 0.1.9 — Global Input Engine Lab

## Base validada
- Mantém a implementação do analógico WASD local da versão 0.1.6.
- Mantém a captura global de teclado por AccessibilityService validada pelo usuário na versão 0.1.7.

## Novidades 0.1.8
- O serviço global mantém o conjunto de teclas pressionadas (DOWN/UP).
- Calcula eixos normalizados X/Y a partir das teclas WASD configuradas no perfil.
- Normaliza diagonais para magnitude máxima 1.0.
- Alterna o estado lógico de Vista pela tecla VISTA configurada no perfil.
- Diagnóstico mostra eixos, teclas pressionadas, estado Vista e movimento ativo.
- Continua retornando `false` em `onKeyEvent`: não consome nem bloqueia os eventos físicos originais.
- Limpa estado de teclas ao interromper/desvincular o serviço.

## Limitações explícitas
Esta versão calcula e exibe estado global, mas ainda NÃO injeta toque no jogo, NÃO cria touchscreen virtual e NÃO transforma o mouse em movimento de câmera/cursor. A Vista ainda é apenas um estado lógico/diagnóstico. O analógico local continua funcionando dentro do HAZE.

## Teste recomendado
1. Instale a versão compilada pelo AndroidForge.
2. Confirme que o serviço de acessibilidade continua habilitado.
3. Abra o Free Fire e segure W; depois teste W+D e solte.
4. Volte ao HAZE > Captura global de teclado > Atualizar diagnóstico.
5. Confira X/Y, teclas pressionadas e estado Vista.
6. Repita com a tecla Vista configurada. O jogo deve continuar recebendo os eventos originais.

## Build
Projeto Android Gradle, compileSdk 35, minSdk 26, Java 17, Shizuku API/Provider 13.1.5. Compile no AndroidForge. Este pacote é código-fonte; não é APK compilado.

## 0.1.9 — Native virtual touchscreen backend (experimental)

This revision adds an arm64-v8a JNI backend based on Linux `uinput`:

- `nativeProbeTouch()` opens `/dev/uinput`, configures a virtual direct-touch device, creates it briefly, and destroys it. It does **not** send touch events.
- `nativeStartTouch()` creates a persistent virtual touchscreen for an explicit test session.
- `nativeTouchEvent(action, x, y)` supports `0=DOWN`, `1=MOVE`, `2=UP` with normalized absolute coordinates in the 0..32767 range.
- `nativeStopTouch()` releases any active contact and destroys the device.

The UI exposes a probe, start, explicit center-tap test (with confirmation), and stop. Keep the game closed during the center-tap test. Do not leave the virtual device active when finished; use **Encerrar touchscreen virtual**.

### Important limitations

- This is an experimental kernel uinput backend, not yet connected to global WASD state. Global key observation remains non-consuming.
- `/dev/uinput` availability and SELinux policy vary by firmware. Shizuku's ADB identity is not root; an `EACCES`/`EPERM` result means this route is blocked on that build unless the device exposes a permitted interface.
- Successful `UI_DEV_CREATE` does not yet prove Free Fire accepts the virtual device. Android may ignore, classify, or restrict virtual input differently.
- The current device exposes one multitouch contact. Multi-finger aim/fire and Vista/cursor switching are not implemented in this revision.
- Native build requirements: Android NDK + CMake installed in the build environment; target ABI is `arm64-v8a`.

### Safe validation order

1. Build and install; connect Shizuku and start UserService.
2. Run **Testar criação real de touchscreen virtual**. It should report `UINPUT_CREATE_OK` or a precise errno.
3. Only if probe succeeds, close the game and start the virtual device.
4. Use the confirmed center-tap test on a harmless screen.
5. Stop/destroy the device.

Never treat a successful probe as proof that global mapping or Free Fire gameplay injection is complete.
