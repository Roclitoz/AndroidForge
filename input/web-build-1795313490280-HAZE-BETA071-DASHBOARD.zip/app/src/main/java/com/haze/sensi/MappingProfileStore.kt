package com.haze.sensi

import android.content.Context
import com.haze.sensi.model.MappingProfile
import org.json.JSONArray
import org.json.JSONObject

/** Local-only storage for mobilador setup and calibration history. */
class MappingProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("haze_sensi_profiles", Context.MODE_PRIVATE)

    fun saveMapping(p: MappingProfile) {
        val json = JSONObject().apply {
            put("appVersion",p.appVersion); put("sensitivity",p.sensitivity)
            put("sensitivityX",p.sensitivityX); put("sensitivityY",p.sensitivityY)
            put("acceleration",p.acceleration); put("smoothing",p.smoothing)
            put("deadzone",p.deadzone); put("responseCurve",p.responseCurve)
            put("aimButtonBehavior",p.aimButtonBehavior); put("controlProfile",p.controlProfile)
            put("switchedSensitivity",p.switchedSensitivity); put("sensitivityMaximum",p.sensitivityMaximum)
            put("switchedEnabled",p.switchedEnabled); put("mouseDpi",p.mouseDpi); put("phoneDpi",p.phoneDpi)
            put("antiShakeActive",p.antiShakeActive); put("antiShakeConfigured",p.antiShakeConfigured)
            put("pollingRate",p.pollingRate); put("pointerSpeed",p.pointerSpeed)
            put("secondScreenWidth",p.secondScreenWidth); put("secondScreenHeight",p.secondScreenHeight)
            put("secondScreenRefreshRate",p.secondScreenRefreshRate); put("screenOrientation",p.screenOrientation)
            put("mappingMode",p.mappingMode); put("screenScale",p.screenScale); put("extraNotes",p.extraNotes)
        }
        prefs.edit().putString("mapping_profile",json.toString()).apply()
    }

    fun loadMapping(): MappingProfile {
        val j = runCatching { JSONObject(prefs.getString("mapping_profile","{}") ?: "{}") }.getOrDefault(JSONObject())
        return MappingProfile(
            appVersion=j.optString("appVersion"), sensitivity=j.optString("sensitivity"),
            sensitivityX=j.optString("sensitivityX"), sensitivityY=j.optString("sensitivityY"),
            acceleration=j.optString("acceleration"), smoothing=j.optString("smoothing"),
            deadzone=j.optString("deadzone"), responseCurve=j.optString("responseCurve"),
            aimButtonBehavior=j.optString("aimButtonBehavior"), controlProfile=j.optString("controlProfile"),
            switchedSensitivity=j.optString("switchedSensitivity"), sensitivityMaximum=j.optString("sensitivityMaximum","100"),
            switchedEnabled=j.optBoolean("switchedEnabled",false), mouseDpi=j.optString("mouseDpi"),
            phoneDpi=j.optString("phoneDpi",j.optString("androidDisplayDpi")),
            antiShakeActive=j.optBoolean("antiShakeActive",false), antiShakeConfigured=j.optBoolean("antiShakeConfigured",false),
            pollingRate=j.optString("pollingRate"), pointerSpeed=j.optString("pointerSpeed"),
            secondScreenWidth=j.optString("secondScreenWidth"), secondScreenHeight=j.optString("secondScreenHeight"),
            secondScreenRefreshRate=j.optString("secondScreenRefreshRate"), screenOrientation=j.optString("screenOrientation","Paisagem"),
            mappingMode=j.optString("mappingMode","Mouse + teclado"), screenScale=j.optString("screenScale"), extraNotes=j.optString("extraNotes")
        )
    }

    fun addHistory(summary:String) {
        val entries=runCatching { JSONArray(prefs.getString("calibration_history","[]") ?: "[]") }.getOrDefault(JSONArray())
        val updated=JSONArray().put(summary).also { out -> for(i in 0 until minOf(entries.length(),39)) out.put(entries.optString(i)) }
        prefs.edit().putString("calibration_history",updated.toString()).apply()
    }
    fun loadHistory():List<String> {
        val a=runCatching { JSONArray(prefs.getString("calibration_history","[]") ?: "[]") }.getOrDefault(JSONArray())
        return (0 until a.length()).mapNotNull { a.optString(it).takeIf(String::isNotBlank) }
    }
}
