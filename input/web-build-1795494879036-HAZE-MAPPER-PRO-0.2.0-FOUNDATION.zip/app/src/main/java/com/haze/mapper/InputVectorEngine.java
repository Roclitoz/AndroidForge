package com.haze.mapper;

import java.util.Set;

/**
 * Pure input math shared by the capture layer and tests.
 * Screen coordinates are not produced here: x is horizontal (A=-1, D=+1),
 * y is vertical (S=-1, W=+1). Diagonals are normalized to unit length.
 */
public final class InputVectorEngine {
    private InputVectorEngine() { }

    public static final class Vector {
        public final float x;
        public final float y;
        public final boolean active;
        private Vector(float x, float y) {
            this.x = x; this.y = y;
            this.active = x != 0f || y != 0f;
        }
    }

    public static Vector fromHeld(Set<Integer> held, int keyW, int keyA, int keyS, int keyD) {
        if (held == null || held.isEmpty()) return new Vector(0f, 0f);
        float x = (held.contains(keyD) ? 1f : 0f) - (held.contains(keyA) ? 1f : 0f);
        float y = (held.contains(keyW) ? 1f : 0f) - (held.contains(keyS) ? 1f : 0f);
        float lengthSquared = x * x + y * y;
        if (lengthSquared > 1f) {
            float inverseLength = (float)(1.0 / Math.sqrt(lengthSquared));
            x *= inverseLength; y *= inverseLength;
        }
        return new Vector(x, y);
    }
}
