import com.haze.mapper.InputVectorEngine;
import java.util.HashSet;
import java.util.Set;

public final class InputVectorEngineSmokeTest {
    private static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        final int W=1,A=2,S=3,D=4;
        Set<Integer> keys = new HashSet<>();
        InputVectorEngine.Vector v = InputVectorEngine.fromHeld(keys,W,A,S,D);
        check(!v.active && v.x==0f && v.y==0f,"neutral");
        keys.add(W); v=InputVectorEngine.fromHeld(keys,W,A,S,D);
        check(v.x==0f && v.y==1f,"W");
        keys.clear(); keys.add(A); v=InputVectorEngine.fromHeld(keys,W,A,S,D);
        check(v.x==-1f && v.y==0f,"A");
        keys.clear(); keys.add(S); v=InputVectorEngine.fromHeld(keys,W,A,S,D);
        check(v.x==0f && v.y==-1f,"S");
        keys.clear(); keys.add(D); v=InputVectorEngine.fromHeld(keys,W,A,S,D);
        check(v.x==1f && v.y==0f,"D");
        keys.clear(); keys.add(W); keys.add(D); v=InputVectorEngine.fromHeld(keys,W,A,S,D);
        check(Math.abs(v.x-0.70710677f)<0.00001f && Math.abs(v.y-0.70710677f)<0.00001f,"W+D normalized");
        keys.add(A); v=InputVectorEngine.fromHeld(keys,W,A,S,D);
        check(v.x==0f && v.y==1f,"opposite horizontal keys cancel");
        System.out.println("PASS: 7 vector assertions");
    }
}
