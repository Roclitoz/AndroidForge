# Haze Mapper Pro 0.2.0 — Foundation Rebuild

Esta entrega inaugura a nova linha do Haze Mapper Pro. É um projeto-fonte Android (não APK).

## O que mudou
- Branding e versão 0.2.0.
- Nova classe `InputVectorEngine`: matemática WASD isolada e testável sem Android.
- `GlobalKeyCaptureService` usa o mesmo cálculo centralizado nos dois fluxos de movimento.
- Auditoria técnica, roteiro e protocolo de feedback em `docs/`.

## O que ainda não está resolvido
A transformação de coordenadas do touchscreen continua pendente; a implementação antiga ainda contém uma transformação inferida para Samsung landscape. Mouse global/cursor próprio não está implementado. Binder e JNI ainda precisam da revisão de segurança e do gerenciador de contatos. Consulte `docs/ENGINE_AUDIT_0.2.0.md`.

## Teste matemático
A classe `InputVectorEngine` não depende de Android. O teste independente está em `tools/InputVectorEngineSmokeTest.java`. Pode ser executado com `javac` e `java`; ver instruções em `docs/FEEDBACK_PROTOCOL.md`.

## Build Android
Abra o projeto no Android Studio ou envie a pasta/ZIP ao AndroidForge. Configuração: AGP 8.7.3, compileSdk 35, minSdk 26, targetSdk 35, NDK/CMake, ABI arm64-v8a, Shizuku API/provider 13.1.5. Este ambiente não contém Gradle/Android SDK configurado; portanto, não foi possível validar APK aqui.
