# Haze Mapper Pro 0.2.0 — auditoria de engenharia

## Escopo desta entrega
Esta é uma reconstrução incremental da base 0.1.12, não uma alegação de que mouse global/Vista já esteja implementado. O nome e a versão foram atualizados, e a matemática WASD foi extraída para uma classe Java pura e testável. O backend nativo e o protocolo Binder ainda exigem a refatoração descrita abaixo.

## Achados confirmados no código 0.1.12

### `MappingEngine.java`
- Mantém `Map<Integer, Binding>` sincronizado.
- Cada `Binding` guarda keyCode e ratios limitados a [0,1].
- Os binds SPACE/R/F são defaults de demonstração, não um perfil real do Free Fire.
- `toPixel` multiplica ratio pela dimensão e limita a dimensão-1.

### `GlobalKeyCaptureService.java`
- É `AccessibilityService` e solicita `FLAG_REQUEST_FILTER_KEY_EVENTS`.
- Mantém teclas pressionadas em `HashSet<Integer>`.
- Alterna Vista por tecla configurada; suspende o joystick ao entrar em Vista.
- Envia atualizações periódicas de heartbeat de 45 ms.
- `onInterrupt`, `onDestroy` e `onUnbind` limpam o estado de movimento.
- Não implementa captura global do movimento relativo do mouse nem cursor próprio.
- A atualização do estado de Vista e os callbacks de entrada devem futuramente ser serializados num único controlador de sessão.

### `MapperUserService.java`
- Expõe protocolo Binder manual com códigos de transação fixos.
- Carrega `libhazeinput` e chama JNI.
- Diagnóstico chama `id`, `getprop`, `wm` e `getevent`; tap/swipe chamam `input`.
- A implementação atual não faz allowlist explícita de UID chamador nem validação completa de todos os argumentos.
- O tratamento de destroy encerra o processo; a próxima revisão deve preferir encerramento ordenado e liberação idempotente.

### `hazeinput.c`
- Abre `/dev/uinput`, configura touchscreen direto e cria dispositivo virtual.
- Declara slots 0, 1 e 2 para teste, joystick e HUD; embora o ABS_MT_SLOT seja configurado até 9.
- Usa estado global (`g_fd`, flags de contato e tracking IDs) sem mutex.
- A transformação de joystick/HUD usa inversão/troca de eixos explicitamente descrita no próprio código como inferida de teste, não calibrada pelo dispositivo.
- DOWN pode ser emitido novamente sem verificar se aquele slot já estava ativo; MOVE/UP também precisam validar o estado do slot.
- As escritas de evento devem ser agrupadas e verificadas; o ciclo de vida deve liberar todos os slots em falha e encerramento.

### `HudEditorView.java` e overlay
- O editor armazena ratios normalizados com base na dimensão da View do editor.
- O overlay calcula pixels usando `getRealMetrics()` e usa defaults independentes.
- O overlay não aplica necessariamente os mesmos limites/insets/área útil do editor.
- Portanto, posição salva no preview não prova posição equivalente no jogo.

## Alteração implementada nesta revisão
`InputVectorEngine` centraliza a matemática do vetor WASD. A convenção lógica é explícita: A=-X, D=+X, S=-Y, W=+Y. Vetores diagonais são normalizados para comprimento 1. A classe não faz transformação de tela nem decide rotação; essas responsabilidades ficam fora dela até termos calibração observada. `GlobalKeyCaptureService` agora usa essa classe em seus dois pontos de cálculo do vetor.

## Não declarar como concluído
- Orientação real dos eixos do uinput no Galaxy A17.
- Calibração de coordenadas do jogo.
- Captura global de mouse e modo câmera/cursor Vista.
- Toques HUD multitouch simultâneos em número arbitrário.
- Build APK: este pacote é fonte.

## Referências externas verificadas nesta revisão

- Linux kernel, `uinput`: https://www.kernel.org/doc/html/latest/input/uinput.html — permite criar dispositivos virtuais via `/dev/uinput`; a própria documentação recomenda considerar `libevdev` como camada menos propensa a erros para software novo. Mantemos acesso direto no protótipo atual por dependência mínima, mas isso deve ser reavaliado.
- Linux kernel, Multi-touch Type B: https://www.kernel.org/doc/html/latest/input/multi-touch-protocol.html — slots representam contatos identificáveis; `ABS_MT_TRACKING_ID >= 0` cria/identifica contato e `-1` encerra; cada lote termina em `SYN_REPORT`. Isso confirma a necessidade de um gerenciador explícito de slots.
- Shizuku API: https://github.com/RikkaApps/Shizuku-API — `UserService` executa em processo separado com identidade shell (UID 2000 quando Shizuku é iniciado via ADB) ou root. Não é um processo Android app comum; algumas APIs de `Context` não funcionam normalmente. Portanto, evitar mover lógica dependente de Activity/Context para esse processo.
- Android `AccessibilityService`: https://developer.android.com/reference/android/accessibilityservice/AccessibilityService — `onMotionEvent` existe desde API 34, mas o serviço precisa solicitar fontes por `setMotionEventSources`; a documentação recomenda `TouchInteractionController` para observar/controlar interações touchscreen. Os eventos das fontes solicitadas não são encaminhados ao restante do sistema, então a captura de mouse deve ser validada com cuidado para não interromper o dispositivo físico.
- Android JNI tips: https://developer.android.com/ndk/guides/jni-tips — recomenda reduzir a quantidade/frequência de cruzamentos JNI, limitar threads que acessam JNI e nunca compartilhar `JNIEnv` entre threads. Nosso JNI atual é síncrono, mas o estado nativo global ainda precisa de sincronização.
- Android `WindowMetrics`: https://developer.android.com/reference/android/view/WindowManager#getMaximumWindowMetrics() — métricas de janela não devem ser confundidas automaticamente com coordenadas físicas do touchscreen virtual; insets, multi-window e rotação precisam ser modelados explicitamente.

## Implicações de projeto

1. Não usar `onMotionEvent` como solução pronta de mouse: primeiro testar quais fontes o Galaxy A17 realmente entrega e se a solicitação interfere na propagação do mouse.
2. Não adotar `libevdev` até confirmar que a biblioteca está disponível/compilável no NDK e que não aumenta desnecessariamente o pacote; estudar seu modelo de criação como referência.
3. O motor nativo deve manter uma tabela de contatos (`slot`, `trackingId`, `active`, `x`, `y`) e serializar cada lote de eventos. `BTN_TOUCH` deve refletir o estado agregado de todos os contatos ativos.
4. O serviço deve ter um único proprietário do ciclo de vida do touchscreen. A Activity não deve destruir a sessão apenas por recriação de UI; a política de sessão precisa ser explícita.
