# Roadmap técnico

1. **0.2.0 Foundation:** auditoria da 0.1.12, documentação de riscos, vetor WASD puro e testável.
2. **0.2.1 Coordinate Lab:** leitura das capacidades reais do dispositivo virtual e matriz de transformação configurável; sem valores presumidos.
3. **0.2.2 Touch Session:** gerenciador de slots/contatos com estado, mutex, tracking ID e liberação idempotente.
4. **0.2.3 Analog:** integrar vetor testado à transformação calibrada e validar persistência do dedo.
5. **0.2.4 Mouse research:** protótipo independente para fontes de movimento disponíveis e viabilidade de captura fora do app.
6. **0.2.5 Vista:** câmera/cursor somente após prova técnica da captura e do encaminhamento de movimento/clique.
7. **0.2.6 HUD:** uma única geometria de display e preview; persistência e múltiplos contatos.
8. **Security pass:** UID allowlist, argumentos validados, comandos de diagnóstico allowlist, limpeza ordenada e watchdog.

Cada etapa precisa de teste reproduzível antes de avançar.
