# Haze Mapper Pro — protocolo de feedback 0.2.0

## Antes de testar
1. Faça backup do APK anterior e mantenha o ZIP-fonte original.
2. Compile e instale este projeto como uma instalação de teste.
3. Não teste inicialmente em partida ranqueada. Use treinamento/sala.
4. Registre modelo, versão Android, orientação, resolução/densidade reportadas pelo app e se Shizuku está autorizado.

## Teste A — inicialização e Shizuku
- Abrir app: não deve fechar inesperadamente.
- Conectar Shizuku: serviço deve conectar.
- Executar diagnóstico: guardar texto integral, especialmente UID, versão/API, display size/density e lista de input devices.
- Iniciar dispositivo virtual e parar: guardar respostas.

## Teste B — teclado isolado
Com o jogo fora de foco, confirmar se o contador de eventos do serviço muda. Depois, com o jogo em treinamento, testar W, A, S, D individualmente e combinações. Não presumir que o toque está na posição correta ainda.

## Teste C — analógico
Para cada tecla, anotar: direção real no jogo, posição inicial do toque, se o dedo fica pressionado, se há interrupção, e se solta ao liberar a tecla. Testar W, A, S, D, W+A, W+D, S+A, S+D.

## Teste D — Vista e mouse
Nesta revisão, Vista não é anunciada como controle global de mouse. Registrar apenas se alternar Vista suspende/retoma o analógico. Não interpretar movimento de câmera curto como captura funcional.

## Como enviar feedback
Enviar: (1) screenshot do diagnóstico; (2) vídeo curto mostrando o teste; (3) sequência exata de teclas; (4) comportamento esperado e observado; (5) se o toque virtual move o cursor/câmera ou aciona o joystick. Não é necessário enviar dados pessoais.

## Resultado esperado desta etapa
A principal validação de código desta revisão é matemática: vetores WASD e diagonais. O comportamento do touchscreen ainda depende da transformação nativa que será calibrada em uma etapa própria.
