# Haze Mapper Pro 0.3.4 — Independent Key Engine

Projeto Android fonte da RCL Developments. Abra `haze_031_work` no Android Studio e compile `assembleDebug`.

Esta versão implementa contatos independentes para as teclas físicas configuradas em FIRE, JUMP e RELOAD. O WASD permanece em seu contato dedicado; os contatos de ação usam slots multitouch separados e o estado BTN_TOUCH é agregado.

Consulte `docs/KEY-ENGINE-0.3.4.md` para arquitetura, alterações e roteiro de validação.

**Estado da validação:** testes locais do gerenciador de estados e verificação sintática C executados. APK Android/NDK não foi compilado neste ambiente e ainda falta validar os contatos simultâneos no Galaxy A17/Free Fire.


## Diagnostic logs (0.3.4)
Use **EXPORTAR LOGS DE DIAGNÓSTICO** on the main screen to save `haze-diagnostics.txt`. The report includes key event phases, mapped controls, display geometry, native touch coordinates/slots, backend responses, calibration observations, and UserService diagnostics. It is bounded and stored privately until the user exports it. See `docs/DIAGNOSTIC-LOGGING-0.3.4.md`.
