package com.haze.mapper;
public final class HudRotationMappingSmokeTest {
  static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);}
  static void near(float a,float b,String label){check(Math.abs(a-b)<0.0001f,label+" got="+a+" expected="+b);}
  public static void main(String[] args){
    float[] p=HudCoordinateMapper.rotateBetweenDisplayOrientations(.25f,.75f,0,1); near(p[0],.25f,"90 x"); near(p[1],.25f,"90 y");
    p=HudCoordinateMapper.rotateBetweenDisplayOrientations(.25f,.75f,0,2); near(p[0],.75f,"180 x"); near(p[1],.25f,"180 y");
    p=HudCoordinateMapper.rotateBetweenDisplayOrientations(.25f,.75f,0,3); near(p[0],.75f,"270 x"); near(p[1],.75f,"270 y");
    p=HudCoordinateMapper.rotateBetweenDisplayOrientations(.25f,.75f,2,2); near(p[0],.25f,"same x"); near(p[1],.75f,"same y");
    System.out.println("PASS: 8 orientation mapping assertions");
  }
}
