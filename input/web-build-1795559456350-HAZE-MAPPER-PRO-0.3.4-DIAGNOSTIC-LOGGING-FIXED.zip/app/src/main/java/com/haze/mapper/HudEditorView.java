package com.haze.mapper;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import java.util.ArrayList;
import java.util.List;

/** HUD editor whose saved positions are normalized to the full game display. */
public final class HudEditorView extends View {
    private static final String PREFS = "haze_hud";
    private static final String[] IDS = {"W", "A", "S", "D", "FIRE", "JUMP", "RELOAD", "VISTA"};
    private final SharedPreferences prefs;
    private final List<RectF> items = new ArrayList<>();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int selected = -1;
    private float downX, downY, startX, startY;
    private float radius, viewportLeft, viewportTop, viewportWidth, viewportHeight;
    private float globalScale=1f, globalOpacity=.85f;

    public void setGlobalScale(float value){globalScale=Math.max(.5f,Math.min(1.5f,value));prefs.edit().putFloat("global_scale",globalScale).apply();invalidate();}
    public void setGlobalOpacity(float value){globalOpacity=Math.max(0f,Math.min(1f,value));prefs.edit().putFloat("global_opacity",globalOpacity).apply();invalidate();}

    public HudEditorView(Context context) {
        super(context);
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        globalScale=prefs.getFloat("global_scale",1f);
        globalOpacity=prefs.getFloat("global_opacity",.85f);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    private float px(String id, String axis, float fallback) {
        return prefs.getFloat(id + "_" + axis, fallback);
    }

    private void calculateViewport(float w, float h) {
        DisplayMetrics dm = new DisplayMetrics();
        WindowManager wm = (WindowManager)getContext().getSystemService(Context.WINDOW_SERVICE);
        Display display = wm == null ? null : wm.getDefaultDisplay();
        if (display != null) display.getRealMetrics(dm);
        float targetAspect = (dm.widthPixels > 0 && dm.heightPixels > 0)
                ? dm.widthPixels / (float)dm.heightPixels : w / Math.max(1f,h);
        float viewAspect = w / Math.max(1f,h);
        if (viewAspect > targetAspect) {
            viewportHeight = h;
            viewportWidth = h * targetAspect;
            viewportLeft = (w - viewportWidth) * .5f;
            viewportTop = 0f;
        } else {
            viewportWidth = w;
            viewportHeight = w / targetAspect;
            viewportLeft = 0f;
            viewportTop = (h - viewportHeight) * .5f;
        }
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        c.drawColor(0xFF171923);
        calculateViewport(w,h);
        RectF screen = new RectF(viewportLeft+8, viewportTop+8,
                viewportLeft+viewportWidth-8, viewportTop+viewportHeight-8);
        paint.setColor(0xFF252B3A); paint.setStyle(Paint.Style.FILL);
        c.drawRoundRect(screen, 22, 22, paint);
        paint.setColor(0xFF46516A); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(2);
        c.drawRoundRect(new RectF(screen.left+10,screen.top+10,screen.right-10,screen.bottom-10),18,18,paint);

        radius = Math.max(20, Math.min(viewportWidth, viewportHeight) * 0.055f) * globalScale;
        items.clear();
        float[][] defaults = {{.15f,.68f},{.08f,.77f},{.15f,.86f},{.22f,.77f},{.86f,.76f},{.75f,.62f},{.88f,.48f},{.50f,.90f}};
        for (int i=0;i<IDS.length;i++) {
            float nx = px(IDS[i], "x", defaults[i][0]);
            float ny = px(IDS[i], "y", defaults[i][1]);
            float x = viewportLeft + nx * viewportWidth;
            float y = viewportTop + ny * viewportHeight;
            RectF r = new RectF(x-radius, y-radius, x+radius, y+radius); items.add(r);
            paint.setStyle(Paint.Style.FILL); paint.setColor((Math.round(globalOpacity*255)<<24) | (i==selected?0x008B5CF6:0x0034415B)); c.drawRoundRect(r, 14, 14, paint);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(2); paint.setColor((Math.round(globalOpacity*255)<<24) | 0x00B9C4D8); c.drawRoundRect(r,14,14,paint);
            paint.setStyle(Paint.Style.FILL); paint.setColor((Math.round(globalOpacity*255)<<24) | 0x00FFFFFF); paint.setTextAlign(Paint.Align.CENTER); paint.setTextSize(IDS[i].length()>4?radius*.42f:radius*.58f);
            c.drawText(IDS[i], x, y - paint.getTextSize()*.05f, paint);
            android.content.SharedPreferences keys = getContext().getSharedPreferences("haze_profile", Context.MODE_PRIVATE);
            int fallback = i==0?android.view.KeyEvent.KEYCODE_W:i==1?android.view.KeyEvent.KEYCODE_A:i==2?android.view.KeyEvent.KEYCODE_S:i==3?android.view.KeyEvent.KEYCODE_D:i==4?android.view.KeyEvent.KEYCODE_BUTTON_R1:i==5?android.view.KeyEvent.KEYCODE_SPACE:i==6?android.view.KeyEvent.KEYCODE_R:android.view.KeyEvent.KEYCODE_F1;
            int key = keys.getInt("key_"+IDS[i], fallback);
            paint.setTextSize(Math.max(9, radius*.25f));
            c.drawText(android.view.KeyEvent.keyCodeToString(key).replace("KEYCODE_", ""), x, y + radius*.55f, paint);
        }
        paint.setTextAlign(Paint.Align.LEFT); paint.setTextSize(13); paint.setColor(0xFFCFD6E5);
        c.drawText("PRÉVIA NA PROPORÇÃO REAL DO JOGO • ARRASTE OS CONTROLES", 28, 48, paint);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x=e.getX(), y=e.getY();
        if (e.getAction()==MotionEvent.ACTION_DOWN) {
            selected=-1;
            for(int i=items.size()-1;i>=0;i--) if(items.get(i).contains(x,y)){selected=i;break;}
            if(selected>=0){downX=x;downY=y;startX=items.get(selected).centerX();startY=items.get(selected).centerY(); invalidate(); return true;}
        } else if(e.getAction()==MotionEvent.ACTION_MOVE && selected>=0) {
            float cx=Math.max(viewportLeft+radius+8,Math.min(viewportLeft+viewportWidth-radius-8,startX+x-downX));
            float cy=Math.max(viewportTop+radius+8,Math.min(viewportTop+viewportHeight-radius-8,startY+y-downY));
            String id=IDS[selected];
            float nx=(cx-viewportLeft)/Math.max(1f,viewportWidth);
            float ny=(cy-viewportTop)/Math.max(1f,viewportHeight);
            prefs.edit().putFloat(id+"_x",nx).putFloat(id+"_y",ny).apply();
            invalidate(); return true;
        } else if((e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL) && selected>=0) { selected=-1; invalidate(); return true; }
        return true;
    }
}
