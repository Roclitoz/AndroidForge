package com.haze.mapper;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

/** Full-screen landscape editor for the clickable HUD layout. */
public final class HudEditorActivity extends Activity {
    private HudEditorView editor;
    private android.content.SharedPreferences prefs;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("haze_hud", MODE_PRIVATE);
        build();
    }

    private TextView label(String value, int size) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(Color.WHITE);
        t.setTextSize(size);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private void build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(10, 5, 10, 5);
        root.setBackgroundColor(0xFF0B0F18);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("HAZE MAPPER PRO  •  EDITOR HUD", 16);
        title.setTypeface(null, 1);
        header.addView(title, new LinearLayout.LayoutParams(0, 38, 1));
        TextView hint = label("LANDSCAPE  •  ARRASTE OS CONTROLES", 11);
        hint.setTextColor(0xFFB8C4D8);
        header.addView(hint, new LinearLayout.LayoutParams(-2, 38));
        root.addView(header);

        editor = new HudEditorView(this);
        root.addView(editor, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout options = new LinearLayout(this);
        options.setGravity(Gravity.CENTER_VERTICAL);
        options.setPadding(4, 0, 4, 0);

        LinearLayout scaleBox = new LinearLayout(this);
        scaleBox.setOrientation(LinearLayout.VERTICAL);
        scaleBox.addView(label("TAMANHO", 10));
        SeekBar scale = new SeekBar(this);
        scale.setMax(150);
        scale.setProgress(Math.round(prefs.getFloat("global_scale", 1f) * 100));
        scale.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int v, boolean user) { editor.setGlobalScale(Math.max(50, v) / 100f); }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });
        scaleBox.addView(scale);
        options.addView(scaleBox, new LinearLayout.LayoutParams(0, 48, 1));

        LinearLayout opacityBox = new LinearLayout(this);
        opacityBox.setOrientation(LinearLayout.VERTICAL);
        opacityBox.setPadding(12, 0, 12, 0);
        opacityBox.addView(label("OPACIDADE", 10));
        SeekBar opacity = new SeekBar(this);
        opacity.setMax(100);
        opacity.setProgress(Math.round(prefs.getFloat("global_opacity", .85f) * 100));
        opacity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int v, boolean user) { editor.setGlobalOpacity(v / 100f); }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });
        opacityBox.addView(opacity);
        options.addView(opacityBox, new LinearLayout.LayoutParams(0, 48, 1));

        Button reset = new Button(this);
        reset.setText("REDEFINIR");
        reset.setTextSize(10);
        reset.setAllCaps(false);
        reset.setOnClickListener(v -> {
            String[] ids = {"W", "A", "S", "D", "FIRE", "JUMP", "RELOAD", "VISTA"};
            float[][] defaults = {{.15f,.68f},{.08f,.77f},{.15f,.86f},{.22f,.77f},{.86f,.76f},{.75f,.62f},{.88f,.48f},{.50f,.90f}};
            android.content.SharedPreferences.Editor edit = prefs.edit();
            for (int i = 0; i < ids.length; i++) edit.putFloat(ids[i] + "_x", defaults[i][0]).putFloat(ids[i] + "_y", defaults[i][1]);
            edit.apply();
            editor.invalidate();
        });
        options.addView(reset, new LinearLayout.LayoutParams(-2, 44));
        root.addView(options, new LinearLayout.LayoutParams(-1, 50));

        LinearLayout footer = new LinearLayout(this);
        footer.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        Button save = new Button(this);
        save.setText("SALVAR E VOLTAR");
        save.setAllCaps(false);
        save.setOnClickListener(v -> {
            GlobalKeyCaptureService.refreshHudOverlay();
            finish();
        });
        footer.addView(save, new LinearLayout.LayoutParams(-2, 44));
        root.addView(footer);
        setContentView(root);
        // Positions are stored in normalized full-display coordinates.
        // The editor preview is letterboxed to the real game aspect ratio;
        // only the display rotation is persisted for later conversion.
        editor.post(() -> prefs.edit()
                .putInt("hud_layout_rotation", getWindowManager().getDefaultDisplay().getRotation())
                .putInt("hud_coordinate_schema", 2)
                .apply());
    }

    @Override public void onBackPressed() {
        GlobalKeyCaptureService.refreshHudOverlay();
        super.onBackPressed();
    }
}
