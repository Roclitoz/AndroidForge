package com.haze.mapper;

import android.content.SharedPreferences;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;

/**
 * HUD positions are stored in normalized FULL-DISPLAY coordinates (0..1),
 * never in editor-preview coordinates. The editor letterboxes its preview
 * to the display aspect ratio; this class only applies display rotation and
 * converts normalized coordinates to current physical display pixels.
 */
public final class HudCoordinateMapper {
    private HudCoordinateMapper() {}

    public static int[] toScreen(SharedPreferences hud, WindowManager wm, float nx, float ny) {
        DisplayMetrics dm = new DisplayMetrics();
        Display display = wm == null ? null : wm.getDefaultDisplay();
        if (display != null) display.getRealMetrics(dm);
        int screenW = Math.max(1, dm.widthPixels);
        int screenH = Math.max(1, dm.heightPixels);

        float sx = clamp(nx);
        float sy = clamp(ny);
        int savedRotation = hud.getInt("hud_layout_rotation",
                display == null ? 0 : display.getRotation());
        int currentRotation = display == null ? savedRotation : display.getRotation();
        float[] rotated = rotateBetweenDisplayOrientations(sx, sy, savedRotation, currentRotation);
        int x = Math.round(rotated[0] * (screenW - 1));
        int y = Math.round(rotated[1] * (screenH - 1));
        return new int[]{clamp(x, 0, screenW - 1), clamp(y, 0, screenH - 1), screenW, screenH};
    }

    static float[] rotateBetweenDisplayOrientations(float x, float y, int from, int to) {
        int delta = ((to - from) % 4 + 4) % 4;
        switch (delta) {
            case 1: return new float[]{1f - y, x};
            case 2: return new float[]{1f - x, 1f - y};
            case 3: return new float[]{y, 1f - x};
            default: return new float[]{x, y};
        }
    }

    private static float clamp(float v) { return Math.max(0f, Math.min(1f, v)); }
    private static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
}
