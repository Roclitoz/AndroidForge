package com.haze.mapper;

import android.content.Context;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.Surface;
import android.view.WindowManager;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Bounded, private diagnostic log. No key contents, files, contacts or personal data are collected. */
public final class DiagnosticLog {
    private static final String FILE_NAME = "haze-diagnostics.log";
    private static final long MAX_BYTES = 512L * 1024L;
    private static final Object LOCK = new Object();
    private static final SimpleDateFormat FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US);
    private DiagnosticLog() {}

    public static void initialize(Context context) {
        write(context, "APP", "START version=" + version(context) + " sdk=" + Build.VERSION.SDK_INT
                + " device=" + Build.MANUFACTURER + "/" + Build.MODEL + " android=" + Build.VERSION.RELEASE
                + " display=" + display(context));
    }

    public static void write(Context context, String category, String message) {
        if (context == null || message == null) return;
        synchronized (LOCK) {
            try {
                File dir = new File(context.getFilesDir(), "diagnostics");
                if (!dir.exists() && !dir.mkdirs()) return;
                File file = new File(dir, FILE_NAME);
                if (file.exists() && file.length() + message.length() + 128 > MAX_BYTES) {
                    File old = new File(dir, FILE_NAME + ".1");
                    if (old.exists()) old.delete();
                    if (!file.renameTo(old)) file.delete();
                }
                try (BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file, true), "UTF-8"))) {
                    out.write(FORMAT.format(new Date()));
                    out.write(" ["); out.write(category == null ? "GENERAL" : category);
                    out.write("] "); out.write(message.replace('\n', ' ')); out.newLine();
                }
            } catch (Throwable ignored) { }
        }
    }

    public static File currentFile(Context context) {
        return new File(new File(context.getFilesDir(), "diagnostics"), FILE_NAME);
    }

    public static File previousFile(Context context) {
        return new File(new File(context.getFilesDir(), "diagnostics"), FILE_NAME + ".1");
    }

    private static String display(Context context) {
        try {
            WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(dm);
            int rotation = wm.getDefaultDisplay().getRotation();
            String r = rotation == Surface.ROTATION_0 ? "0" : rotation == Surface.ROTATION_90 ? "90" : rotation == Surface.ROTATION_180 ? "180" : "270";
            return dm.widthPixels + "x" + dm.heightPixels + " rotation=" + r;
        } catch (Throwable t) { return "unavailable:" + t.getClass().getSimpleName(); }
    }

    private static String version(Context context) {
        try { return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName; }
        catch (Throwable t) { return "unknown"; }
    }
}
