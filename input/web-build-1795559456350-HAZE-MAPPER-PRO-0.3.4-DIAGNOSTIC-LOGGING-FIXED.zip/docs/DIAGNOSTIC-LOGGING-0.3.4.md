# Haze Mapper Pro — Diagnostic Logging 0.3.4

## Purpose
Persist a bounded diagnostic trace so input/capture/coordinate/backend behavior can be reviewed from a real device report.

## Storage and export
- Internal app-private storage: `files/diagnostics/haze-diagnostics.log`.
- Active file is capped at approximately 512 KiB; the previous file is rotated to `haze-diagnostics.log.1`.
- Main screen action `EXPORTAR LOGS DE DIAGNÓSTICO` uses Android Storage Access Framework (`ACTION_CREATE_DOCUMENT`) to export both files as `haze-diagnostics.txt`. No storage permission is requested.

## Captured events
- App start, version, Android release/API, device model, display dimensions and rotation.
- Accessibility service connect/interrupt/destroy and foreground package transitions.
- Physical key code, DOWN/UP, repeat count and input device ID (not typed text).
- Key-to-control mapping, duplicate/release behavior, action contact request and backend response.
- Display dimensions, rotation, requested screen point, normalized HUD point, transform mode.
- Native backend response including control ID, multitouch slot, normalized coordinates, raw uinput coordinates, and SYN_REPORT status.
- Joystick vector changes and safety-release events.
- Calibration target, raw injected coordinate, observed MotionEvent coordinate, viewport, residual error and matrix.
- Shizuku/UserService IPC operation results, including device diagnostics and `getevent -lp` output.

## Privacy and performance
- Logs do not record typed text, passwords, message contents, contacts, files, or account identifiers. Key codes are recorded only to diagnose physical input mapping.
- Writes are serialized and append-only; rotation bounds storage. No per-frame mouse motion or 45 ms joystick heartbeat is logged.
- Export is user-initiated and uses the Android document picker.

## Reading a report
Correlate `KEY_EVENT` -> `KEY_MAPPING` -> `KEY_TOUCH_REQUEST` -> `KEY_TOUCH_RESULT`. For calibration, correlate `CALIBRATION_TARGET` -> `CALIBRATION_MOTION_EVENT` -> `CALIBRATION_RESULT`. A successful Binder/native return confirms only that the backend accepted/wrote the event; it does not by itself prove that the game received the touch at the intended location.
