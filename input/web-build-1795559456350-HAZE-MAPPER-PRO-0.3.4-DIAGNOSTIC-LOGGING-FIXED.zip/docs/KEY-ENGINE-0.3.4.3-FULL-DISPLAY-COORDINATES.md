# HAZE MAPPER PRO 0.3.4.3 — Full-display HUD coordinate model

## Objective
Correct the persistent mismatch between the position selected in the HUD editor and the touchscreen coordinate injected by the Key Engine.

## Root cause addressed
The previous editor stored positions as percentages of its own available View rectangle. That rectangle includes app layout constraints and does not necessarily have the same aspect ratio as the actual game display. The mapper then converted that preview-local percentage into physical display coordinates, so the preview percentage was incorrectly treated as a game-screen percentage.

## New coordinate contract
- Every control position (`*_x`, `*_y`) is normalized against the full game display, from 0.0 to 1.0.
- The editor preview is letterboxed to the real display aspect ratio.
- Dragging a control converts its preview position back into full-display normalized coordinates.
- Overlay rendering and keyboard-triggered injection both use the same normalized full-display values.
- Display rotation is stored separately as `hud_layout_rotation`; rotation conversion occurs only when the current display rotation differs.
- The preview's header/footer and unused letterbox areas no longer distort control coordinates.

## Preserved
- Analog Engine and WASD controller implementation unchanged.
- KeyStateManager and independent key-contact behavior unchanged.
- Native multitouch slots and JNI injection unchanged.
- Roadmap unchanged: 0.3.4 Key Engine → 0.3.5 Vista → 0.3.6 Visual HUD Editor → 0.4.0 Integration & Stability.

## Validation
- Static source checks confirm both overlay positioning and physical-key injection call the same HudCoordinateMapper.
- Geometry round-trip tests cover wide and tall editor containers while preserving the full-display normalized position.
- Android compilation and physical touch alignment still require AndroidForge build and device testing.
