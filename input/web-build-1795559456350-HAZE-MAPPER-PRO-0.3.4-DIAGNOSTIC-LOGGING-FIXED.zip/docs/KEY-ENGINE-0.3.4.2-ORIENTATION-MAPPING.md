# HAZE MAPPER PRO 0.3.4.2 — Orientation-aware HUD coordinates

## Scope
This patch only addresses the current HUD touch-coordinate mismatch. The development roadmap is unchanged: 0.3.4 Key Engine, 0.3.5 Vista, 0.3.6 Visual HUD Editor, 0.4.0 Integration & Stability.

## Source finding
The previous mapper persisted the editor preview rectangle but did not persist the display rotation. It then applied that old rectangle directly to the current display dimensions. If the display orientation changed after editing, the mapped point could exceed the current display bounds and be silently clamped to an edge (consistent with the diagnostic X=1079 on a 1080-pixel-wide display).

## Change
- Persist the editor display rotation together with its real dimensions and preview rectangle.
- Convert the saved preview point into normalized full-display coordinates.
- Rotate that normalized point from the editor's saved display orientation into the current display orientation.
- Scale only after rotation, using the current real display dimensions.
- Keep the old normalized fallback when no valid editor geometry exists.
- Leave the WASD/VirtualStickController and native joystick slot logic unchanged.

## Validation
A pure Java smoke test covers all four relative display rotations. Android build and on-device touch alignment are not validated in this environment. The physical test must compare the visual HUD center with the diagnostic injected coordinate in both portrait and landscape before testing Free Fire actions.
