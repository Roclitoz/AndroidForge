# HAZE MAPPER PRO 0.3.4.1 — HUD Coordinate Fix

## Problem addressed
The HUD editor stores each control center as normalized coordinates relative to the editor preview View. The global service previously multiplied those values by the full physical display dimensions. The preview View excludes the editor header, options/footer, and root padding, so the injected touch could land at a different screen position from the visible control.

## Fix
- HudEditorActivity records the preview View's actual on-screen rectangle after layout.
- HudCoordinateMapper converts normalized preview coordinates to absolute display pixels using that rectangle.
- Both the floating HUD overlay and physical-key action injection use the same conversion.
- A full-display fallback remains for older layouts if no preview geometry has been recorded.
- Global input diagnostics now expose the last mapped action, DOWN/UP phase, absolute coordinate, display size, and native backend result.

## Preserved behavior
- WASD / VirtualStickController logic is unchanged.
- Native joystick contact remains on multitouch slot 1.
- Action key contacts remain independent on slots 3–5.
- The KeyStateManager reference-count behavior is unchanged.

## Validation status
- Source-level coordinate-path inspection completed.
- Java/Android build and device injection test still required; this environment does not have the Android SDK/Gradle toolchain configured.
