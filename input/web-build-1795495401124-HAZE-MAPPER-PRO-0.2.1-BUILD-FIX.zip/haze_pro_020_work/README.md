# HAZE MAPPER 0.1.12 — INPUT AXIS FIX + HUD TOUCH OVERLAY

## Correções desta revisão
- Corrige a transformação de coordenadas observada no Galaxy A17 em paisagem: a calibração do analógico agora é interpretada em coordenadas da tela e convertida para o referencial bruto do touchscreen virtual.
- Corrige a matriz WASD conforme o teste relatado: W/S passam a representar cima/baixo e A/D esquerda/direita, compensando a transformação refletida do dispositivo virtual.
- Mantém o contato do analógico no slot 1 e adiciona heartbeat de 45 ms enquanto uma direção permanece pressionada, para evitar que o jogo perca o movimento por falta de atualizações.
- Gerencia BTN_TOUCH pelo estado agregado dos contatos (slot de teste, joystick e HUD), evitando que soltar um dedo encerre outro contato simultâneo.
- Adiciona HUD flutuante por Accessibility Overlay para FIRE/JUMP/RELOAD; pressionar um controle envia DOWN/UP real no touchscreen virtual. As posições/tamanho/opacidade usam o editor já existente.
- A tecla Vista e o botão flutuante VISTA alternam o estado global e suspendem/retomam o dedo do analógico. O overlay de botões continua clicável no modo Vista.

## Importante sobre Vista
Esta versão implementa a suspensão/retomada do joystick e o estado de modo Vista. Ela ainda não implementa captura global do movimento físico do mouse nem um cursor virtual próprio. Não deve ser descrita como substituto completo do modo mouse/câmera do GG Mouse Pro até essa camada ser implementada e testada.

## Ativação
1. Compile e instale o APK pelo AndroidForge.
2. Conecte Shizuku, inicie o UserService e ative a captura de acessibilidade.
3. Inicie o touchscreen virtual.
4. Ative WASD → analógico.
5. Abra o editor e ajuste as posições/tamanhos dos controles FIRE/JUMP/RELOAD para coincidir com o HUD do Free Fire.
6. Ative “HUD flutuante com cliques reais”. Teste primeiro numa sala/área segura.
7. Teste Vista: alternar deve soltar/suspender o joystick; desativar Vista com WASD ainda pressionado deve retomar o movimento.

## Limitações / validação pendente
- A transformação de coordenadas foi inferida a partir dos quatro sentidos relatados; confirmar no Galaxy A17 em paisagem antes de considerar calibrada.
- A camada de HUD atualmente tem FIRE/JUMP/RELOAD e um contato HUD simultâneo; múltiplos botões pressionados simultaneamente ainda exigem slots independentes.
- Vista ainda não captura globalmente o mouse físico.
- O projeto-fonte não é APK. Validar o build no AndroidForge (compileSdk 35, NDK/CMake, ABI arm64-v8a).


## 0.2.1 — correção de build
- Adicionada a string `global_key_capture_description`, exigida pela configuração do serviço de acessibilidade.
- Incrementados `versionCode` e `versionName` para 21 / 0.2.1.
