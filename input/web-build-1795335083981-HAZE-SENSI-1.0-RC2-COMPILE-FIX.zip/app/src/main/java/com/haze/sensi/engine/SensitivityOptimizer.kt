package com.haze.sensi.engine

/** Feedback observed by the player after testing the same movement in Free Fire. */
enum class GameFeedback(val label: String) { OVERSHOOT("Passou do alvo"), UNDERSHOOT("Ficou abaixo"), HIT("Acertou"), UNSTABLE("Instável") }
enum class MobiladorAxis(val label: String) { HORIZONTAL("Horizontal"), VERTICAL("Vertical"), SWITCHED("Comutada") }

data class MobiladorSettings(
    val mouseDpi: Int? = null,
    val phoneDpi: Int? = null,
    val counterAcceleration: String = "",
    val horizontal: Double? = null,
    val vertical: Double? = null,
    val switched: Double? = null,
    val switchedEnabled: Boolean = false,
    val sensitivityMaximum: Double = 100.0,
    val adjustmentStep: Double = 1.0
)

data class TuningProposal(val axis: MobiladorAxis, val before: Double, val after: Double, val reason: String)

/**
 * Conservative, feedback-driven tuner. It deliberately does not invent a universal GG Mouse preset.
 * Only the selected sensitivity field is changed; DPI and acceleration remain contextual inputs.
 */
object SensitivityOptimizer {
    fun refine(settings: MobiladorSettings, axis: MobiladorAxis, feedback: GameFeedback): TuningProposal? {
        if (feedback == GameFeedback.HIT || feedback == GameFeedback.UNSTABLE) return null
        if (axis == MobiladorAxis.SWITCHED && !settings.switchedEnabled) return null
        val current = when (axis) {
            MobiladorAxis.HORIZONTAL -> settings.horizontal
            MobiladorAxis.VERTICAL -> settings.vertical
            MobiladorAxis.SWITCHED -> settings.switched
        } ?: return null
        val max = settings.sensitivityMaximum
        if (!max.isFinite() || max <= 0.0 || current < 0.0 || current > max) return null
        val step = settings.adjustmentStep.coerceIn(0.1, max)
        val delta = if (feedback == GameFeedback.OVERSHOOT) -step else step
        val next = (current + delta).coerceIn(0.0, max)
        if (next == current) return null
        val reason = if (feedback == GameFeedback.OVERSHOOT)
            "Redução pequena: a mira ultrapassou o alvo. Mantenha DPI e aceleração iguais durante a comparação."
        else "Aumento pequeno: a mira ficou abaixo do alvo. Mantenha DPI e aceleração iguais durante a comparação."
        return TuningProposal(axis, current, next, reason)
    }
}

/** Final profile is released only after all six protocols and six feedback answers are complete. */
data class HazeAiRecommendation(
    val horizontal: Double,
    val vertical: Double,
    val switched: Double?,
    val confidence: String,
    val summary: String
)

object HazeAiEngine {
    fun generate(
        currentHorizontal: Double?, currentVertical: Double?, currentSwitched: Double?, switchedEnabled: Boolean,
        maximum: Double, gameFeedback: GameFeedback, affectedDirection: String,
        stability: String, consistency: String, dragDistance: String, aimScope: String,
        averageStraightness: Double, trackingSummary: String, setupSummary: String,
        completedTestCount: Int, attemptsPerTest: Int
    ): HazeAiRecommendation? {
        if (completedTestCount != 6 || attemptsPerTest < 3 || maximum <= 0.0 || !maximum.isFinite()) return null
        val h = currentHorizontal ?: return null
        val v = currentVertical ?: return null
        if (stability.isBlank() || consistency.isBlank() || dragDistance.isBlank() || aimScope.isBlank()) return null
        val unstableEvidence = stability == "Oscila / treme" || consistency == "Varia entre tentativas" || averageStraightness < 0.55
        fun adjusted(value: Double, apply: Boolean): Double {
            if (!apply || unstableEvidence || gameFeedback == GameFeedback.UNSTABLE) return value.coerceIn(0.0, maximum)
            val factor = when (dragDistance) { "Curta" -> 0.02; "Longa" -> 0.04; else -> 0.03 }
            val delta = (maximum * factor).coerceAtLeast(0.5)
            val next = when (gameFeedback) {
                GameFeedback.OVERSHOOT -> value - delta
                GameFeedback.UNDERSHOOT -> value + delta
                GameFeedback.HIT, GameFeedback.UNSTABLE -> value
            }
            return next.coerceIn(0.0, maximum)
        }
        val affectH = affectedDirection == "Horizontal" || affectedDirection == "Horizontal e vertical"
        val affectV = affectedDirection == "Vertical" || affectedDirection == "Horizontal e vertical"
        val confidence = if (consistency == "Quase sempre igual" && stability == "Estável" && averageStraightness >= 0.75) "Boa consistência" else "Consistência moderada"
        val summary = if (unstableEvidence || gameFeedback == GameFeedback.UNSTABLE) {
            "Sem alteração automática: tracking/feedback indicam oscilação. Repita a calibração com DPI e aceleração fixos."
        } else when (gameFeedback) {
            GameFeedback.OVERSHOOT -> "Redução conservadora nos eixos selecionados: a mira ultrapassou o alvo."
            GameFeedback.UNDERSHOOT -> "Aumento conservador nos eixos selecionados: a mira ficou abaixo do alvo."
            GameFeedback.HIT -> "Sem alteração: o feedback indica que a mira já está acertando o alvo."
            GameFeedback.UNSTABLE -> "Sem alteração automática: estabilize a resposta e repita os testes."
        } + " Mira avaliada: $aimScope. Linearidade média do tracking: ${(averageStraightness * 100).toInt()}%. $trackingSummary Configuração registrada: $setupSummary."
        return HazeAiRecommendation(
            horizontal = adjusted(h, affectH), vertical = adjusted(v, affectV),
            switched = if (switchedEnabled) currentSwitched?.let { adjusted(it, affectH || affectV) } else null,
            confidence = confidence, summary = summary
        )
    }
}
