package com.haze.sensi

import android.content.Context
import com.haze.sensi.model.MappingProfile
import com.haze.sensi.model.MotionMetrics
import org.json.JSONArray
import org.json.JSONObject

/** Local-only storage for mobilador setup and calibration history. */
class MappingProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("haze_sensi_profiles", Context.MODE_PRIVATE)

    fun saveMapping(p: MappingProfile) {
        val json = JSONObject().apply {
            put("appVersion",p.appVersion); put("sensitivity",p.sensitivity)
            put("sensitivityX",p.sensitivityX); put("sensitivityY",p.sensitivityY)
            put("acceleration",p.acceleration); put("smoothing",p.smoothing)
            put("deadzone",p.deadzone); put("responseCurve",p.responseCurve)
            put("aimButtonBehavior",p.aimButtonBehavior); put("controlProfile",p.controlProfile)
            put("switchedSensitivity",p.switchedSensitivity); put("sensitivityMaximum",p.sensitivityMaximum)
            put("switchedEnabled",p.switchedEnabled); put("mouseDpi",p.mouseDpi); put("phoneDpi",p.phoneDpi)
            put("antiShakeActive",p.antiShakeActive); put("antiShakeConfigured",p.antiShakeConfigured)
            put("pollingRate",p.pollingRate); put("pointerSpeed",p.pointerSpeed)
            put("secondScreenWidth",p.secondScreenWidth); put("secondScreenHeight",p.secondScreenHeight)
            put("secondScreenRefreshRate",p.secondScreenRefreshRate); put("screenOrientation",p.screenOrientation)
            put("mappingMode",p.mappingMode); put("screenScale",p.screenScale); put("extraNotes",p.extraNotes)
            put("mouseSensor",p.mouseSensor); put("androidVersion",p.androidVersion); put("androidBrand",p.androidBrand)
            put("switchedHorizontal",p.switchedHorizontal); put("switchedVertical",p.switchedVertical)
        }
        prefs.edit().putString("mapping_profile",json.toString()).apply()
    }

    fun loadMapping(): MappingProfile {
        val j = runCatching { JSONObject(prefs.getString("mapping_profile","{}") ?: "{}") }.getOrDefault(JSONObject())
        return MappingProfile(
            appVersion=j.optString("appVersion","GG Mouse Pro 3 (padrão)").ifBlank { "GG Mouse Pro 3 (padrão)" }, sensitivity=j.optString("sensitivity"),
            sensitivityX=j.optString("sensitivityX"), sensitivityY=j.optString("sensitivityY"),
            acceleration=j.optString("acceleration"), smoothing=j.optString("smoothing"),
            deadzone=j.optString("deadzone"), responseCurve=j.optString("responseCurve"),
            aimButtonBehavior=j.optString("aimButtonBehavior"), controlProfile=j.optString("controlProfile"),
            switchedSensitivity=j.optString("switchedSensitivity"), sensitivityMaximum=j.optString("sensitivityMaximum","100"),
            switchedEnabled=j.optBoolean("switchedEnabled",false), mouseDpi=j.optString("mouseDpi"),
            phoneDpi=j.optString("phoneDpi",j.optString("androidDisplayDpi")),
            antiShakeActive=j.optBoolean("antiShakeActive",false), antiShakeConfigured=j.optBoolean("antiShakeConfigured",false),
            pollingRate=j.optString("pollingRate"), pointerSpeed=j.optString("pointerSpeed"),
            secondScreenWidth=j.optString("secondScreenWidth"), secondScreenHeight=j.optString("secondScreenHeight"),
            secondScreenRefreshRate=j.optString("secondScreenRefreshRate"), screenOrientation=j.optString("screenOrientation","Paisagem"),
            mappingMode=j.optString("mappingMode","Mouse + teclado"), screenScale=j.optString("screenScale"), extraNotes=j.optString("extraNotes"),
            mouseSensor=j.optString("mouseSensor","Sensor genérico (baixo orçamento)"), androidVersion=j.optString("androidVersion","17"), androidBrand=j.optString("androidBrand","Samsung"),
            switchedHorizontal=j.optString("switchedHorizontal"), switchedVertical=j.optString("switchedVertical")
        )
    }

    fun saveLabProgress(attempts: Map<String, List<MotionMetrics>>, answers: List<String>) {
        val tests = JSONObject()
        attempts.forEach { (name, metrics) ->
            val array = JSONArray()
            metrics.forEach { m -> array.put(JSONObject().apply {
                put("sampleCount",m.sampleCount); put("pathLengthPx",m.pathLengthPx.toDouble()); put("netDistancePx",m.netDistancePx.toDouble())
                put("durationMs",m.durationMs); put("averageSpeedPxPerSecond",m.averageSpeedPxPerSecond.toDouble()); put("peakSpeedPxPerSecond",m.peakSpeedPxPerSecond.toDouble())
                put("straightness",m.straightness.toDouble()); put("endpointErrorPx",m.endpointErrorPx.toDouble()); put("hitTarget",m.hitTarget)
            }) }
            tests.put(name,array)
        }
        val answerArray=JSONArray().apply { answers.forEach { put(it) } }
        prefs.edit().putString("lab_progress",JSONObject().put("tests",tests).put("answers",answerArray).toString()).apply()
    }

    fun loadLabProgress(): Pair<Map<String,List<MotionMetrics>>,List<String>> {
        val root=runCatching { JSONObject(prefs.getString("lab_progress","{}") ?: "{}") }.getOrDefault(JSONObject())
        val tests=root.optJSONObject("tests") ?: JSONObject()
        val result=mutableMapOf<String,List<MotionMetrics>>()
        val keys=tests.keys()
        while(keys.hasNext()) {
            val key=keys.next(); val arr=tests.optJSONArray(key) ?: JSONArray()
            result[key]=(0 until minOf(arr.length(),3)).mapNotNull { i ->
                val m=arr.optJSONObject(i) ?: return@mapNotNull null
                MotionMetrics(m.optInt("sampleCount"),m.optDouble("pathLengthPx").toFloat(),m.optDouble("netDistancePx").toFloat(),m.optLong("durationMs"),m.optDouble("averageSpeedPxPerSecond").toFloat(),m.optDouble("peakSpeedPxPerSecond").toFloat(),m.optDouble("straightness").toFloat(),m.optDouble("endpointErrorPx").toFloat(),m.optBoolean("hitTarget"))
            }
        }
        val answers=root.optJSONArray("answers") ?: JSONArray()
        return result to (0 until 6).map { answers.optString(it,"") }
    }

    fun addHistory(summary:String) {
        val entries=runCatching { JSONArray(prefs.getString("calibration_history","[]") ?: "[]") }.getOrDefault(JSONArray())
        val updated=JSONArray().put(summary).also { out -> for(i in 0 until minOf(entries.length(),39)) out.put(entries.optString(i)) }
        prefs.edit().putString("calibration_history",updated.toString()).apply()
    }
    fun loadHistory():List<String> {
        val a=runCatching { JSONArray(prefs.getString("calibration_history","[]") ?: "[]") }.getOrDefault(JSONArray())
        return (0 until a.length()).mapNotNull { a.optString(it).takeIf(String::isNotBlank) }
    }
}
