# HAZE MAPPER 0.1.4 — HUD Editor Prototype

Baseado no HAZE MAPPER 0.1.3 que reconhece Shizuku, mouse e teclado.

## Novidades desta versão
- Editor visual de HUD com controles W/A/S/D, FIRE, JUMP, RELOAD e VISTA.
- Arraste os controles no quadro para ajustar as posições.
- Posições normalizadas salvas automaticamente em SharedPreferences.
- Tecla configurável para alternar o estado do modo Vista (padrão F1).
- Indicador de estado: movimentar câmera ou cursor/clique.

## Limitações importantes
Esta é uma etapa de interface/configuração. O quadro do editor ainda é uma prévia dentro do app, não uma janela flutuante sobre o jogo. O modo Vista nesta versão alterna o estado visual enquanto o app está em foco; ainda não redireciona os eventos físicos para um cursor real nem injeta toques contínuos no jogo. O motor 0.1.3 ainda usa comandos `input tap/swipe` para testes e não é um backend completo de mapeamento.

Para a próxima etapa, integrar o layout salvo ao serviço de overlay e ao backend de toque virtual, com teste de captura/liberação dos dispositivos no aparelho.

## Build
Abra o projeto no Android Studio/AndroidForge e compile o módulo `app` com Gradle. `versionCode=5`, `versionName=0.1.4`.

## Correção 0.1.4-fix1
- Corrigido o uso de `KeyEvent.isRepeated()`, método inexistente no Android SDK.
- A detecção de primeiro pressionamento agora usa `KeyEvent.getRepeatCount() == 0`.
