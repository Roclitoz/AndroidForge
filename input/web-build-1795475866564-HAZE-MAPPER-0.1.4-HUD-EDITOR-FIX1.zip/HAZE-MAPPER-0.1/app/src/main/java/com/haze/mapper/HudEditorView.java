package com.haze.mapper;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

/** Draggable normalized HUD layout editor. Positions survive app restarts. */
public final class HudEditorView extends View {
    private static final String PREFS = "haze_hud";
    private static final String[] IDS = {"W", "A", "S", "D", "FIRE", "JUMP", "RELOAD", "VISTA"};
    private final SharedPreferences prefs;
    private final List<RectF> items = new ArrayList<>();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int selected = -1;
    private float downX, downY, startX, startY;
    private float radius;

    public HudEditorView(Context context) {
        super(context);
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    private float px(String id, String axis, float fallback) {
        return prefs.getFloat(id + "_" + axis, fallback);
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        c.drawColor(0xFF171923);
        paint.setColor(0xFF252B3A); paint.setStyle(Paint.Style.FILL);
        c.drawRoundRect(new RectF(12, 12, w - 12, h - 12), 22, 22, paint);
        paint.setColor(0xFF46516A); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(2);
        c.drawRoundRect(new RectF(22, 22, w - 22, h - 22), 18, 18, paint);
        radius = Math.max(25, Math.min(w, h) * 0.055f);
        items.clear();
        float[][] defaults = {{.15f,.68f},{.08f,.77f},{.15f,.86f},{.22f,.77f},{.86f,.76f},{.75f,.62f},{.88f,.48f},{.50f,.90f}};
        for (int i=0;i<IDS.length;i++) {
            float x = px(IDS[i], "x", defaults[i][0]) * w;
            float y = px(IDS[i], "y", defaults[i][1]) * h;
            RectF r = new RectF(x-radius, y-radius, x+radius, y+radius); items.add(r);
            paint.setStyle(Paint.Style.FILL); paint.setColor(i==selected?0xFF8B5CF6:0xDD34415B); c.drawRoundRect(r, 14, 14, paint);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(2); paint.setColor(0xFFB9C4D8); c.drawRoundRect(r,14,14,paint);
            paint.setStyle(Paint.Style.FILL); paint.setColor(0xFFFFFFFF); paint.setTextAlign(Paint.Align.CENTER); paint.setTextSize(IDS[i].length()>4?radius*.42f:radius*.58f);
            c.drawText(IDS[i], x, y + paint.getTextSize()*.34f, paint);
        }
        paint.setTextAlign(Paint.Align.LEFT); paint.setTextSize(13); paint.setColor(0xFFCFD6E5);
        c.drawText("ARRASTE OS BOTÕES PARA POSICIONAR", 28, 48, paint);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x=e.getX(), y=e.getY();
        if (e.getAction()==MotionEvent.ACTION_DOWN) {
            selected=-1;
            for(int i=items.size()-1;i>=0;i--) if(items.get(i).contains(x,y)){selected=i;break;}
            if(selected>=0){downX=x;downY=y;startX=items.get(selected).centerX();startY=items.get(selected).centerY(); invalidate(); return true;}
        } else if(e.getAction()==MotionEvent.ACTION_MOVE && selected>=0) {
            float nx=Math.max(radius+12,Math.min(getWidth()-radius-12,startX+x-downX));
            float ny=Math.max(radius+60,Math.min(getHeight()-radius-12,startY+y-downY));
            String id=IDS[selected]; prefs.edit().putFloat(id+"_x",nx/getWidth()).putFloat(id+"_y",ny/getHeight()).apply(); invalidate(); return true;
        } else if((e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL) && selected>=0) { selected=-1; invalidate(); return true; }
        return true;
    }
}
