# Haze Mapper Pro 0.3.3 — Coordinate Calibration

Fonte do projeto. Abra `haze_031_work` no Android Studio e compile `assembleDebug`. Esta versão adiciona calibração afim baseada nos MotionEvents realmente devolvidos pelo Android para o dispositivo uinput HAZE.

APK não incluído. A compilação Android/NDK e o teste no Galaxy A17 ainda precisam ser executados. Ver `docs/COORDINATE-CALIBRATION-0.3.3.md`.
