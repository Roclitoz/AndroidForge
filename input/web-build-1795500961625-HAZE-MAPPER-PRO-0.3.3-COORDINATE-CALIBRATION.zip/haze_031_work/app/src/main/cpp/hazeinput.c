#include <jni.h>
#include <linux/input.h>
#include <linux/uinput.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <time.h>
#include <math.h>

static int g_fd = -1;
static int g_tracking = 1;
static int g_joystick_down = 0;
static int g_test_down = 0;
static int g_hud_down = 0;
static int g_hud_tracking = 2000;
static int g_joystick_tracking = 1000;
static const int MAX_X = 32767;
static const int MAX_Y = 32767;
static int g_calibration_valid = 0;
static float g_screen_to_raw[6] = {1.f,0.f,0.f,0.f,1.f,0.f};

static jstring js(JNIEnv *env, const char *s) { return (*env)->NewStringUTF(env, s); }
static int emit(int fd, unsigned short type, unsigned short code, int value) {
    struct input_event ev; memset(&ev, 0, sizeof(ev));
    ev.type = type; ev.code = code; ev.value = value;
    return write(fd, &ev, sizeof(ev)) == sizeof(ev) ? 0 : -1;
}
static int setup_device(int fd) {
    if (ioctl(fd, UI_SET_EVBIT, EV_SYN) < 0) return -1;
    if (ioctl(fd, UI_SET_EVBIT, EV_KEY) < 0) return -1;
    if (ioctl(fd, UI_SET_KEYBIT, BTN_TOUCH) < 0) return -1;
    if (ioctl(fd, UI_SET_EVBIT, EV_ABS) < 0) return -1;
    if (ioctl(fd, UI_SET_PROPBIT, INPUT_PROP_DIRECT) < 0) return -1;
    const int abs_codes[] = {ABS_MT_SLOT, ABS_MT_TRACKING_ID, ABS_MT_POSITION_X, ABS_MT_POSITION_Y, ABS_MT_PRESSURE};
    const int mins[] = {0, 0, 0, 0, 0};
    const int maxs[] = {9, 65535, MAX_X, MAX_Y, 255};
    for (int i=0; i<5; i++) {
        if (ioctl(fd, UI_SET_ABSBIT, abs_codes[i]) < 0) return -1;
        struct uinput_abs_setup a; memset(&a, 0, sizeof(a));
        a.code = abs_codes[i]; a.absinfo.minimum = mins[i]; a.absinfo.maximum = maxs[i];
        if (ioctl(fd, UI_ABS_SETUP, &a) < 0) return -1;
    }
    struct uinput_setup setup; memset(&setup, 0, sizeof(setup));
    snprintf(setup.name, UINPUT_MAX_NAME_SIZE, "HAZE Virtual Touchscreen");
    setup.id.bustype = BUS_VIRTUAL; setup.id.vendor = 0x4841; setup.id.product = 0x5E01; setup.id.version = 1;
    if (ioctl(fd, UI_DEV_SETUP, &setup) < 0) return -1;
    if (ioctl(fd, UI_DEV_CREATE) < 0) return -1;
    struct timespec ts = {0, 150000000}; nanosleep(&ts, NULL);
    return 0;
}
static void close_fd(int fd) { if (fd >= 0) { ioctl(fd, UI_DEV_DESTROY); close(fd); } }
static void sync_btn_touch(void) {
    if (g_fd >= 0) emit(g_fd, EV_KEY, BTN_TOUCH, (g_test_down || g_joystick_down || g_hud_down) ? 1 : 0);
}

JNIEXPORT jstring JNICALL Java_com_haze_mapper_MapperUserService_nativeProbeTouch(JNIEnv *env, jclass cls) {
    int fd = open("/dev/uinput", O_WRONLY | O_NONBLOCK | O_CLOEXEC);
    if (fd < 0) { char b[256]; snprintf(b, sizeof(b), "UINPUT_OPEN_FAILED errno=%d (%s). Shizuku/ADB não tem acesso de escrita ao /dev/uinput neste firmware.", errno, strerror(errno)); return js(env,b); }
    if (setup_device(fd) < 0) { int e=errno; close_fd(fd); char b[256]; snprintf(b,sizeof(b),"UINPUT_CREATE_FAILED errno=%d (%s). O nó abriu, mas o kernel recusou a configuração do touchscreen.",e,strerror(e)); return js(env,b); }
    close_fd(fd);
    return js(env,"UINPUT_CREATE_OK: touchscreen virtual criado e destruído com sucesso. Nenhum toque foi enviado.");
}
JNIEXPORT jstring JNICALL Java_com_haze_mapper_MapperUserService_nativeStartTouch(JNIEnv *env, jclass cls) {
    if (g_fd >= 0) return js(env,"TOUCH_DEVICE_ALREADY_ACTIVE");
    int fd = open("/dev/uinput", O_WRONLY | O_NONBLOCK | O_CLOEXEC);
    if (fd < 0) { char b[192]; snprintf(b,sizeof(b),"UINPUT_OPEN_FAILED errno=%d (%s)",errno,strerror(errno)); return js(env,b); }
    if (setup_device(fd) < 0) { int e=errno; close(fd); char b[192]; snprintf(b,sizeof(b),"UINPUT_CREATE_FAILED errno=%d (%s)",e,strerror(e)); return js(env,b); }
    g_fd=fd; g_tracking=1; g_test_down=0; g_joystick_down=0; g_hud_down=0; return js(env,"TOUCH_DEVICE_ACTIVE: dispositivo virtual criado. Ainda não há toque pressionado.");
}
JNIEXPORT jstring JNICALL Java_com_haze_mapper_MapperUserService_nativeTouchEvent(JNIEnv *env, jclass cls, jint action, jint x, jint y) {
    if (g_fd < 0) return js(env,"TOUCH_DEVICE_NOT_ACTIVE");
    if (x<0) x=0; if (x>MAX_X) x=MAX_X; if (y<0) y=0; if (y>MAX_Y) y=MAX_Y;
    int ok=0;
    if (action==0) { // DOWN
        ok |= emit(g_fd,EV_ABS,ABS_MT_SLOT,0); ok |= emit(g_fd,EV_ABS,ABS_MT_TRACKING_ID,g_tracking++);
        ok |= emit(g_fd,EV_ABS,ABS_MT_POSITION_X,x); ok |= emit(g_fd,EV_ABS,ABS_MT_POSITION_Y,y);
        ok |= emit(g_fd,EV_ABS,ABS_MT_PRESSURE,180); g_test_down=1; sync_btn_touch();
    } else if (action==1) { // MOVE
        ok |= emit(g_fd,EV_ABS,ABS_MT_SLOT,0); ok |= emit(g_fd,EV_ABS,ABS_MT_POSITION_X,x); ok |= emit(g_fd,EV_ABS,ABS_MT_POSITION_Y,y);
    } else if (action==2) { // UP
        ok |= emit(g_fd,EV_ABS,ABS_MT_SLOT,0); ok |= emit(g_fd,EV_ABS,ABS_MT_TRACKING_ID,-1);
        ok |= emit(g_fd,EV_ABS,ABS_MT_PRESSURE,0); g_test_down=0; sync_btn_touch();
    } else return js(env,"INVALID_TOUCH_ACTION (0=DOWN, 1=MOVE, 2=UP)");
    ok |= emit(g_fd,EV_SYN,SYN_REPORT,0);
    return ok==0 ? js(env,"TOUCH_EVENT_OK") : js(env,"TOUCH_EVENT_WRITE_FAILED");
}
JNIEXPORT jstring JNICALL Java_com_haze_mapper_MapperUserService_nativeStopTouch(JNIEnv *env, jclass cls) {
    if (g_fd < 0) return js(env,"TOUCH_DEVICE_NOT_ACTIVE");
    for (int slot=0; slot<=2; slot++) {
        emit(g_fd,EV_ABS,ABS_MT_SLOT,slot);
        emit(g_fd,EV_ABS,ABS_MT_TRACKING_ID,-1);
    }
    g_test_down=0; g_joystick_down=0; g_hud_down=0;
    emit(g_fd,EV_KEY,BTN_TOUCH,0); emit(g_fd,EV_SYN,SYN_REPORT,0);
    close_fd(g_fd);g_fd=-1; return js(env,"TOUCH_DEVICE_DESTROYED");
}

static float clamp01(float v) { if (v < 0.f) return 0.f; if (v > 1.f) return 1.f; return v; }
static void screen_to_raw(float sx, float sy, int mode, float *rx, float *ry) {
    sx=clamp01(sx); sy=clamp01(sy);
    if(g_calibration_valid){*rx=clamp01(g_screen_to_raw[0]*sx+g_screen_to_raw[1]*sy+g_screen_to_raw[2]);*ry=clamp01(g_screen_to_raw[3]*sx+g_screen_to_raw[4]*sy+g_screen_to_raw[5]);return;}
    switch (mode) {
        case 1: *rx=1.f-sx; *ry=sy; break; case 2: *rx=sx; *ry=1.f-sy; break;
        case 3: *rx=1.f-sx; *ry=1.f-sy; break; case 4: *rx=sy; *ry=sx; break;
        case 5: *rx=1.f-sy; *ry=sx; break; case 6: *rx=sy; *ry=1.f-sx; break;
        case 7: *rx=1.f-sy; *ry=1.f-sx; break; default: *rx=sx; *ry=sy; break;
    }
}
JNIEXPORT jstring JNICALL Java_com_haze_mapper_MapperUserService_nativeJoystickEvent(JNIEnv *env,jclass cls,jfloat x,jfloat y,jboolean active,jfloat cx,jfloat cy,jfloat rx,jfloat ry,jint transform) {
    if (g_fd < 0) return js(env, "TOUCH_DEVICE_NOT_ACTIVE");
    if (!active) { if (g_joystick_down) { emit(g_fd,EV_ABS,ABS_MT_SLOT,1); emit(g_fd,EV_ABS,ABS_MT_TRACKING_ID,-1); emit(g_fd,EV_ABS,ABS_MT_PRESSURE,0); g_joystick_down=0; sync_btn_touch(); emit(g_fd,EV_SYN,SYN_REPORT,0); } return js(env,"JOYSTICK_RELEASED"); }
    if(x < -1.f)x=-1.f;if(x>1.f)x=1.f;if(y < -1.f)y=-1.f;if(y>1.f)y=1.f;
    cx=clamp01(cx);cy=clamp01(cy);if(rx<.005f)rx=.005f;if(rx>.25f)rx=.25f;if(ry<.005f)ry=.005f;if(ry>.25f)ry=.25f;if(transform<0||transform>7)transform=0;
    float rcx,rcy,pxn,pyn;screen_to_raw(cx,cy,transform,&rcx,&rcy);screen_to_raw(cx+x*rx,cy-y*ry,transform,&pxn,&pyn);
    int px=(int)(pxn*MAX_X),py=(int)(pyn*MAX_Y),ok=0;
    ok|=emit(g_fd,EV_ABS,ABS_MT_SLOT,1);
    if(!g_joystick_down){ok|=emit(g_fd,EV_ABS,ABS_MT_TRACKING_ID,g_joystick_tracking++);ok|=emit(g_fd,EV_ABS,ABS_MT_POSITION_X,(int)(rcx*MAX_X));ok|=emit(g_fd,EV_ABS,ABS_MT_POSITION_Y,(int)(rcy*MAX_Y));ok|=emit(g_fd,EV_ABS,ABS_MT_PRESSURE,180);g_joystick_down=1;sync_btn_touch();ok|=emit(g_fd,EV_SYN,SYN_REPORT,0);}
    ok|=emit(g_fd,EV_ABS,ABS_MT_SLOT,1);ok|=emit(g_fd,EV_ABS,ABS_MT_POSITION_X,px);ok|=emit(g_fd,EV_ABS,ABS_MT_POSITION_Y,py);ok|=emit(g_fd,EV_ABS,ABS_MT_PRESSURE,180);ok|=emit(g_fd,EV_SYN,SYN_REPORT,0);
    return ok==0?js(env,"JOYSTICK_EVENT_OK"):js(env,"JOYSTICK_WRITE_FAILED");
}





JNIEXPORT jstring JNICALL Java_com_haze_mapper_MapperUserService_nativeSetCalibration(JNIEnv *env,jclass cls,jboolean valid,jfloat m0,jfloat m1,jfloat m2,jfloat m3,jfloat m4,jfloat m5){
    if(valid){float m[6]={m0,m1,m2,m3,m4,m5};for(int i=0;i<6;i++)if(!isfinite(m[i]))return js(env,"CALIBRATION_REJECTED_NONFINITE");float det=m0*m4-m1*m3;if(fabsf(det)<0.00001f)return js(env,"CALIBRATION_REJECTED_SINGULAR");for(int i=0;i<6;i++)g_screen_to_raw[i]=m[i];g_calibration_valid=1;return js(env,"CALIBRATION_APPLIED");}
    g_calibration_valid=0;g_screen_to_raw[0]=1.f;g_screen_to_raw[1]=0.f;g_screen_to_raw[2]=0.f;g_screen_to_raw[3]=0.f;g_screen_to_raw[4]=1.f;g_screen_to_raw[5]=0.f;return js(env,"CALIBRATION_CLEARED");
}

JNIEXPORT jstring JNICALL Java_com_haze_mapper_MapperUserService_nativeHudTouch(JNIEnv *env,jclass cls,jint action,jint screenX,jint screenY,jint screenW,jint screenH,jint transform) {
    if (g_fd < 0) return js(env, "TOUCH_DEVICE_NOT_ACTIVE");
    if (screenW <= 0 || screenH <= 0) return js(env, "INVALID_DISPLAY_SIZE");
    if (action == 0) {
        float sx=(float)screenX/(float)screenW, sy=(float)screenY/(float)screenH;
        if(sx<0.f)sx=0.f;if(sx>1.f)sx=1.f;if(sy<0.f)sy=0.f;if(sy>1.f)sy=1.f;
        float rawXn,rawYn;screen_to_raw(sx,sy,transform,&rawXn,&rawYn);int rawX=(int)(rawXn*MAX_X), rawY=(int)(rawYn*MAX_Y);
        emit(g_fd,EV_ABS,ABS_MT_SLOT,2);
        emit(g_fd,EV_ABS,ABS_MT_TRACKING_ID,g_hud_tracking++);
        emit(g_fd,EV_ABS,ABS_MT_POSITION_X,rawX);
        emit(g_fd,EV_ABS,ABS_MT_POSITION_Y,rawY);
        emit(g_fd,EV_ABS,ABS_MT_PRESSURE,180);
        g_hud_down=1; sync_btn_touch(); emit(g_fd,EV_SYN,SYN_REPORT,0);
        return js(env,"HUD_TOUCH_DOWN_OK");
    }
    if (action == 1) {
        if(g_hud_down){emit(g_fd,EV_ABS,ABS_MT_SLOT,2);emit(g_fd,EV_ABS,ABS_MT_TRACKING_ID,-1);emit(g_fd,EV_ABS,ABS_MT_PRESSURE,0);g_hud_down=0;sync_btn_touch();emit(g_fd,EV_SYN,SYN_REPORT,0);}
        return js(env,"HUD_TOUCH_UP_OK");
    }
    return js(env,"INVALID_HUD_TOUCH_ACTION");
}
