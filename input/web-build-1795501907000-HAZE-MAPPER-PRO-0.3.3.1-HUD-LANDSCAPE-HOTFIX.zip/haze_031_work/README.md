# Haze Mapper Pro 0.3.3.1 — HUD Landscape Hotfix

Projeto Android fonte. Abra `haze_031_work` no Android Studio e compile `assembleDebug`.

Esta atualização mantém a calibração 0.3.3 e corrige a tela do editor de HUD: o editor agora abre em uma Activity landscape dedicada, com área ampla para arrastar os controles. O motor WASD/analógico não foi alterado.

Consulte `docs/HUD-LANDSCAPE-HOTFIX-0.3.3.1.md` para alterações e roteiro de teste. APK não incluído; a compilação Android/NDK e validação no Galaxy A17 ainda precisam ser executadas.
