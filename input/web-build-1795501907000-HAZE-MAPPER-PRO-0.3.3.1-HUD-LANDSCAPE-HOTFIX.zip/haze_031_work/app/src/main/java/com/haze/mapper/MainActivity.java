package com.haze.mapper;

import android.app.Activity;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static volatile IBinder sharedRemote;
    private static final String GLOBAL_PREFS = "haze_global_input";

    public static void pushHudTouch(int action,int x,int y,int w,int h) { pushHudTouch(action,x,y,w,h,0); }
    public static void pushHudTouch(int action,int x,int y,int w,int h,int transform) {
        IBinder binder=sharedRemote;if(binder==null||!binder.isBinderAlive())return;
        Parcel data=Parcel.obtain(),reply=Parcel.obtain();
        try{data.writeInterfaceToken(MapperUserService.DESCRIPTOR);data.writeInt(action);data.writeInt(x);data.writeInt(y);data.writeInt(w);data.writeInt(h);data.writeInt(transform);binder.transact(MapperUserService.TRANSACTION_HUD_TOUCH,data,reply,0);reply.readException();reply.readString();}
        catch(Throwable ignored){}finally{data.recycle();reply.recycle();}
    }









    public static String sendRawTouchEvent(int action,int rawX,int rawY) {
        IBinder binder=sharedRemote;if(binder==null||!binder.isBinderAlive())return "MOTOR NÃO CONECTADO";
        Parcel data=Parcel.obtain(),reply=Parcel.obtain();try{data.writeInterfaceToken(MapperUserService.DESCRIPTOR);data.writeInt(action);data.writeInt(rawX);data.writeInt(rawY);boolean ok=binder.transact(MapperUserService.TRANSACTION_TOUCH_EVENT,data,reply,0);if(!ok)return "TOUCH_TRANSACTION_UNHANDLED";reply.readException();return reply.readString();}catch(Throwable t){return "ERRO IPC: "+t.getClass().getSimpleName();}finally{data.recycle();reply.recycle();}
    }
    public static String applyTouchCalibration(float[] m) {
        IBinder binder=sharedRemote;if(binder==null||!binder.isBinderAlive())return "MOTOR NÃO CONECTADO • matriz salva para próxima conexão";
        if(m==null||m.length!=6)return "MATRIZ INVÁLIDA";Parcel data=Parcel.obtain(),reply=Parcel.obtain();
        try{data.writeInterfaceToken(MapperUserService.DESCRIPTOR);data.writeInt(1);for(float v:m)data.writeFloat(v);boolean ok=binder.transact(MapperUserService.TRANSACTION_SET_CALIBRATION,data,reply,0);if(!ok)return "CALIBRATION_TRANSACTION_UNHANDLED";reply.readException();return reply.readString();}catch(Throwable t){return "ERRO IPC: "+t.getClass().getSimpleName();}finally{data.recycle();reply.recycle();}
    }
    private void restoreTouchCalibration(){android.content.SharedPreferences p=getSharedPreferences("haze_touch_calibration",MODE_PRIVATE);if(!p.getBoolean("valid",false))return;float[] m=new float[6];for(int i=0;i<6;i++)m[i]=p.getFloat("m"+i, i==0||i==4?1f:0f);applyTouchCalibration(m);}


    public static String sendSimpleCommand(int transaction) {
        IBinder binder=sharedRemote; if(binder==null || !binder.isBinderAlive()) return "MOTOR NÃO CONECTADO • inicie o UserService primeiro";
        Parcel data=Parcel.obtain(),reply=Parcel.obtain();
        try { data.writeInterfaceToken(MapperUserService.DESCRIPTOR); boolean ok=binder.transact(transaction,data,reply,0); if(!ok)return "OPERAÇÃO NÃO SUPORTADA"; reply.readException(); return reply.readString(); }
        catch(Throwable t){return "ERRO IPC: "+t.getClass().getSimpleName()+" • "+t.getMessage();}
        finally{data.recycle();reply.recycle();}
    }

    /** Called by the accessibility service for global WASD updates. */
    public static String pushGlobalJoystick(float x,float y,boolean active) { return pushGlobalJoystick(x,y,active,.16f,.78f,.055f,.085f,0); }
    public static String pushGlobalJoystick(float x,float y,boolean active,float cx,float cy,float rx,float ry) { return pushGlobalJoystick(x,y,active,cx,cy,rx,ry,0); }
    public static String pushGlobalJoystick(float x,float y,boolean active,float cx,float cy,float rx,float ry,int transform) {
        return sendGlobalJoystick(x,y,active,cx,cy,rx,ry,transform);
    }
    public static String sendGlobalJoystick(float x,float y,boolean active,float cx,float cy,float rx,float ry,int transform) {
        IBinder binder=sharedRemote; if(binder==null || !binder.isBinderAlive()) return "MOTOR NÃO CONECTADO";
        Parcel data=Parcel.obtain(),reply=Parcel.obtain();
        try { data.writeInterfaceToken(MapperUserService.DESCRIPTOR); data.writeFloat(x);data.writeFloat(y);data.writeInt(active?1:0);data.writeFloat(cx);data.writeFloat(cy);data.writeFloat(rx);data.writeFloat(ry);data.writeInt(transform);boolean ok=binder.transact(MapperUserService.TRANSACTION_JOYSTICK,data,reply,0);if(!ok)return "JOYSTICK_TRANSACTION_UNHANDLED";reply.readException();return reply.readString(); }
        catch(Throwable t){return "ERRO IPC: "+t.getClass().getSimpleName();} finally{data.recycle();reply.recycle();}
    }

    private TextView status, output, liveInput;
    private IBinder remote;
    private final int requestCode = 4201;
    private boolean binding = false;
    private boolean vistaMode = false;
    private int vistaToggleKey = KeyEvent.KEYCODE_F1;
    private TextView modeStatus;
    private String capturingBindingId = null;
    private final String[] bindingIds = {"W", "A", "S", "D", "FIRE", "JUMP", "RELOAD", "VISTA"};
    private android.content.SharedPreferences profilePrefs;
    private AnalogPadView analogPad;
    private TextView analogValues;
    private final java.util.Set<Integer> heldMovementKeys = new java.util.HashSet<>();

    private final Shizuku.OnBinderReceivedListener binderReceived = this::refreshShizuku;
    private final Shizuku.OnBinderDeadListener binderDead = () -> runOnUiThread(() -> {
        remote = null; sharedRemote = null; binding = false;
        if (status != null) { status.setText("Shizuku desconectado. Aguardando Binder…"); status.setTextColor(Color.RED); }
    });

    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder binder) {
            remote = binder; sharedRemote = binder; binding = false;
            restoreTouchCalibration();
            runOnUiThread(() -> {
                status.setText("UserService conectado • UID " + safeUid());
                status.setTextColor(Color.rgb(100, 220, 140));
                log("Binder do motor conectado. Execute o diagnóstico para validar o UID shell/ADB.");
            });
        }
        @Override public void onServiceDisconnected(ComponentName name) {
            remote = null; sharedRemote = null; binding = false;
            runOnUiThread(() -> { status.setText("UserService desconectado"); status.setTextColor(Color.RED); });
        }
    };

    private final Shizuku.OnRequestPermissionResultListener permissionListener = (code, result) -> {
        if (code != requestCode) return;
        if (result == PackageManager.PERMISSION_GRANTED) {
            status.setText("Autorizado pelo Shizuku. Iniciando motor…");
            startUserService();
        } else status.setText("Autorização recusada no Shizuku.");
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        profilePrefs = getSharedPreferences("haze_profile", MODE_PRIVATE);
        vistaToggleKey = profilePrefs.getInt("vista_key", KeyEvent.KEYCODE_F1);
        buildUi();
        Shizuku.addBinderReceivedListenerSticky(binderReceived);
        Shizuku.addBinderDeadListener(binderDead);
        Shizuku.addRequestPermissionResultListener(permissionListener);
        refreshShizuku();
    }

    @Override protected void onResume() { super.onResume(); refreshShizuku(); }
    private int safeUid() { try { return Shizuku.getUid(); } catch (Throwable t) { return -1; } }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 28); root.setBackgroundColor(Color.rgb(16,16,24)); scroll.addView(root);
        TextView title = text("HAZE MAPPER PRO 0.3.3.1", 26, Color.WHITE); root.addView(title);
        root.addView(text("SHIZUKU BRIDGE • INPUT ENGINE TEST", 12, 0xFFB58AFF));
        modeStatus = text("MOUSE: MOVIMENTAR CÂMERA • VISTA: DESATIVADA (F1)", 14, 0xFF8B5CF6); root.addView(modeStatus);
        addButton(root, "ABRIR FREE FIRE", () -> launchGame("com.dts.freefireth", "Free Fire"));
        addButton(root, "ABRIR FREE FIRE MAX", () -> launchGame("com.dts.freefiremax", "Free Fire MAX"));
        addButton(root, "Editar HUD (posição, tamanho e opacidade)", this::openHudEditor);
        addButton(root, "Ativar HUD flutuante com cliques reais", () -> {
            boolean on=!getSharedPreferences("haze_hud",MODE_PRIVATE).getBoolean("overlay_enabled",false);
            getSharedPreferences("haze_hud",MODE_PRIVATE).edit().putBoolean("overlay_enabled",on).apply();
            GlobalKeyCaptureService.setHudOverlayEnabled(on);
            log(on?"HUD flutuante solicitado. Deixe a captura de acessibilidade ativa e o UserService conectado.":"HUD flutuante desativado.");
        });
        addButton(root, "0.3.3 • Calibrar coordenadas reais do touchscreen", () -> startActivity(new android.content.Intent(this, CoordinateCalibrationActivity.class)));
        addButton(root, "Coordinate Lab • diagnóstico visual antigo", () -> startActivity(new android.content.Intent(this, CoordinateLabActivity.class)));
        addButton(root, "Analog Lab • HUD editável e calibração", () -> startActivity(new android.content.Intent(this, AnalogLabActivity.class)));
        addButton(root, "Configurar teclas do HUD", this::openBindingsEditor);
        addButton(root, "Testar analógico e inputs", this::openInputLab);
        addButton(root, "Captura global de teclado (teste no FF)", this::openGlobalCapture);
        addButton(root, "Definir tecla do modo Vista", this::captureVistaKey);
        status = text("Aguardando Shizuku…", 15, Color.YELLOW); gap(root); root.addView(status);
        addButton(root, "1. Solicitar autorização do Shizuku", this::requestPermissionOrStart);
        addButton(root, "2. Iniciar UserService", this::startUserService);
        addButton(root, "3. Diagnóstico ADB + dispositivos", () -> callRemote(0));
        addButton(root, "4. Listar dispositivos de entrada", () -> callRemote(1));
        addButton(root, "5. Testar criação real de touchscreen virtual", () -> callRemote(4));
        addButton(root, "6. Criar dispositivo virtual (sessão de teste)", () -> callRemote(5));
        addButton(root, "7. Enviar toque de teste no centro", this::confirmVirtualTap);
        addButton(root, "8. Encerrar touchscreen virtual", () -> callRemote(7));
        addButton(root, "9. Testar toque ADB (legado)", () -> {
            int x = getResources().getDisplayMetrics().widthPixels / 2;
            int y = getResources().getDisplayMetrics().heightPixels / 2;
            callRemote(2, x, y);
        });
        addButton(root, "10. Testar swipe ADB (legado)", () -> {
            int x = getResources().getDisplayMetrics().widthPixels;
            int y = getResources().getDisplayMetrics().heightPixels / 2;
            callRemote(3, x/4, y, x*3/4, y, 350);
        });
        gap(root); root.addView(text("CAPTURA LOCAL (com esta tela aberta)", 16, Color.WHITE));
        liveInput = text("Mova o mouse ou pressione uma tecla…", 14, Color.LTGRAY); root.addView(liveInput);
        gap(root); root.addView(text("LOG", 16, Color.WHITE)); output = text("Aguardando teste.", 12, 0xFFD0D0D0); root.addView(output);
        setContentView(scroll);
    }


    private void launchGame(String packageName, String label) {
        try {
            android.content.Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
            if (launch == null) { log(label + " não está instalado ou não está visível para o Haze."); return; }
            launch.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
            log("Abrindo " + label + ". O overlay depende das permissões e serviços ativos.");
        } catch (Throwable error) { log("Não foi possível abrir " + label + ": " + error.getClass().getSimpleName()); }
    }

    private void openHudEditor() {
        startActivity(new android.content.Intent(this, HudEditorActivity.class));
    }

    private void openGlobalCapture() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL); page.setPadding(18,18,18,18); page.setBackgroundColor(0xFF101018);
        page.addView(text("CAPTURA GLOBAL • TECLADO", 21, Color.WHITE));
        page.addView(text("Esta etapa usa o serviço de acessibilidade do Android para observar teclas físicas mesmo com outro app em primeiro plano. As teclas NÃO serão bloqueadas nem alteradas; o objetivo é validar a captura no Free Fire com segurança.", 14, 0xFFCFD0D8));
        TextView state = text("Verificando serviço…", 15, 0xFFB58AFF); page.addView(state);
        page.addView(text("WASD global pode controlar um dedo virtual persistente no analógico. Ative somente com o touchscreen virtual iniciado e teste primeiro fora do jogo.", 13, 0xFFCFD0D8));
        TextView last = text("Nenhuma tecla recebida ainda.", 14, Color.WHITE); page.addView(last);
        TextView axes = text("Eixos globais: X 0.00 • Y 0.00\nTeclas pressionadas: —\nVista: câmera", 15, 0xFFB58AFF); page.addView(axes);
        Runnable refresh = () -> {
            android.content.SharedPreferences p = getSharedPreferences("haze_global_input", MODE_PRIVATE);
            boolean enabled = isGlobalKeyServiceEnabled();
            state.setText(enabled ? "Serviço habilitado nas configurações do Android" : "Serviço ainda não habilitado");
            state.setTextColor(enabled ? Color.rgb(100,220,140) : Color.YELLOW);
            int code = p.getInt("last_keycode", KeyEvent.KEYCODE_UNKNOWN);
            int action = p.getInt("last_action", -1);
            int count = p.getInt("event_count", 0);
            long at = p.getLong("last_event_at", 0);
            String age = at == 0 ? "nunca" : android.text.format.DateFormat.format("HH:mm:ss", at).toString();
            last.setText("Última tecla: " + (code == KeyEvent.KEYCODE_UNKNOWN ? "—" : KeyEvent.keyCodeToString(code))
                    + " • " + (action == KeyEvent.ACTION_DOWN ? "DOWN" : action == KeyEvent.ACTION_UP ? "UP" : "—")
                    + "\nEventos capturados: " + count + "\nÚltimo evento: " + age);
            float gx = p.getFloat("global_x", 0f), gy = p.getFloat("global_y", 0f);
            boolean vistaOn = p.getBoolean("vista_mode", false);
            String held = p.getString("held_keys", "");
            axes.setText(String.format(java.util.Locale.US, "Eixos globais: X %.2f • Y %.2f\nTeclas pressionadas: %s\nVista: %s\nMovimento: %s\nBackend: %s", gx, gy, (held == null || held.isEmpty()) ? "—" : held, vistaOn ? "cursor" : "câmera", (gx != 0f || gy != 0f) ? "ATIVO" : "parado", p.getString("last_backend_result", "—")));
        };
        addButton(page, "1. Iniciar sessão touchscreen virtual", () -> callRemote(5));
        addButton(page, "2. Ativar WASD → analógico virtual", () -> {
            getSharedPreferences("haze_global_input", MODE_PRIVATE).edit().putBoolean("joystick_enabled", true).apply();
            log("Mapeamento global ativado. WASD controlará um dedo virtual enquanto o modo câmera estiver ativo.");
        });
        addButton(page, "3. Desativar WASD → analógico virtual", () -> {
            getSharedPreferences("haze_global_input", MODE_PRIVATE).edit().putBoolean("joystick_enabled", false).apply();
            pushGlobalJoystick(0f, 0f, false);
            log("Mapeamento desativado; soltura enviada.");
        });
        addButton(page, "4. Encerrar sessão touchscreen virtual", () -> {
            getSharedPreferences("haze_global_input", MODE_PRIVATE).edit().putBoolean("joystick_enabled", false).apply();
            pushGlobalJoystick(0f, 0f, false);
            callRemote(7);
        });
        addButton(page, "Abrir configurações de acessibilidade", () -> startActivity(new android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        addButton(page, "Atualizar diagnóstico", refresh);
        addButton(page, "Zerar contador", () -> { getSharedPreferences("haze_global_input", MODE_PRIVATE).edit().putInt("event_count", 0).apply(); refresh.run(); });
        Button back = new Button(this); back.setText("Voltar"); back.setOnClickListener(v -> buildUi()); page.addView(back);
        setContentView(page); refresh.run();
    }

    private boolean isGlobalKeyServiceEnabled() {
        try {
            String enabled = android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            String target = new ComponentName(this, GlobalKeyCaptureService.class).flattenToString();
            return enabled != null && enabled.toLowerCase(java.util.Locale.ROOT).contains(target.toLowerCase(java.util.Locale.ROOT));
        } catch (Throwable ignored) { return false; }
    }

    private void captureVistaKey() {
        capturingVistaKey = true;
        capturingBindingId = "VISTA";
        log("Pressione a tecla que alternará o modo Vista (ESC cancela).");
    }

    private void openBindingsEditor() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL); page.setPadding(18,18,18,18); page.setBackgroundColor(0xFF101018);
        page.addView(text("TECLAS DO HUD", 22, Color.WHITE));
        page.addView(text("Toque em um controle e pressione a tecla ou botão físico que deseja associar. A captura acontece com esta tela em foco.", 13, 0xFFCFD0D8));
        for (String id : bindingIds) {
            int key = profilePrefs.getInt("key_" + id, defaultKey(id));
            Button b = new Button(this); b.setAllCaps(false);
            b.setText(id + "  •  " + KeyEvent.keyCodeToString(key));
            b.setOnClickListener(v -> { capturingBindingId = id; log("Aguardando tecla para " + id + "…"); });
            page.addView(b, new LinearLayout.LayoutParams(-1, -2));
        }
        Button back = new Button(this); back.setText("Voltar"); back.setOnClickListener(v -> buildUi()); page.addView(back);
        setContentView(page);
    }

    private int defaultKey(String id) {
        switch (id) {
            case "W": return KeyEvent.KEYCODE_W;
            case "A": return KeyEvent.KEYCODE_A;
            case "S": return KeyEvent.KEYCODE_S;
            case "D": return KeyEvent.KEYCODE_D;
            case "JUMP": return KeyEvent.KEYCODE_SPACE;
            case "RELOAD": return KeyEvent.KEYCODE_R;
            case "FIRE": return KeyEvent.KEYCODE_BUTTON_R1;
            case "VISTA": return KeyEvent.KEYCODE_F1;
            default: return KeyEvent.KEYCODE_UNKNOWN;
        }
    }

    private void openInputLab() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL); page.setPadding(16,16,16,16); page.setBackgroundColor(0xFF101018);
        page.addView(text("LABORATÓRIO DE INPUT", 21, Color.WHITE));
        page.addView(text("Teste o analógico virtual, zona morta e leitura de eixos. Esta etapa valida o controle dentro do HAZE; ainda não injeta movimento contínuo no Free Fire.", 13, 0xFFCFD0D8));
        TextView values = text("X: 0.00   Y: 0.00   |   Intensidade: 0%", 15, 0xFF8B5CF6); page.addView(values);
        analogValues = values;
        analogPad = new AnalogPadView(this, (x,y,magnitude) -> values.setText(String.format(java.util.Locale.US, "X: %.2f   Y: %.2f   |   Intensidade: %.0f%%", x, y, magnitude*100f)));
        analogPad.setFocusable(true);
        page.addView(analogPad, new LinearLayout.LayoutParams(-1, 0, 1));
        page.addView(text("Zona morta: 12% • Eixos normalizados • Soltar retorna ao centro", 12, 0xFFB7BECF));
        Button back = new Button(this); back.setText("Voltar"); back.setOnClickListener(v -> { analogPad = null; analogValues = null; heldMovementKeys.clear(); buildUi(); }); page.addView(back);
        setContentView(page);
        page.setFocusableInTouchMode(true); page.requestFocus();
    }
    private boolean capturingVistaKey = false;

    private TextView text(String value, int size, int color) {
        TextView v = new TextView(this); v.setText(value); v.setTextSize(size); v.setTextColor(color); v.setPadding(0,8,0,8); return v;
    }
    private void gap(LinearLayout root) { View gap = new View(this); root.addView(gap, new LinearLayout.LayoutParams(1,12)); }
    private void addButton(LinearLayout root, String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0,6,0,6); root.addView(b,p);
    }

    private void refreshShizuku() {
        if (status == null) return;
        try {
            if (!Shizuku.pingBinder()) {
                status.setText("Binder do Shizuku indisponível. Confirme se o serviço está iniciado e volte ao app.");
                status.setTextColor(Color.YELLOW); return;
            }
            if (Shizuku.isPreV11()) { status.setText("Shizuku API anterior à v11: UserService não é suportado."); return; }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                status.setText("Shizuku conectado e autorizado • UID " + safeUid());
                status.setTextColor(Color.rgb(100,220,140));
            } else {
                status.setText("Shizuku encontrado. Toque para solicitar autorização.");
                status.setTextColor(Color.YELLOW);
            }
        } catch (Throwable t) {
            status.setText("Falha ao consultar Shizuku: " + t.getClass().getSimpleName() + " — " + t.getMessage());
            status.setTextColor(Color.RED);
        }
    }

    private void requestPermissionOrStart() {
        try {
            if (!Shizuku.pingBinder()) { refreshShizuku(); return; }
            if (Shizuku.isPreV11()) { log("Atualize o Shizuku: UserService exige API v11 ou superior."); return; }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) { startUserService(); return; }
            Shizuku.requestPermission(requestCode);
        } catch (Throwable t) { log("Solicitação Shizuku falhou: " + t); }
    }

    private void startUserService() {
        try {
            if (!Shizuku.pingBinder()) { refreshShizuku(); return; }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) { requestPermissionOrStart(); return; }
            if (binding || (remote != null && remote.isBinderAlive())) { log("Motor já está conectado ou iniciando."); return; }
            Shizuku.UserServiceArgs args = new Shizuku.UserServiceArgs(
                    new ComponentName(getPackageName(), MapperUserService.class.getName()))
                    .daemon(false).tag("haze-mapper-input-engine").version(3).processNameSuffix("engine");
            binding = true;
            status.setText("Solicitando inicialização do UserService…");
            Shizuku.bindUserService(args, connection);
        } catch (Throwable t) { binding = false; log("Falha ao iniciar UserService: " + t.getClass().getSimpleName() + ": " + t.getMessage()); }
    }

    private void callRemote(int action, int... values) {
        IBinder binder = remote;
        if (binder == null || !binder.isBinderAlive()) { log("Motor não conectado. Autorize o Shizuku e inicie o UserService."); return; }
        new Thread(() -> {
            Parcel data = Parcel.obtain(), reply = Parcel.obtain();
            String result;
            try {
                data.writeInterfaceToken(MapperUserService.DESCRIPTOR);
                int code;
                if (action == 0) code = MapperUserService.TRANSACTION_DIAGNOSTIC;
                else if (action == 1) code = MapperUserService.TRANSACTION_LIST_DEVICES;
                else if (action == 2) { code = MapperUserService.TRANSACTION_TAP; data.writeInt(values[0]); data.writeInt(values[1]); }
                else if (action == 4) code = MapperUserService.TRANSACTION_PROBE_UINPUT;
                else if (action == 5) code = MapperUserService.TRANSACTION_TOUCH_START;
                else if (action == 7) code = MapperUserService.TRANSACTION_TOUCH_STOP;
                else if (action == 6) { code = MapperUserService.TRANSACTION_TOUCH_EVENT; for (int value : values) data.writeInt(value); }
                else { code = MapperUserService.TRANSACTION_SWIPE; for (int value : values) data.writeInt(value); }
                boolean handled = binder.transact(code, data, reply, 0);
                if (!handled) result = "O Binder não reconheceu a operação (" + code + ").";
                else { reply.readException(); result = reply.readString(); }
            } catch (Throwable t) { result = "ERRO IPC: " + t.getClass().getSimpleName() + ": " + t.getMessage(); }
            finally { data.recycle(); reply.recycle(); }
            final String out = result;
            runOnUiThread(() -> log(out));
        }).start();
    }

    private void confirmVirtualTap() {
        new android.app.AlertDialog.Builder(this)
                .setTitle("Teste de toque virtual")
                .setMessage("O teste enviará um toque curto no centro da tela. Feche o Free Fire e deixe uma tela sem ações importantes aberta antes de continuar.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Enviar toque", (d, w) -> {
                    callRemote(6, 0, 16384, 16384);
                    new android.os.Handler(getMainLooper()).postDelayed(() -> callRemote(6, 2, 16384, 16384), 120);
                }).show();
    }

    private void updateVistaLabel() {
        if (modeStatus != null) modeStatus.setText("MOUSE: " + (vistaMode ? "CURSOR / CLIQUE" : "MOVIMENTAR CÂMERA") + " • VISTA: " + (vistaMode ? "ATIVADA" : "DESATIVADA") + " (" + KeyEvent.keyCodeToString(vistaToggleKey) + ")");
    }
    private void log(String value) { if (output != null) output.setText(value); }
    @Override public boolean dispatchGenericMotionEvent(MotionEvent event) {
        if ((event.getSource() & InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE && liveInput != null)
            liveInput.setText((vistaMode ? "MOUSE • CURSOR/CLIQUE" : "MOUSE • CÂMERA") + " • x=" + event.getX() + " y=" + event.getY() + " • action=" + event.getAction());
        return super.dispatchGenericMotionEvent(event);
    }
    private void updateKeyboardAnalog() {
        if (analogPad == null) return;
        int keyW = profilePrefs.getInt("key_W", KeyEvent.KEYCODE_W);
        int keyA = profilePrefs.getInt("key_A", KeyEvent.KEYCODE_A);
        int keyS = profilePrefs.getInt("key_S", KeyEvent.KEYCODE_S);
        int keyD = profilePrefs.getInt("key_D", KeyEvent.KEYCODE_D);
        float x = (heldMovementKeys.contains(keyD) ? 1f : 0f) - (heldMovementKeys.contains(keyA) ? 1f : 0f);
        float y = (heldMovementKeys.contains(keyW) ? 1f : 0f) - (heldMovementKeys.contains(keyS) ? 1f : 0f);
        analogPad.setKeyboardAxes(x, y);
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (analogPad != null && (event.getAction() == KeyEvent.ACTION_DOWN || event.getAction() == KeyEvent.ACTION_UP)) {
            int code = event.getKeyCode();
            int w = profilePrefs.getInt("key_W", KeyEvent.KEYCODE_W);
            int a = profilePrefs.getInt("key_A", KeyEvent.KEYCODE_A);
            int s = profilePrefs.getInt("key_S", KeyEvent.KEYCODE_S);
            int d = profilePrefs.getInt("key_D", KeyEvent.KEYCODE_D);
            if (code == w || code == a || code == s || code == d) {
                if (event.getAction() == KeyEvent.ACTION_DOWN) heldMovementKeys.add(code);
                else heldMovementKeys.remove(code);
                updateKeyboardAnalog();
                return true;
            }
        }
        if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
            if (capturingBindingId != null) {
                String id = capturingBindingId;
                capturingBindingId = null;
                if (event.getKeyCode() != KeyEvent.KEYCODE_ESCAPE) {
                    profilePrefs.edit().putInt("key_" + id, event.getKeyCode()).apply();
                    if ("VISTA".equals(id)) { vistaToggleKey = event.getKeyCode(); profilePrefs.edit().putInt("vista_key", vistaToggleKey).apply(); updateVistaLabel(); }
                    log("Tecla de " + id + " definida: " + KeyEvent.keyCodeToString(event.getKeyCode()));
                } else log("Captura cancelada.");
                return true;
            }
            if (event.getKeyCode() == vistaToggleKey) { vistaMode = !vistaMode; updateVistaLabel(); log(vistaMode ? "Vista ativada: modo cursor (preview local)." : "Vista desativada: modo câmera (preview local)."); return true; }
        }
        if (liveInput != null) liveInput.setText("TECLADO • " + KeyEvent.keyCodeToString(event.getKeyCode()) + " • " + (event.getAction()==KeyEvent.ACTION_DOWN?"DOWN":"UP"));
        return super.dispatchKeyEvent(event);
    }

    @Override protected void onDestroy() {
        Shizuku.removeBinderReceivedListener(binderReceived);
        Shizuku.removeBinderDeadListener(binderDead);
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        try {
            Shizuku.UserServiceArgs args = new Shizuku.UserServiceArgs(
                    new ComponentName(getPackageName(), MapperUserService.class.getName()))
                    .daemon(false).tag("haze-mapper-input-engine").version(3).processNameSuffix("engine");
            Shizuku.unbindUserService(args, connection, true);
        } catch (Throwable ignored) {}
        analogPad = null; analogValues = null; heldMovementKeys.clear();
        super.onDestroy();
    }
}
