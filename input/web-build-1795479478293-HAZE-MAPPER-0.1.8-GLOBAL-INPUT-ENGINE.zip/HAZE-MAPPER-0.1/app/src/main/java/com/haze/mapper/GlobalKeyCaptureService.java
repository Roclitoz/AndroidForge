package com.haze.mapper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import java.util.HashSet;
import java.util.Set;

/** Global physical-key observer and normalized control-state calculator.
 * Events are deliberately not consumed: the foreground game keeps receiving them.
 */
public final class GlobalKeyCaptureService extends AccessibilityService {
    private static final String PREFS = "haze_global_input";
    private static final String PROFILE = "haze_profile";
    private final Set<Integer> held = new HashSet<>();

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = getServiceInfo();
        if (info != null) {
            info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
            setServiceInfo(info);
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("service_connected", true)
                .putLong("connected_at", System.currentTimeMillis())
                .putFloat("global_x", 0f).putFloat("global_y", 0f)
                .putString("held_keys", "").apply();
        held.clear();
    }

    @Override protected boolean onKeyEvent(KeyEvent event) {
        if (event == null || (event.getAction() != KeyEvent.ACTION_DOWN && event.getAction() != KeyEvent.ACTION_UP)) return false;
        final int code = event.getKeyCode();
        final boolean down = event.getAction() == KeyEvent.ACTION_DOWN;
        boolean newlyPressed = false;
        if (down) newlyPressed = held.add(code); else held.remove(code);

        android.content.SharedPreferences profile = getSharedPreferences(PROFILE, MODE_PRIVATE);
        int w = profile.getInt("key_W", KeyEvent.KEYCODE_W);
        int a = profile.getInt("key_A", KeyEvent.KEYCODE_A);
        int s = profile.getInt("key_S", KeyEvent.KEYCODE_S);
        int d = profile.getInt("key_D", KeyEvent.KEYCODE_D);
        int vista = profile.getInt("vista_key", KeyEvent.KEYCODE_F1);

        android.content.SharedPreferences state = getSharedPreferences(PREFS, MODE_PRIVATE);
        android.content.SharedPreferences.Editor edit = state.edit();
        if (down && newlyPressed && code == vista) {
            edit.putBoolean("vista_mode", !state.getBoolean("vista_mode", false));
        }

        float x = (held.contains(d) ? 1f : 0f) - (held.contains(a) ? 1f : 0f);
        float y = (held.contains(w) ? 1f : 0f) - (held.contains(s) ? 1f : 0f);
        float len = (float)Math.hypot(x, y);
        if (len > 1f) { x /= len; y /= len; }

        StringBuilder keys = new StringBuilder();
        for (Integer key : held) {
            if (keys.length() > 0) keys.append(',');
            keys.append(KeyEvent.keyCodeToString(key));
        }
        int count = state.getInt("event_count", 0) + 1;
        edit.putInt("last_keycode", code)
                .putInt("last_action", event.getAction())
                .putInt("last_device", event.getDeviceId())
                .putInt("event_count", count)
                .putLong("last_event_at", System.currentTimeMillis())
                .putFloat("global_x", x).putFloat("global_y", y)
                .putString("held_keys", keys.toString())
                .putBoolean("movement_active", x != 0f || y != 0f)
                .apply();
        // Observation/calculation only. Do not swallow the physical event.
        return false;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { clearHeldState(); }

    private void clearHeldState() {
        held.clear();
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putFloat("global_x", 0f).putFloat("global_y", 0f)
                .putBoolean("movement_active", false).putString("held_keys", "").apply();
    }

    @Override public boolean onUnbind(android.content.Intent intent) {
        clearHeldState();
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("service_connected", false).apply();
        return super.onUnbind(intent);
    }
}
