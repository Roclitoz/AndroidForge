# HAZE MAPPER 0.1.8 — Global Input Engine Lab

## Base validada
- Mantém a implementação do analógico WASD local da versão 0.1.6.
- Mantém a captura global de teclado por AccessibilityService validada pelo usuário na versão 0.1.7.

## Novidades 0.1.8
- O serviço global mantém o conjunto de teclas pressionadas (DOWN/UP).
- Calcula eixos normalizados X/Y a partir das teclas WASD configuradas no perfil.
- Normaliza diagonais para magnitude máxima 1.0.
- Alterna o estado lógico de Vista pela tecla VISTA configurada no perfil.
- Diagnóstico mostra eixos, teclas pressionadas, estado Vista e movimento ativo.
- Continua retornando `false` em `onKeyEvent`: não consome nem bloqueia os eventos físicos originais.
- Limpa estado de teclas ao interromper/desvincular o serviço.

## Limitações explícitas
Esta versão calcula e exibe estado global, mas ainda NÃO injeta toque no jogo, NÃO cria touchscreen virtual e NÃO transforma o mouse em movimento de câmera/cursor. A Vista ainda é apenas um estado lógico/diagnóstico. O analógico local continua funcionando dentro do HAZE.

## Teste recomendado
1. Instale a versão compilada pelo AndroidForge.
2. Confirme que o serviço de acessibilidade continua habilitado.
3. Abra o Free Fire e segure W; depois teste W+D e solte.
4. Volte ao HAZE > Captura global de teclado > Atualizar diagnóstico.
5. Confira X/Y, teclas pressionadas e estado Vista.
6. Repita com a tecla Vista configurada. O jogo deve continuar recebendo os eventos originais.

## Build
Projeto Android Gradle, compileSdk 35, minSdk 26, Java 17, Shizuku API/Provider 13.1.5. Compile no AndroidForge. Este pacote é código-fonte; não é APK compilado.
