#include <jni.h>
#include <linux/input.h>
#include <linux/uinput.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <time.h>

static int g_fd = -1;
static int g_tracking = 1;
static int g_joystick_down = 0;
static int g_joystick_tracking = 1000;
static const int MAX_X = 32767;
static const int MAX_Y = 32767;

static jstring js(JNIEnv *env, const char *s) { return (*env)->NewStringUTF(env, s); }
static int emit(int fd, unsigned short type, unsigned short code, int value) {
    struct input_event ev; memset(&ev, 0, sizeof(ev));
    ev.type = type; ev.code = code; ev.value = value;
    return write(fd, &ev, sizeof(ev)) == sizeof(ev) ? 0 : -1;
}
static int setup_device(int fd) {
    if (ioctl(fd, UI_SET_EVBIT, EV_SYN) < 0) return -1;
    if (ioctl(fd, UI_SET_EVBIT, EV_KEY) < 0) return -1;
    if (ioctl(fd, UI_SET_KEYBIT, BTN_TOUCH) < 0) return -1;
    if (ioctl(fd, UI_SET_EVBIT, EV_ABS) < 0) return -1;
    if (ioctl(fd, UI_SET_PROPBIT, INPUT_PROP_DIRECT) < 0) return -1;
    const int abs_codes[] = {ABS_MT_SLOT, ABS_MT_TRACKING_ID, ABS_MT_POSITION_X, ABS_MT_POSITION_Y, ABS_MT_PRESSURE};
    const int mins[] = {0, 0, 0, 0, 0};
    const int maxs[] = {9, 65535, MAX_X, MAX_Y, 255};
    for (int i=0; i<5; i++) {
        if (ioctl(fd, UI_SET_ABSBIT, abs_codes[i]) < 0) return -1;
        struct uinput_abs_setup a; memset(&a, 0, sizeof(a));
        a.code = abs_codes[i]; a.absinfo.minimum = mins[i]; a.absinfo.maximum = maxs[i];
        if (ioctl(fd, UI_ABS_SETUP, &a) < 0) return -1;
    }
    struct uinput_setup setup; memset(&setup, 0, sizeof(setup));
    snprintf(setup.name, UINPUT_MAX_NAME_SIZE, "HAZE Virtual Touchscreen");
    setup.id.bustype = BUS_VIRTUAL; setup.id.vendor = 0x4841; setup.id.product = 0x5E01; setup.id.version = 1;
    if (ioctl(fd, UI_DEV_SETUP, &setup) < 0) return -1;
    if (ioctl(fd, UI_DEV_CREATE) < 0) return -1;
    struct timespec ts = {0, 150000000}; nanosleep(&ts, NULL);
    return 0;
}
static void close_fd(int fd) { if (fd >= 0) { ioctl(fd, UI_DEV_DESTROY); close(fd); } }

JNIEXPORT jstring JNICALL Java_com_haze_mapper_MapperUserService_nativeProbeTouch(JNIEnv *env, jclass cls) {
    int fd = open("/dev/uinput", O_WRONLY | O_NONBLOCK | O_CLOEXEC);
    if (fd < 0) { char b[256]; snprintf(b, sizeof(b), "UINPUT_OPEN_FAILED errno=%d (%s). Shizuku/ADB não tem acesso de escrita ao /dev/uinput neste firmware.", errno, strerror(errno)); return js(env,b); }
    if (setup_device(fd) < 0) { int e=errno; close_fd(fd); char b[256]; snprintf(b,sizeof(b),"UINPUT_CREATE_FAILED errno=%d (%s). O nó abriu, mas o kernel recusou a configuração do touchscreen.",e,strerror(e)); return js(env,b); }
    close_fd(fd);
    return js(env,"UINPUT_CREATE_OK: touchscreen virtual criado e destruído com sucesso. Nenhum toque foi enviado.");
}
JNIEXPORT jstring JNICALL Java_com_haze_mapper_MapperUserService_nativeStartTouch(JNIEnv *env, jclass cls) {
    if (g_fd >= 0) return js(env,"TOUCH_DEVICE_ALREADY_ACTIVE");
    int fd = open("/dev/uinput", O_WRONLY | O_NONBLOCK | O_CLOEXEC);
    if (fd < 0) { char b[192]; snprintf(b,sizeof(b),"UINPUT_OPEN_FAILED errno=%d (%s)",errno,strerror(errno)); return js(env,b); }
    if (setup_device(fd) < 0) { int e=errno; close(fd); char b[192]; snprintf(b,sizeof(b),"UINPUT_CREATE_FAILED errno=%d (%s)",e,strerror(e)); return js(env,b); }
    g_fd=fd; g_tracking=1; return js(env,"TOUCH_DEVICE_ACTIVE: dispositivo virtual criado. Ainda não há toque pressionado.");
}
JNIEXPORT jstring JNICALL Java_com_haze_mapper_MapperUserService_nativeTouchEvent(JNIEnv *env, jclass cls, jint action, jint x, jint y) {
    if (g_fd < 0) return js(env,"TOUCH_DEVICE_NOT_ACTIVE");
    if (x<0) x=0; if (x>MAX_X) x=MAX_X; if (y<0) y=0; if (y>MAX_Y) y=MAX_Y;
    int ok=0;
    if (action==0) { // DOWN
        ok |= emit(g_fd,EV_ABS,ABS_MT_SLOT,0); ok |= emit(g_fd,EV_ABS,ABS_MT_TRACKING_ID,g_tracking++);
        ok |= emit(g_fd,EV_ABS,ABS_MT_POSITION_X,x); ok |= emit(g_fd,EV_ABS,ABS_MT_POSITION_Y,y);
        ok |= emit(g_fd,EV_ABS,ABS_MT_PRESSURE,180); ok |= emit(g_fd,EV_KEY,BTN_TOUCH,1);
    } else if (action==1) { // MOVE
        ok |= emit(g_fd,EV_ABS,ABS_MT_SLOT,0); ok |= emit(g_fd,EV_ABS,ABS_MT_POSITION_X,x); ok |= emit(g_fd,EV_ABS,ABS_MT_POSITION_Y,y);
    } else if (action==2) { // UP
        ok |= emit(g_fd,EV_ABS,ABS_MT_SLOT,0); ok |= emit(g_fd,EV_ABS,ABS_MT_TRACKING_ID,-1);
        ok |= emit(g_fd,EV_ABS,ABS_MT_PRESSURE,0); ok |= emit(g_fd,EV_KEY,BTN_TOUCH,0);
    } else return js(env,"INVALID_TOUCH_ACTION (0=DOWN, 1=MOVE, 2=UP)");
    ok |= emit(g_fd,EV_SYN,SYN_REPORT,0);
    return ok==0 ? js(env,"TOUCH_EVENT_OK") : js(env,"TOUCH_EVENT_WRITE_FAILED");
}
JNIEXPORT jstring JNICALL Java_com_haze_mapper_MapperUserService_nativeStopTouch(JNIEnv *env, jclass cls) {
    if (g_fd < 0) return js(env,"TOUCH_DEVICE_NOT_ACTIVE");
    emit(g_fd,EV_ABS,ABS_MT_SLOT,0); emit(g_fd,EV_ABS,ABS_MT_TRACKING_ID,-1);
    if (g_joystick_down) { emit(g_fd,EV_ABS,ABS_MT_SLOT,1); emit(g_fd,EV_ABS,ABS_MT_TRACKING_ID,-1); g_joystick_down=0; }
    emit(g_fd,EV_KEY,BTN_TOUCH,0); emit(g_fd,EV_SYN,SYN_REPORT,0);
    close_fd(g_fd); g_fd=-1; return js(env,"TOUCH_DEVICE_DESTROYED");
}


JNIEXPORT jstring JNICALL Java_com_haze_mapper_MapperUserService_nativeJoystickEvent(JNIEnv *env,jclass cls,jfloat x,jfloat y,jboolean active,jfloat cx,jfloat cy,jfloat rx,jfloat ry) {
    if (g_fd < 0) return js(env, "TOUCH_DEVICE_NOT_ACTIVE");
    if (!active) {
        if (g_joystick_down) {
            emit(g_fd, EV_ABS, ABS_MT_SLOT, 1);
            emit(g_fd, EV_ABS, ABS_MT_TRACKING_ID, -1);
            emit(g_fd, EV_ABS, ABS_MT_PRESSURE, 0);
            emit(g_fd, EV_KEY, BTN_TOUCH, 0);
            emit(g_fd, EV_SYN, SYN_REPORT, 0);
            g_joystick_down = 0;
        }
        return js(env, "JOYSTICK_RELEASED");
    }
    if (x < -1.f) x = -1.f; if (x > 1.f) x = 1.f;
    if (y < -1.f) y = -1.f; if (y > 1.f) y = 1.f;
    // Calibrated screen anchor and independent X/Y travel radius (normalized 0..1).
    if(cx<0.f)cx=0.f;if(cx>1.f)cx=1.f;if(cy<0.f)cy=0.f;if(cy>1.f)cy=1.f;
    if(rx<0.005f)rx=0.005f;if(rx>0.25f)rx=0.25f;if(ry<0.005f)ry=0.005f;if(ry>0.25f)ry=0.25f;
    int px=(int)(cx*MAX_X+x*rx*MAX_X);
    int py=(int)(cy*MAX_Y-y*ry*MAX_Y);
    if (px < 0) px = 0; if (px > MAX_X) px = MAX_X;
    if (py < 0) py = 0; if (py > MAX_Y) py = MAX_Y;
    int ok = 0;
    ok |= emit(g_fd, EV_ABS, ABS_MT_SLOT, 1);
    if (!g_joystick_down) {
        // Establish the finger at the joystick anchor first, then move it.
        int anchor_x=(int)(cx*MAX_X);
        int anchor_y=(int)(cy*MAX_Y);
        ok |= emit(g_fd, EV_ABS, ABS_MT_TRACKING_ID, g_joystick_tracking++);
        ok |= emit(g_fd, EV_ABS, ABS_MT_POSITION_X, anchor_x);
        ok |= emit(g_fd, EV_ABS, ABS_MT_POSITION_Y, anchor_y);
        ok |= emit(g_fd, EV_ABS, ABS_MT_PRESSURE, 180);
        ok |= emit(g_fd, EV_KEY, BTN_TOUCH, 1);
        ok |= emit(g_fd, EV_SYN, SYN_REPORT, 0);
        g_joystick_down = 1;
    }
    ok |= emit(g_fd, EV_ABS, ABS_MT_SLOT, 1);
    ok |= emit(g_fd, EV_ABS, ABS_MT_POSITION_X, px);
    ok |= emit(g_fd, EV_ABS, ABS_MT_POSITION_Y, py);
    ok |= emit(g_fd, EV_ABS, ABS_MT_PRESSURE, 180);
    ok |= emit(g_fd, EV_SYN, SYN_REPORT, 0);
    return ok == 0 ? js(env, "JOYSTICK_EVENT_OK") : js(env, "JOYSTICK_WRITE_FAILED");
}
