# HAZE MAPPER 0.1.10 — GLOBAL WASD → VIRTUAL JOYSTICK

## O que esta versão acrescenta
- Preserva a captura global de teclado por AccessibilityService.
- Encaminha os eixos WASD normalizados para o Shizuku UserService.
- Adiciona um dedo virtual persistente no slot multitouch 1.
- DOWN cria o contato; MOVE atualiza a posição do mesmo contato; UP encerra.
- A tecla Vista suspende o dedo de movimento enquanto o modo cursor está ativo.
- Botões no painel de Captura Global iniciam/encerram a sessão e ativam/desativam o mapeamento.

## Teste recomendado (primeiro fora do Free Fire)
1. Instale e abra o HAZE.
2. Conecte e autorize o Shizuku; inicie o UserService.
3. Ative o serviço de acessibilidade do HAZE.
4. Abra Captura global de teclado.
5. Toque em "1. Iniciar sessão touchscreen virtual" e aguarde TOUCH_DEVICE_ACTIVE.
6. Toque em "2. Ativar WASD → analógico virtual".
7. Em uma tela segura, pressione W/A/S/D no teclado físico. O contato virtual fica na zona inferior esquerda e se desloca conforme os eixos.
8. Solte as teclas: o contato deve ser liberado.
9. Desative o mapeamento e encerre a sessão antes de fechar o HAZE.

## Importante
- Esta versão é um teste inicial de movimento virtual, não um mapeador completo.
- A posição do analógico é uma calibração fixa provisória (18% da largura, 78% da altura).
- A captura global depende do serviço de acessibilidade habilitado.
- O encaminhamento ao UserService depende de o processo principal do HAZE permanecer ativo e conectado ao Shizuku.
- O modo Vista apenas suspende o dedo virtual de movimento; ainda não implementa cursor, clique nem controle da câmera.
- Ainda não há editor de posição do analógico integrado, multitouch completo para mira/disparo, nem captura global de mouse.
- O teste deve ser feito primeiro numa tela segura, nunca sobre botões de compra/confirmação.
- Para encerrar em qualquer situação, desative o mapeamento e use "Encerrar sessão touchscreen virtual". O encerramento nativo também libera o dedo virtual.

## Build
Requer Android Gradle Plugin, Gradle, Android SDK, NDK e CMake. ABI configurada: arm64-v8a. O APK não foi compilado neste ambiente; validar o build no AndroidForge.


## 0.1.11 — HUD & joystick calibration
- Calibração configurável do centro e do alcance X/Y do analógico virtual.
- Posição inicial baseada no HUD Free Fire enviado: centro aproximado X=17,5%, Y=10,5%.
- Mantém o toque persistente do joystick virtual e a suspensão do movimento no modo Vista.
- Editor HUD: arrastar controles, ajustar escala global e opacidade.
- Vista continua configurável por tecla; o estado global permanece sob controle do Accessibility Service.

Observação: esta versão é código-fonte para build no AndroidForge; a calibração precisa ser testada no aparelho e pode exigir ajuste fino conforme escala/resolução/HUD do jogo.
