# Haze Mapper Pro 0.3.2

Release de desenvolvimento: Analog Lab + HUD editável. Leia `docs/ANALOG_LAB_0.3.2.md` antes do teste.

**Fonte, não APK.** O projeto foi validado com testes puros Java e verificação sintática C; não houve build Android nem teste no Galaxy A17 neste ambiente.

Preserva Shizuku, captura global de teclado e o Coordinate Lab 0.3.1. Substitui a transformação de touchscreen presumida por oito candidatos selecionáveis. O modo correto deve ser calibrado no aparelho.
