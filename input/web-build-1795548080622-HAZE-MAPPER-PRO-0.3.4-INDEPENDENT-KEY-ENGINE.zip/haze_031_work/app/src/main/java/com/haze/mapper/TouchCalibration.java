package com.haze.mapper;

import java.util.List;

/** Affine calibration between normalized display coordinates and raw uinput axes. */
public final class TouchCalibration {
    private TouchCalibration() {}
    public static final class Sample {
        public final double rawX, rawY, screenX, screenY;
        public Sample(double rawX,double rawY,double screenX,double screenY) {
            this.rawX=rawX; this.rawY=rawY; this.screenX=screenX; this.screenY=screenY;
        }
    }
    public static final class Result {
        // screen -> raw: rawX=m[0]*screenX+m[1]*screenY+m[2]; rawY=m[3]*screenX+m[4]*screenY+m[5]
        public final float[] matrix;
        public final double rmsError, maxError, determinant;
        Result(float[] m,double rms,double max,double det){matrix=m;rmsError=rms;maxError=max;determinant=det;}
        public float[] map(float sx,float sy){return new float[]{clamp(matrix[0]*sx+matrix[1]*sy+matrix[2]),clamp(matrix[3]*sx+matrix[4]*sy+matrix[5])};}
    }
    public static Result solve(List<Sample> samples) {
        if(samples==null || samples.size()<3) throw new IllegalArgumentException("At least 3 samples are required");
        double[][] n=new double[3][3]; double[] bx=new double[3],by=new double[3];
        for(Sample s:samples){double[] v={s.rawX,s.rawY,1};for(int i=0;i<3;i++){bx[i]+=v[i]*s.screenX;by[i]+=v[i]*s.screenY;for(int j=0;j<3;j++)n[i][j]+=v[i]*v[j];}}
        double[] ax=solve3(n,bx), ay=solve3(n,by);
        double det=ax[0]*ay[1]-ax[1]*ay[0];
        if(!Double.isFinite(det)||Math.abs(det)<1e-8)throw new IllegalArgumentException("Degenerate calibration geometry");
        // Invert observedScreen = A * raw + b.
        double i00=ay[1]/det, i01=-ax[1]/det, i10=-ay[0]/det, i11=ax[0]/det;
        double i02=-(i00*ax[2]+i01*ay[2]), i12=-(i10*ax[2]+i11*ay[2]);
        float[] m={(float)i00,(float)i01,(float)i02,(float)i10,(float)i11,(float)i12};
        double sum=0,max=0;
        for(Sample s:samples){double px=ax[0]*s.rawX+ax[1]*s.rawY+ax[2],py=ay[0]*s.rawX+ay[1]*s.rawY+ay[2];double e=Math.hypot(px-s.screenX,py-s.screenY);sum+=e*e;max=Math.max(max,e);}
        if(!finite(m))throw new IllegalArgumentException("Non-finite calibration matrix");
        return new Result(m,Math.sqrt(sum/samples.size()),max,det);
    }
    private static double[] solve3(double[][] src,double[] rhs){double[][] a=new double[3][4];for(int i=0;i<3;i++){System.arraycopy(src[i],0,a[i],0,3);a[i][3]=rhs[i];}for(int c=0;c<3;c++){int p=c;for(int r=c+1;r<3;r++)if(Math.abs(a[r][c])>Math.abs(a[p][c]))p=r;if(Math.abs(a[p][c])<1e-10)throw new IllegalArgumentException("Calibration points are collinear");double[] t=a[c];a[c]=a[p];a[p]=t;double d=a[c][c];for(int j=c;j<4;j++)a[c][j]/=d;for(int r=0;r<3;r++)if(r!=c){double f=a[r][c];for(int j=c;j<4;j++)a[r][j]-=f*a[c][j];}}return new double[]{a[0][3],a[1][3],a[2][3]};}
    private static boolean finite(float[] a){for(float v:a)if(!Float.isFinite(v))return false;return true;}
    private static float clamp(double v){return (float)Math.max(0,Math.min(1,v));}
}
