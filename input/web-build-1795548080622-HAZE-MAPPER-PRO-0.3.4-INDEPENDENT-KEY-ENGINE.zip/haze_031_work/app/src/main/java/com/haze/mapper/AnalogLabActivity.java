package com.haze.mapper;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.content.SharedPreferences;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Landscape editor and diagnostic lab for one persistent virtual thumb contact. */
public final class AnalogLabActivity extends Activity {
    private SharedPreferences stickPrefs, hudPrefs, globalPrefs;
    private EditorSurface surface;
    private TextView status, readout;
    private Spinner transformSpinner;
    private SeekBar radiusBar, opacityBar, sizeBar;
    private boolean testMode = false;
    private final Set<Integer> held = new HashSet<>();

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        stickPrefs=getSharedPreferences("haze_joystick",MODE_PRIVATE);
        hudPrefs=getSharedPreferences("haze_hud",MODE_PRIVATE);
        globalPrefs=getSharedPreferences("haze_global_input",MODE_PRIVATE);
        build();
    }

    private void build() {
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(12,8,12,8);root.setBackgroundColor(0xFF0D111B);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setOrientation(LinearLayout.HORIZONTAL);
        TextView title=new TextView(this);title.setText("HAZE MAPPER PRO  /  ANALOG LAB 0.3.2");title.setTextColor(Color.WHITE);title.setTextSize(16);title.setTypeface(null,1);header.addView(title,new LinearLayout.LayoutParams(0,44,1));
        Button edit=new Button(this);edit.setText("EDITAR HUD");edit.setAllCaps(false);edit.setOnClickListener(v->{testMode=false;surface.invalidate();updateStatus("Modo edição: arraste o analógico e os botões para posicionar.");});header.addView(edit);
        Button test=new Button(this);test.setText("PREVIEW WASD");test.setAllCaps(false);test.setOnClickListener(v->toggleTest());header.addView(test);
        root.addView(header);

        surface=new EditorSurface();root.addView(surface,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.HORIZONTAL);controls.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout left=new LinearLayout(this);left.setOrientation(LinearLayout.VERTICAL);
        TextView radiusLabel=smallLabel("RAIO DO ANALÓGICO");left.addView(radiusLabel);
        radiusBar=new SeekBar(this);radiusBar.setMax(180);radiusBar.setProgress(Math.round(stickPrefs.getFloat("ry",.085f)*1000));radiusBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int v,boolean u){float r=Math.max(25,v)/1000f;float aspect=getResources().getDisplayMetrics().heightPixels/(float)Math.max(1,getResources().getDisplayMetrics().widthPixels);stickPrefs.edit().putFloat("rx",r*aspect).putFloat("ry",r).apply();surface.invalidate();}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});left.addView(radiusBar,new LinearLayout.LayoutParams(250,36));
        TextView sizeLabel=smallLabel("TAMANHO DOS BOTÕES HUD");left.addView(sizeLabel);
        sizeBar=new SeekBar(this);sizeBar.setMax(150);sizeBar.setProgress(Math.round(hudPrefs.getFloat("global_scale",1f)*100));sizeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int v,boolean u){float scale=Math.max(50,v)/100f;hudPrefs.edit().putFloat("global_scale",scale).apply();surface.invalidate();}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});left.addView(sizeBar,new LinearLayout.LayoutParams(250,36));
        TextView opacityLabel=smallLabel("OPACIDADE HUD");left.addView(opacityLabel);
        opacityBar=new SeekBar(this);opacityBar.setMax(100);opacityBar.setProgress(Math.round(hudPrefs.getFloat("global_opacity",.85f)*100));opacityBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int v,boolean u){hudPrefs.edit().putFloat("global_opacity",v/100f).apply();surface.invalidate();}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});left.addView(opacityBar,new LinearLayout.LayoutParams(250,36));
        controls.addView(left,new LinearLayout.LayoutParams(270,-2));

        LinearLayout right=new LinearLayout(this);right.setOrientation(LinearLayout.VERTICAL);right.setPadding(12,0,0,0);
        right.addView(smallLabel("ORIENTAÇÃO DOS EIXOS TOUCH"));
        transformSpinner=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,TouchTransform.LABELS);transformSpinner.setAdapter(adapter);transformSpinner.setSelection(stickPrefs.getInt("transform",0));transformSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){stickPrefs.edit().putInt("transform",pos).apply();updateStatus("Transformação selecionada: "+TouchTransform.LABELS[pos]);}public void onNothingSelected(android.widget.AdapterView<?> p){}});right.addView(transformSpinner,new LinearLayout.LayoutParams(290,42));
        readout=smallLabel("WASD: neutro  •  contato: UP");right.addView(readout);
        controls.addView(right,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(controls);

        LinearLayout footer=new LinearLayout(this);footer.setGravity(Gravity.CENTER_VERTICAL);footer.setOrientation(LinearLayout.HORIZONTAL);
        Button save=new Button(this);save.setText("SALVAR LAYOUT");save.setAllCaps(false);save.setOnClickListener(v->{surface.persist();updateStatus("Layout e calibração salvos neste aparelho.");});footer.addView(save);
        Button global=new Button(this);global.setText("ATIVAR WASD NO FREE FIRE");global.setAllCaps(false);global.setOnClickListener(v->{surface.persist();if(testMode){MainActivity.pushGlobalJoystick(0,0,false);testMode=false;}String session=MainActivity.sendSimpleCommand(MapperUserService.TRANSACTION_TOUCH_START);globalPrefs.edit().putBoolean("joystick_enabled",true).putBoolean("vista_mode",false).apply();updateStatus("WASD GLOBAL ATIVADO • "+session+" • volte ao menu e abra o Free Fire.");surface.invalidate();});footer.addView(global);
        Button back=new Button(this);back.setText("VOLTAR");back.setAllCaps(false);back.setOnClickListener(v->{stopLocalTest();finish();});footer.addView(back);
        root.addView(footer);
        status=smallLabel("EDIÇÃO • arraste os controles no preview landscape");root.addView(status);
        setContentView(root);root.setFocusableInTouchMode(true);root.requestFocus();
    }

    private TextView smallLabel(String value){TextView t=new TextView(this);t.setText(value);t.setTextColor(0xFFB8C4D8);t.setTextSize(11);t.setPadding(4,2,4,2);return t;}
    private void updateStatus(String s){if(status!=null)status.setText(s);}

    private void toggleTest(){
        testMode=!testMode;
        held.clear();
        updateStatus(testMode?"PREVIEW WASD: simulação visual • nenhum toque é injetado nesta tela.":"Modo edição: arraste os controles.");
        if(readout!=null)readout.setText("WASD: neutro • preview sem injeção");
        surface.invalidate();
    }
    private void stopLocalTest(){
        held.clear();testMode=false;
        if(readout!=null)readout.setText("WASD: neutro • preview encerrado");
    }
    private void sendAxes(float x,float y,boolean active){
        if(!testMode)return;
        if(readout!=null)readout.setText(String.format(Locale.US,"PREVIEW  X %.2f  Y %.2f  •  %s",x,y,active?"DIRECTION DOWN":"NEUTRO"));
    }
    private void updateHeld(){
        int w=KeyEvent.KEYCODE_W,a=KeyEvent.KEYCODE_A,s=KeyEvent.KEYCODE_S,d=KeyEvent.KEYCODE_D;
        float x=(held.contains(d)?1:0)-(held.contains(a)?1:0),y=(held.contains(w)?1:0)-(held.contains(s)?1:0);
        float m=(float)Math.hypot(x,y);if(m>1){x/=m;y/=m;}
        sendAxes(x,y,m>0);
    }
    @Override public boolean dispatchKeyEvent(KeyEvent e){
        int code=e.getKeyCode();if(code==KeyEvent.KEYCODE_W||code==KeyEvent.KEYCODE_A||code==KeyEvent.KEYCODE_S||code==KeyEvent.KEYCODE_D){
            if(e.getAction()==KeyEvent.ACTION_DOWN)held.add(code);else if(e.getAction()==KeyEvent.ACTION_UP)held.remove(code);updateHeld();return true;
        }
        return super.dispatchKeyEvent(e);
    }
    @Override protected void onPause(){if(testMode)stopLocalTest();super.onPause();}

    private final class EditorSurface extends View {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final String[] ids={"FIRE","JUMP","RELOAD","VISTA"};
        private final float[][] defaults={{.86f,.76f},{.75f,.62f},{.88f,.48f},{.50f,.90f}};
        private RectF game=new RectF();private int selected=-1;private float downX,downY,startX,startY;private boolean stickSelected=false;private float pointerX,pointerY;private boolean pointerActive=false;
        EditorSurface(){super(AnalogLabActivity.this);setFocusable(true);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        private void calcGame(){game.set(0,0,getWidth(),getHeight());}
        private float nx(float n){return game.left+n*game.width();}private float ny(float n){return game.top+n*game.height();}
        @Override protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(0xFF090D15);calcGame();
            p.setStyle(Paint.Style.FILL);p.setColor(0xFF151E2E);c.drawRoundRect(game,14,14,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(0xFF35445E);c.drawRoundRect(game,14,14,p);
            p.setStrokeWidth(1);p.setColor(0x222D3D59);for(int i=1;i<10;i++){float x=game.left+game.width()*i/10f,y=game.top+game.height()*i/10f;c.drawLine(x,game.top,x,game.bottom,p);c.drawLine(game.left,y,game.right,y,p);}
            p.setStyle(Paint.Style.FILL);p.setTextSize(12);p.setColor(0xFF9AAAC2);c.drawText(testMode?"TEST MODE • WASD / DRAG":"EDIT MODE • DRAG CONTROLS",game.left+14,game.top+22,p);
            float cx=nx(stickPrefs.getFloat("cx",.16f)),cy=ny(stickPrefs.getFloat("cy",.78f));float radiusX=game.width()*stickPrefs.getFloat("rx",.055f),radiusY=game.height()*stickPrefs.getFloat("ry",.085f);
            int alpha=Math.round(hudPrefs.getFloat("global_opacity",.85f)*255);
            p.setStyle(Paint.Style.FILL);p.setColor((alpha<<24)|0x00242F45);c.drawOval(cx-radiusX,cy-radiusY,cx+radiusX,cy+radiusY,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(0xFF9C7BFF);c.drawOval(cx-radiusX,cy-radiusY,cx+radiusX,cy+radiusY,p);p.setColor(0x665F6F8A);c.drawCircle(cx,cy,Math.min(radiusX,radiusY)*.12f,p);
            p.setStyle(Paint.Style.FILL);p.setColor(0xFFE5DFFF);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(12);c.drawText("WASD",cx,cy+4,p);
            if(testMode&&pointerActive){p.setColor(0xFFFFC857);c.drawCircle(pointerX,pointerY,8,p);}
            float buttonRadius=Math.min(game.width(),game.height())*.045f*hudPrefs.getFloat("global_scale",1f);
            for(int i=0;i<ids.length;i++){float x=nx(hudPrefs.getFloat(ids[i]+"_x",defaults[i][0])),y=ny(hudPrefs.getFloat(ids[i]+"_y",defaults[i][1]));p.setStyle(Paint.Style.FILL);p.setColor((alpha<<24)|0x002C3850);c.drawCircle(x,y,buttonRadius,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(i==selected?0xFFFFC857:0xFFB69AFF);c.drawCircle(x,y,buttonRadius,p);p.setStyle(Paint.Style.FILL);p.setTextSize(Math.max(10,buttonRadius*.36f));p.setColor(Color.WHITE);c.drawText(ids[i],x,y+4,p);}
            p.setTextAlign(Paint.Align.LEFT);p.setTextSize(10);p.setColor(0xFF71829F);c.drawText("PREVIEW 16:9 • posições normalizadas",game.left+14,game.bottom-12,p);
        }
        private float clamp(float v){return Math.max(.04f,Math.min(.96f,v));}
        @Override public boolean onTouchEvent(MotionEvent e){calcGame();float x=e.getX(),y=e.getY();float cx=nx(stickPrefs.getFloat("cx",.16f)),cy=ny(stickPrefs.getFloat("cy",.78f));float hit=Math.min(game.width(),game.height())*.09f;
            if(e.getAction()==MotionEvent.ACTION_DOWN){requestFocus();if(!game.contains(x,y))return true;
                if(testMode){float r=Math.min(game.width(),game.height())*.17f;float dx=x-cx,dy=y-cy;if(Math.hypot(dx,dy)<=r){pointerActive=true;pointerX=x;pointerY=y;float ax=Math.max(-1,Math.min(1,dx/r)),ay=Math.max(-1,Math.min(1,-dy/r));float m=(float)Math.hypot(ax,ay);if(m>1){ax/=m;ay/=m;}sendAxes(ax,ay,m>.02f);}return true;}
                stickSelected=Math.hypot(x-cx,y-cy)<hit;selected=-1;downX=x;downY=y;
                if(stickSelected){startX=stickPrefs.getFloat("cx",.16f);startY=stickPrefs.getFloat("cy",.78f);invalidate();return true;}
                for(int i=ids.length-1;i>=0;i--){float bx=nx(hudPrefs.getFloat(ids[i]+"_x",defaults[i][0])),by=ny(hudPrefs.getFloat(ids[i]+"_y",defaults[i][1]));if(Math.hypot(x-bx,y-by)<hit){selected=i;startX=hudPrefs.getFloat(ids[i]+"_x",defaults[i][0]);startY=hudPrefs.getFloat(ids[i]+"_y",defaults[i][1]);invalidate();break;}}return true;
            }
            if(e.getAction()==MotionEvent.ACTION_MOVE){if(testMode&&pointerActive){pointerX=x;pointerY=y;float r=Math.min(game.width(),game.height())*.17f;float ax=(x-cx)/r,ay=(cy-y)/r;float m=(float)Math.hypot(ax,ay);if(m>1){ax/=m;ay/=m;}sendAxes(ax,ay,m>.02f);invalidate();return true;}
                if(stickSelected){stickPrefs.edit().putFloat("cx",clamp(startX+(x-downX)/game.width())).putFloat("cy",clamp(startY+(y-downY)/game.height())).apply();invalidate();return true;}
                if(selected>=0){hudPrefs.edit().putFloat(ids[selected]+"_x",clamp(startX+(x-downX)/game.width())).putFloat(ids[selected]+"_y",clamp(startY+(y-downY)/game.height())).apply();invalidate();return true;}return true;}
            if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){if(testMode&&pointerActive){pointerActive=false;sendAxes(0,0,false);}stickSelected=false;selected=-1;invalidate();return true;}return true;
        }
        void persist(){stickPrefs.edit().putBoolean("calibrated",true).apply();}
    }
}
