package com.haze.mapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Collections;

/** Tracks physical key holds separately from virtual control contacts. */
public final class KeyStateManager {
    private final Map<Integer, Set<Integer>> controlsByKey = new HashMap<>();
    private final Map<Integer, Integer> controlRefCounts = new HashMap<>();

    /** Returns controls that need a native DOWN. Repeats and duplicate DOWNs are ignored. */
    public synchronized List<Integer> press(int keyCode, int[] mappedControls, boolean repeat) {
        if (repeat || controlsByKey.containsKey(keyCode)) return new ArrayList<>();
        Set<Integer> unique = new HashSet<>();
        if (mappedControls != null) {
            for (int id : mappedControls) if (id >= 0 && id < 7) unique.add(id);
        }
        controlsByKey.put(keyCode, unique);
        List<Integer> down = new ArrayList<>();
        for (int id : unique) {
            int refs = controlRefCounts.getOrDefault(id, 0);
            controlRefCounts.put(id, refs + 1);
            if (refs == 0) down.add(id);
        }
        return down;
    }

    /** Returns controls that need a native UP. An unrelated key cannot release them. */
    public synchronized List<Integer> release(int keyCode) {
        Set<Integer> controls = controlsByKey.remove(keyCode);
        if (controls == null) return new ArrayList<>();
        List<Integer> up = new ArrayList<>();
        for (int id : controls) {
            int refs = controlRefCounts.getOrDefault(id, 0);
            if (refs <= 1) {
                controlRefCounts.remove(id);
                if (refs == 1) up.add(id);
            } else {
                controlRefCounts.put(id, refs - 1);
            }
        }
        return up;
    }

    /** Releases every active action contact, without touching the joystick contact. */
    public synchronized List<Integer> releaseAll() {
        List<Integer> up = new ArrayList<>(controlRefCounts.keySet());
        Collections.sort(up);
        controlRefCounts.clear();
        controlsByKey.clear();
        return up;
    }

    public synchronized boolean isControlDown(int controlId) {
        return controlRefCounts.getOrDefault(controlId, 0) > 0;
    }

    public synchronized int activeControlCount() { return controlRefCounts.size(); }
}
