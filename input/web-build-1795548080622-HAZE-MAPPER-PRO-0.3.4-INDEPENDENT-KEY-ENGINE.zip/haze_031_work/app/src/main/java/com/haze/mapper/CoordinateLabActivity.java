package com.haze.mapper;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** On-device measurement tool. It records the actual Activity viewport and touch samples. */
public final class CoordinateLabActivity extends Activity {
    private CoordinateGridView grid;
    private TextView info;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(12, 14, 22));
        TextView title = new TextView(this);
        title.setText("HAZE • COORDINATE LAB 0.3.1   |   TOQUE NOS 5 ALVOS");
        title.setTextColor(Color.WHITE); title.setTextSize(14); title.setPadding(14, 8, 14, 8);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));
        grid = new CoordinateGridView();
        root.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1));
        info = new TextView(this); info.setTextColor(0xFFBCA7FF); info.setTextSize(11);
        info.setPadding(14, 6, 14, 8); info.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(info, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int l, t, r, b;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets safe = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                l=safe.left; t=safe.top; r=safe.right; b=safe.bottom;
            } else {
                l=insets.getSystemWindowInsetLeft(); t=insets.getSystemWindowInsetTop();
                r=insets.getSystemWindowInsetRight(); b=insets.getSystemWindowInsetBottom();
            }
            v.setPadding(l,t,r,b);
            grid.setInsets(0,0,0,0);
            return insets;
        });
        updateInfo();
    }

    private int rotation() {
        Display display = getWindowManager().getDefaultDisplay();
        return display.getRotation();
    }

    private void updateInfo() {
        if (info == null || grid == null) return;
        LandscapeSpace s = grid.space;
        String dimensions = s == null ? "medindo viewport…" : s.width + " × " + s.height;
        info.setText("Viewport: " + dimensions + "  •  Rotação: " + rotation()
                + "  •  Alvos: " + grid.samples.size() + "/5  •  " + grid.lastSample);
    }

    private final class CoordinateGridView extends View {
        private final Paint p = new Paint(3);
        private int insetL, insetT, insetR, insetB;
        private LandscapeSpace space;
        private final List<LandscapeSpace.Point> samples = new ArrayList<>();
        private String lastSample = "aguardando toque";

        CoordinateGridView() { super(CoordinateLabActivity.this); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        void setInsets(int l,int t,int r,int b) { insetL=l;insetT=t;insetR=r;insetB=b; rebuild(); }
        private void rebuild() {
            int w=getWidth()-insetL-insetR, h=getHeight()-insetT-insetB;
            if(w>0 && h>0 && w>=h) space=new LandscapeSpace(insetL,insetT,w,h);
            invalidate(); updateInfo();
        }
        @Override protected void onSizeChanged(int w,int h,int oldw,int oldh) { rebuild(); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            c.drawColor(0xFF111522);
            if(space==null) { drawText(c,"Aguardando viewport landscape…",30,Color.WHITE,getWidth()/2f,getHeight()/2f); return; }
            float l=space.left, t=space.top, r=l+space.width, b=t+space.height;
            p.setColor(0xFF293249);p.setStrokeWidth(1);
            for(int i=1;i<10;i++){float x=l+space.width*i/10f,y=t+space.height*i/10f;c.drawLine(x,t,x,b,p);c.drawLine(l,y,r,y,p);}
            p.setColor(0xFF8C6BFF);p.setStrokeWidth(2);c.drawRect(l,t,r,b,p);
            float[][] targets={{.1f,.1f},{.9f,.1f},{.5f,.5f},{.1f,.9f},{.9f,.9f}};
            for(int i=0;i<targets.length;i++){
                LandscapeSpace.PixelPoint q=space.toScreen(targets[i][0],targets[i][1]);
                p.setColor(i<samples.size()?0xFF55D6A5:0xFFFFC857);p.setStyle(Paint.Style.FILL);c.drawCircle(q.x,q.y,12,p);
                drawText(c,String.valueOf(i+1),14,Color.BLACK,q.x,q.y+5);
            }
            for(int i=0;i<samples.size();i++){
                LandscapeSpace.Point q=samples.get(i);LandscapeSpace.PixelPoint px=space.toScreen(q.x,q.y);
                p.setColor(Color.WHITE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);c.drawCircle(px.x,px.y,18,p);p.setStyle(Paint.Style.FILL);
            }
            drawText(c,"Toque nos alvos 1 → 5. Não é necessário acertar perfeitamente.",16,Color.WHITE,l+18,t+28);
        }
        private void drawText(Canvas c,String text,float size,int color,float x,float y){p.setStyle(Paint.Style.FILL);p.setTextSize(size);p.setColor(color);c.drawText(text,x,y,p);}

        @Override public boolean onTouchEvent(MotionEvent e) {
            if(e.getAction()!=MotionEvent.ACTION_DOWN || space==null)return true;
            float sx=e.getX(), sy=e.getY();
            if(!space.contains(sx,sy))return true;
            LandscapeSpace.Point n=space.normalize(sx,sy);
            if(samples.size()<5)samples.add(n); else samples.set(4,n);
            lastSample=String.format(Locale.US,"X %.4f • Y %.4f",n.x,n.y);
            persist();invalidate();updateInfo();return true;
        }
        private void persist() {
            android.content.SharedPreferences.Editor e=getSharedPreferences("haze_coordinate_space",MODE_PRIVATE).edit();
            e.putInt("left",space.left).putInt("top",space.top).putInt("width",space.width).putInt("height",space.height)
                    .putInt("rotation",rotation()).putFloat("density",getResources().getDisplayMetrics().density)
                    .putInt("sample_count",samples.size());
            for(int i=0;i<samples.size();i++)e.putFloat("sample_"+i+"_x",samples.get(i).x).putFloat("sample_"+i+"_y",samples.get(i).y);
            e.putBoolean("measured",true).apply();
        }
    }
}
