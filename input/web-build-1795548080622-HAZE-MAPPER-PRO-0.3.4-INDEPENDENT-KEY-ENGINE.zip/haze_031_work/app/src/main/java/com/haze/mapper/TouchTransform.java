package com.haze.mapper;

/** Maps normalized screen coordinates to raw ABS_MT axes using an explicit calibration candidate. */
public final class TouchTransform {
    private TouchTransform() {}
    public static final String[] LABELS = {
        "XY • sem inversão", "XY • inverter X", "XY • inverter Y", "XY • inverter X/Y",
        "YX • trocar eixos", "YX • trocar + inverter X", "YX • trocar + inverter Y", "YX • trocar + inverter X/Y"
    };
    public static float[] toRaw(float screenX, float screenY, int mode) {
        float x=clamp(screenX), y=clamp(screenY);
        switch (mode) {
            case 1: return new float[]{1f-x,y}; case 2: return new float[]{x,1f-y};
            case 3: return new float[]{1f-x,1f-y}; case 4: return new float[]{y,x};
            case 5: return new float[]{1f-y,x}; case 6: return new float[]{y,1f-x};
            case 7: return new float[]{1f-y,1f-x}; default: return new float[]{x,y};
        }
    }
    private static float clamp(float v) { return Math.max(0f,Math.min(1f,v)); }
}
