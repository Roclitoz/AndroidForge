package com.haze.mapper;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.MotionEvent;
import android.view.InputDevice;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.widget.FrameLayout;
import android.widget.Button;
import android.widget.TextView;
import android.view.Gravity;
import android.content.pm.ActivityInfo;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Measures the actual uinput -> Android InputReader -> app coordinate path. */
public final class CoordinateCalibrationActivity extends Activity {
    private CalibrationView surface;
    private TextView status;
    private volatile CountDownLatch waiting;
    private volatile float observedX, observedY;
    private volatile int expectedWidth, expectedHeight;
    private volatile boolean running;
    private static final float[][] TARGETS={{.10f,.10f},{.90f,.10f},{.50f,.50f},{.10f,.90f},{.90f,.90f}};

    @Override public void onCreate(Bundle b){super.onCreate(b);setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(0xFF0D111B);surface=new CalibrationView();root.addView(surface,new FrameLayout.LayoutParams(-1,-1));
        status=new TextView(this);status.setTextColor(Color.WHITE);status.setTextSize(13);status.setPadding(18,12,18,12);status.setBackgroundColor(0xCC171D2B);FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(-1,-2,Gravity.TOP);root.addView(status,sp);
        Button run=new Button(this);run.setText("INICIAR CALIBRAÇÃO AUTOMÁTICA • 5 PONTOS");run.setAllCaps(false);FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);bp.bottomMargin=12;root.addView(run,bp);run.setOnClickListener(v->startCalibration(run));
        setContentView(root);status.setText("0.3.3 COORDINATE CALIBRATION • teste de ida e volta pelo Android InputReader");
    }

    @Override public boolean dispatchTouchEvent(MotionEvent e){
        if(e!=null && isHazeTouch(e)){
            if(e.getActionMasked()==MotionEvent.ACTION_DOWN){
                int[] loc=new int[2];surface.getLocationOnScreen(loc);
                observedX=(e.getRawX()-loc[0])/Math.max(1f,surface.getWidth());observedY=(e.getRawY()-loc[1])/Math.max(1f,surface.getHeight());
                CountDownLatch latch=waiting;if(latch!=null)latch.countDown();
            }
            return true;
        }
        return super.dispatchTouchEvent(e);
    }
    private boolean isHazeTouch(MotionEvent e){InputDevice d=InputDevice.getDevice(e.getDeviceId());return d!=null && d.getName()!=null && d.getName().contains("HAZE Virtual Touchscreen") && (e.getSource()&InputDevice.SOURCE_TOUCHSCREEN)==InputDevice.SOURCE_TOUCHSCREEN;}

    private void startCalibration(Button button){if(running)return;running=true;button.setEnabled(false);surface.setProgress(0,"Preparando dispositivo virtual…");
        new Thread(()->{
            List<TouchCalibration.Sample> samples=new ArrayList<>();String error=null;
            try{
                String start=MainActivity.sendSimpleCommand(MapperUserService.TRANSACTION_TOUCH_START);
                if(start==null || !(start.contains("ACTIVE")||start.contains("ALREADY_ACTIVE")))throw new IllegalStateException("Não foi possível iniciar o touchscreen virtual: "+start);
                Thread.sleep(350);
                expectedWidth=surface.getWidth();expectedHeight=surface.getHeight();if(expectedWidth<2||expectedHeight<2)throw new IllegalStateException("Viewport ainda não está pronto.");
                for(int i=0;i<TARGETS.length;i++){
                    final int index=i;runOnUiThread(()->{surface.setProgress(index,"Medindo ponto "+(index+1)+"/5…");status.setText("Medindo ponto "+(index+1)+"/5 • mantenha a tela sem interação física");});
                    float rx=TARGETS[i][0],ry=TARGETS[i][1];int rawX=Math.round(rx*32767f),rawY=Math.round(ry*32767f);
                    CountDownLatch latch=new CountDownLatch(1);waiting=latch;
                    boolean received=false;String down;
                    try{
                        down=MainActivity.sendRawTouchEvent(0,rawX,rawY);
                        if(down==null || !down.contains("TOUCH_EVENT_OK"))throw new IllegalStateException("Falha ao enviar DOWN no ponto "+(i+1)+": "+down);
                        received=latch.await(1500,TimeUnit.MILLISECONDS);
                    }finally{
                        MainActivity.sendRawTouchEvent(2,rawX,rawY);waiting=null;
                    }
                    Thread.sleep(180);
                    if(!received)throw new IllegalStateException("Android não devolveu MotionEvent do touchscreen HAZE no ponto "+(i+1)+". Verifique se o UserService está ativo.");
                    samples.add(new TouchCalibration.Sample(rx,ry,observedX,observedY));
                }
                TouchCalibration.Result result=TouchCalibration.solve(samples);
                if(result.maxError>.025)throw new IllegalStateException(String.format(Locale.US,"Erro residual alto (%.2f%%). Calibração não aplicada; confira orientação/viewport.",result.maxError*100));
                android.content.SharedPreferences.Editor p=getSharedPreferences("haze_touch_calibration",MODE_PRIVATE).edit();
                for(int i=0;i<6;i++)p.putFloat("m"+i,result.matrix[i]);
                p.putBoolean("valid",true).putInt("width",expectedWidth).putInt("height",expectedHeight).putInt("rotation",getWindowManager().getDefaultDisplay().getRotation()).putLong("calibrated_at",System.currentTimeMillis()).putFloat("rms_error",(float)result.rmsError).putFloat("max_error",(float)result.maxError).apply();
                String applied=MainActivity.applyTouchCalibration(result.matrix);
                runOnUiThread(()->{surface.setProgress(5,String.format(Locale.US,"CALIBRAÇÃO APROVADA • erro máximo %.2f%%\n%s",result.maxError*100,applied));status.setText("Matriz de coordenadas calculada e enviada ao motor nativo. O WASD mantém o mesmo vetor/contato.");});
            }catch(Exception ex){error=ex.getMessage();final String msg=error;runOnUiThread(()->{surface.setProgress(samples.size(),"CALIBRAÇÃO NÃO APLICADA\n"+msg);status.setText("Falha segura: a calibração anterior foi preservada.");});}
            finally{waiting=null;running=false;runOnUiThread(()->button.setEnabled(true));}
        },"haze-coordinate-calibration").start();
    }

    private final class CalibrationView extends View{
        private final Paint p=new Paint(3);private int progress;private String message="Toque em iniciar para testar o caminho real do touchscreen virtual.";
        CalibrationView(){super(CoordinateCalibrationActivity.this);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void setProgress(int n,String m){progress=n;message=m;postInvalidate();}
        @Override protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(0xFF0D111B);float[][] t=TARGETS;
            for(int i=0;i<t.length;i++){float x=t[i][0]*getWidth(),y=t[i][1]*getHeight();p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(i<progress?0xFF52D6A5:0xFFFFC857);c.drawCircle(x,y,22,p);c.drawLine(x-32,y,x+32,y,p);c.drawLine(x,y-32,x,y+32,p);p.setStyle(Paint.Style.FILL);p.setTextSize(18);p.setColor(Color.WHITE);c.drawText(String.valueOf(i+1),x+28,y-20,p);}
            p.setColor(0xFFFFFFFF);p.setTextSize(18);String[] lines=message.split("\\n");float ty=getHeight()*.50f;for(String line:lines){c.drawText(line,24,ty,p);ty+=24;}
            p.setColor(0xFFB8C4D9);p.setTextSize(16);c.drawText("Cada alvo injeta um toque e mede onde o Android realmente o entrega.",24,getHeight()-36,p);
        }
    }
}
