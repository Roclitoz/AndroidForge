package com.haze.mapper;

/**
 * Canonical coordinate contract for a landscape game viewport.
 * Coordinates are normalized to [0..1] inside the measured safe viewport.
 * This class deliberately knows nothing about Samsung/uinput axis rotation.
 */
public final class LandscapeSpace {
    public static final class Point {
        public final float x, y;
        Point(float x, float y) { this.x = x; this.y = y; }
    }
    public static final class PixelPoint {
        public final int x, y;
        PixelPoint(int x, int y) { this.x = x; this.y = y; }
    }

    public final int left, top, width, height;

    public LandscapeSpace(int left, int top, int width, int height) {
        if (width <= 0 || height <= 0 || width < height)
            throw new IllegalArgumentException("Viewport must be landscape (width >= height > 0)");
        this.left = left; this.top = top; this.width = width; this.height = height;
    }

    public Point normalize(float screenX, float screenY) {
        return new Point(clamp((screenX - left) / (float) width),
                clamp((screenY - top) / (float) height));
    }

    public PixelPoint toScreen(float normalizedX, float normalizedY) {
        return new PixelPoint(left + Math.round(clamp(normalizedX) * (width - 1)),
                top + Math.round(clamp(normalizedY) * (height - 1)));
    }

    public boolean contains(float screenX, float screenY) {
        return screenX >= left && screenY >= top
                && screenX < left + width && screenY < top + height;
    }

    private static float clamp(float value) {
        return Math.max(0f, Math.min(1f, value));
    }
}
