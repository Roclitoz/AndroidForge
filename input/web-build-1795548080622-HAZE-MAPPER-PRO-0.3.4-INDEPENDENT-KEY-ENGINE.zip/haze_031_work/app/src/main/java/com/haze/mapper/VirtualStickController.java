package com.haze.mapper;

import java.util.Set;

/**
 * Models WASD as ONE virtual thumbstick contact inside a configured joystick area.
 * It never emits one touch per key. The caller keeps one pointer alive while any
 * direction is held and updates that pointer's position as the key set changes.
 * Coordinates are logical stick-space: +X right, +Y up, both in [-1, 1].
 */
public final class VirtualStickController {
    public static final class State {
        /** Whether the single virtual finger should be down. */
        public final boolean fingerDown;
        /** Normalized stick direction, +X right and +Y up. */
        public final float x, y;
        /** Direction strength in [0, 1]. */
        public final float magnitude;
        /** Normalized point inside the joystick circle, [0, 1] on each axis. */
        public final float pointX, pointY;

        private State(boolean down, float x, float y, float magnitude) {
            this.fingerDown = down;
            this.x = x; this.y = y; this.magnitude = magnitude;
            this.pointX = 0.5f + x * 0.5f;
            this.pointY = 0.5f - y * 0.5f;
        }
    }

    private VirtualStickController() {}

    public static State evaluate(Set<Integer> held, int keyW, int keyA, int keyS, int keyD) {
        boolean up = held != null && held.contains(keyW);
        boolean left = held != null && held.contains(keyA);
        boolean down = held != null && held.contains(keyS);
        boolean right = held != null && held.contains(keyD);
        float x = (right ? 1f : 0f) - (left ? 1f : 0f);
        float y = (up ? 1f : 0f) - (down ? 1f : 0f);
        float magnitude = (float)Math.sqrt(x*x + y*y);
        if (magnitude > 1f) { x /= magnitude; y /= magnitude; magnitude = 1f; }
        boolean active = x != 0f || y != 0f;
        return new State(active, x, y, magnitude);
    }
}
