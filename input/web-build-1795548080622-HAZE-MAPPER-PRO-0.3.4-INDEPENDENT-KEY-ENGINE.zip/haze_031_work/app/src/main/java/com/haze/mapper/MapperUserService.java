package com.haze.mapper;

import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.util.Log;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

/** Shizuku UserService Binder. Uses a tiny explicit Binder protocol to avoid AIDL generation issues. */
public final class MapperUserService extends Binder {
    private static final String TAG = "HazeMapperService";
    public static final String DESCRIPTOR = "com.haze.mapper.IMapperService";
    public static final int TRANSACTION_DIAGNOSTIC = IBinder.FIRST_CALL_TRANSACTION;
    public static final int TRANSACTION_LIST_DEVICES = IBinder.FIRST_CALL_TRANSACTION + 1;
    public static final int TRANSACTION_TAP = IBinder.FIRST_CALL_TRANSACTION + 2;
    public static final int TRANSACTION_SWIPE = IBinder.FIRST_CALL_TRANSACTION + 3;
    public static final int TRANSACTION_PROBE_UINPUT = IBinder.FIRST_CALL_TRANSACTION + 4;
    public static final int TRANSACTION_TOUCH_START = IBinder.FIRST_CALL_TRANSACTION + 5;
    public static final int TRANSACTION_TOUCH_EVENT = IBinder.FIRST_CALL_TRANSACTION + 6;
    public static final int TRANSACTION_TOUCH_STOP = IBinder.FIRST_CALL_TRANSACTION + 7;
    public static final int TRANSACTION_JOYSTICK = IBinder.FIRST_CALL_TRANSACTION + 8;
    public static final int TRANSACTION_HUD_TOUCH = IBinder.FIRST_CALL_TRANSACTION + 9;
    public static final int TRANSACTION_SET_CALIBRATION = IBinder.FIRST_CALL_TRANSACTION + 10;
    public static final int TRANSACTION_KEY_TOUCH = IBinder.FIRST_CALL_TRANSACTION + 11;
    private static boolean nativeAvailable = false;
    static { try { System.loadLibrary("hazeinput"); nativeAvailable = true; } catch (Throwable ignored) {} }
    private static native String nativeProbeTouch();
    private static native String nativeStartTouch();
    private static native String nativeTouchEvent(int action, int x, int y);
    private static native String nativeStopTouch();
    private static native String nativeJoystickEvent(float x,float y,boolean active,float cx,float cy,float rx,float ry,int transform);
    private static native String nativeHudTouch(int action,int x,int y,int width,int height,int transform);
    private static native String nativeKeyTouch(int controlId,int action,int x,int y,int width,int height,int transform);
    private static native String nativeSetCalibration(boolean valid,float m0,float m1,float m2,float m3,float m4,float m5);
    // Shizuku UserService reserved destroy transaction (AIDL equivalent: 16777114).
    public static final int TRANSACTION_DESTROY = 16777114;

    public MapperUserService() { attachInterface(null, DESCRIPTOR); }

    private String command(String... args) {
        Process process = null;
        try {
            process = new ProcessBuilder(args).redirectErrorStream(true).start();
            StringBuilder out = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (out.length() < 12000) out.append(line).append('\n');
                }
            }
            if (!process.waitFor(8, TimeUnit.SECONDS)) {
                process.destroyForcibly();
                return "TIMEOUT: " + String.join(" ", args);
            }
            String result = out.toString().trim();
            return result.isEmpty() ? "Comando executado (sem saída). exit=" + process.exitValue() : result;
        } catch (Exception e) {
            Log.e(TAG, "Command failed", e);
            return "ERRO: " + e.getClass().getSimpleName() + ": " + e.getMessage();
        } finally {
            if (process != null) process.destroy();
        }
    }

    private String diagnostic() {
        return "HAZE MAPPER • SHIZUKU USER SERVICE\n" + command("id")
                + "\n\nAndroid:\n" + command("getprop", "ro.build.version.release")
                + "\nAPI:\n" + command("getprop", "ro.build.version.sdk")
                + "\n\nDisplay size:\n" + command("wm", "size")
                + "\nDensity:\n" + command("wm", "density")
                + "\n\nInput devices:\n" + command("getevent", "-lp");
    }

    @Override protected synchronized boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
        if (code == INTERFACE_TRANSACTION) {
            reply.writeString(DESCRIPTOR);
            return true;
        }
        if (code == TRANSACTION_DESTROY) {
            new Thread(() -> { try { Thread.sleep(100); } catch (InterruptedException ignored) {} System.exit(0); }).start();
            return true;
        }
        data.enforceInterface(DESCRIPTOR);
        String result;
        switch (code) {
            case TRANSACTION_DIAGNOSTIC:
                result = diagnostic();
                break;
            case TRANSACTION_LIST_DEVICES:
                result = command("getevent", "-lp");
                break;
            case TRANSACTION_TAP: {
                int x = data.readInt();
                int y = data.readInt();
                if (x < 0 || y < 0) result = "Coordenadas inválidas.";
                else result = command("input", "tap", String.valueOf(x), String.valueOf(y));
                break;
            }
            case TRANSACTION_SWIPE: {
                int x1 = data.readInt(), y1 = data.readInt(), x2 = data.readInt(), y2 = data.readInt();
                int duration = Math.max(1, Math.min(data.readInt(), 5000));
                if (x1 < 0 || y1 < 0 || x2 < 0 || y2 < 0) result = "Coordenadas inválidas.";
                else result = command("input", "swipe", String.valueOf(x1), String.valueOf(y1),
                        String.valueOf(x2), String.valueOf(y2), String.valueOf(duration));
                break;
            }
            case TRANSACTION_PROBE_UINPUT:
                result = "UID: " + command("id") + "\n" + (nativeAvailable
                        ? nativeProbeTouch()
                        : "NATIVE_BACKEND_UNAVAILABLE: biblioteca hazeinput não carregada. Verifique NDK/ABI arm64-v8a.");
                break;
            case TRANSACTION_TOUCH_START:
                result = nativeAvailable ? nativeStartTouch() : "Backend nativo indisponível.";
                break;
            case TRANSACTION_TOUCH_EVENT: {
                int action = data.readInt(), x = data.readInt(), y = data.readInt();
                result = nativeAvailable ? nativeTouchEvent(action, x, y) : "Backend nativo indisponível.";
                break;
            }
            case TRANSACTION_TOUCH_STOP:
                result = nativeAvailable ? nativeStopTouch() : "Backend nativo indisponível.";
                break;
            case TRANSACTION_JOYSTICK: {
                float x = data.readFloat();
                float y = data.readFloat();
                boolean active=data.readInt()!=0; float cx=data.readFloat(),cy=data.readFloat(),rx=data.readFloat(),ry=data.readFloat(); int transform=data.readInt();
                result=nativeAvailable?nativeJoystickEvent(x,y,active,cx,cy,rx,ry,transform):"Backend nativo indisponível.";
                break;
            }
            case TRANSACTION_HUD_TOUCH: {
                int action=data.readInt(),x=data.readInt(),y=data.readInt(),w=data.readInt(),h=data.readInt(),transform=data.readInt();
                result=nativeAvailable?nativeHudTouch(action,x,y,w,h,transform):"Backend nativo indisponível.";
                break;
            }
            case TRANSACTION_KEY_TOUCH: {
                int controlId=data.readInt(),action=data.readInt(),x=data.readInt(),y=data.readInt(),w=data.readInt(),h=data.readInt(),transform=data.readInt();
                result=nativeAvailable?nativeKeyTouch(controlId,action,x,y,w,h,transform):"Backend nativo indisponível.";
                break;
            }
            case TRANSACTION_SET_CALIBRATION: {
                boolean valid=data.readInt()!=0; float m0=data.readFloat(),m1=data.readFloat(),m2=data.readFloat(),m3=data.readFloat(),m4=data.readFloat(),m5=data.readFloat();
                result=nativeAvailable?nativeSetCalibration(valid,m0,m1,m2,m3,m4,m5):"Backend nativo indisponível."; break;
            }
            default:
                return super.onTransact(code, data, reply, flags);
        }
        reply.writeNoException();
        reply.writeString(result);
        return true;
    }
}
