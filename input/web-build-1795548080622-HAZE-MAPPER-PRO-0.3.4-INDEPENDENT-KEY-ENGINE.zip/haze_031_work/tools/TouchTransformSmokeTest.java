import com.haze.mapper.TouchTransform;
public final class TouchTransformSmokeTest {
  static void check(boolean ok,String msg){if(!ok)throw new AssertionError(msg);}
  static void near(float a,float b,String msg){check(Math.abs(a-b)<0.0001f,msg+" expected="+b+" got="+a);}
  public static void main(String[] args){
    float[][] expected={{0,0},{1,0},{0,1},{1,1},{0,0},{1,0},{0,1},{1,1}};
    for(int mode=0;mode<8;mode++){
      float[] p=TouchTransform.toRaw(0,0,mode);near(p[0],expected[mode][0],"corner x mode "+mode);near(p[1],expected[mode][1],"corner y mode "+mode);
      float[] c=TouchTransform.toRaw(.5f,.5f,mode);near(c[0],.5f,"center x mode "+mode);near(c[1],.5f,"center y mode "+mode);
    }
    float[] clamped=TouchTransform.toRaw(-2,4,0);near(clamped[0],0,"clamp x");near(clamped[1],1,"clamp y");
    System.out.println("PASS: 34 transform assertions across 8 orientation candidates");
  }
}
