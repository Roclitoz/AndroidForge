import com.haze.mapper.LandscapeSpace;
public class CoordinateSpaceSmokeTest {
  static void check(boolean ok,String name){if(!ok)throw new AssertionError(name);}
  public static void main(String[] args){
    LandscapeSpace s=new LandscapeSpace(24,12,1920,1080);
    LandscapeSpace.Point center=s.normalize(984,552);
    check(Math.abs(center.x-.5f)<.00001f && Math.abs(center.y-.5f)<.00001f,"center normalization");
    LandscapeSpace.PixelPoint p=s.toScreen(.5f,.5f);
    check(p.x==984 && p.y==552,"center round trip");
    check(s.contains(24,12) && !s.contains(1944,500),"viewport bounds");
    LandscapeSpace.PixelPoint topLeft=s.toScreen(0,0),bottomRight=s.toScreen(1,1);
    check(topLeft.x==24 && topLeft.y==12,"top-left mapping");
    check(bottomRight.x==1943 && bottomRight.y==1091,"bottom-right stays inside viewport");
    boolean rejected=false;try{new LandscapeSpace(0,0,1080,1920);}catch(IllegalArgumentException e){rejected=true;}
    check(rejected,"portrait viewport rejected");
    System.out.println("PASS: 6 coordinate-space assertions");
  }
}
