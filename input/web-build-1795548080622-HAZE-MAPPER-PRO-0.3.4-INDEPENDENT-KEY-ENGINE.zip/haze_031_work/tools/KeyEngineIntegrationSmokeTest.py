from pathlib import Path

root = Path(__file__).resolve().parents[1]
c = (root / "app/src/main/cpp/hazeinput.c").read_text()
service = (root / "app/src/main/java/com/haze/mapper/GlobalKeyCaptureService.java").read_text()
bridge = (root / "app/src/main/java/com/haze/mapper/MapperUserService.java").read_text()
activity = (root / "app/src/main/java/com/haze/mapper/MainActivity.java").read_text()

checks = {
    "touchscreen exposes slots 0..9": "const int maxs[] = {9, 65535, MAX_X, MAX_Y, 255};" in c,
    "analog slot remains 1": "emit(g_fd,EV_ABS,ABS_MT_SLOT,1)" in c,
    "action slots start at 3": "#define KEY_SLOT_BASE 3" in c,
    "FIRE/JUMP/RELOAD have stable IDs": all(x in service for x in ['case "FIRE": return 0;', 'case "JUMP": return 1;', 'case "RELOAD": return 2;']),
    "BTN_TOUCH aggregates independent key contacts": "any |= g_key_down[i]" in c,
    "native key API is connected to Binder": "TRANSACTION_KEY_TOUCH" in bridge and "TRANSACTION_KEY_TOUCH" in activity,
    "global action contacts use the native bridge": "pushGlobalKeyTouch(controlId, action" in service,
    "focus loss releases action contacts": "if (!freeFire) releaseActionContacts();" in service,
    "keyboard removal has a release path": "onInputDeviceRemoved(int deviceId) { releaseDeviceKeys(deviceId); }" in service,
}
for label, passed in checks.items():
    print(("PASS" if passed else "FAIL") + ": " + label)
if not all(checks.values()):
    raise SystemExit(1)
print("KEY_ENGINE_INTEGRATION_STATIC_OK")
