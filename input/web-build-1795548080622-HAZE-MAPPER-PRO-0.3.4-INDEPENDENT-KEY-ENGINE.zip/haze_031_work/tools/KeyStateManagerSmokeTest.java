import com.haze.mapper.KeyStateManager;
import java.util.List;

public final class KeyStateManagerSmokeTest {
    private static void eq(List<Integer> actual, int... expected) {
        if (actual.size() != expected.length) throw new AssertionError(actual + " expected length " + expected.length);
        for (int i = 0; i < expected.length; i++) if (actual.get(i) != expected[i]) throw new AssertionError(actual + " expected index " + i + "=" + expected[i]);
    }
    public static void main(String[] args) {
        KeyStateManager s = new KeyStateManager();
        eq(s.press(33, new int[]{0}, false), 0);       // F down
        eq(s.press(33, new int[]{0}, true));           // key repeat ignored
        eq(s.press(33, new int[]{0}, false));          // duplicate down ignored
        eq(s.press(46, new int[]{2}, false), 2);       // R down while F held
        eq(s.release(33), 0);                          // F up does not release R
        if (!s.isControlDown(2)) throw new AssertionError("R was released with F");
        eq(s.release(46), 2);
        eq(s.press(33, new int[]{0}, false), 0);
        eq(s.press(34, new int[]{0}, false));          // second key also mapped to FIRE
        eq(s.release(33));                             // first key cannot release shared FIRE
        eq(s.release(34), 0);
        eq(s.press(17, new int[]{1, 2}, false), 1, 2); // one key may hold two controls
        eq(s.releaseAll(), 1, 2);
        if (s.activeControlCount() != 0) throw new AssertionError("releaseAll left contacts active");
        eq(s.release(17));
        System.out.println("KEY_STATE_MANAGER_OK: repeat, duplicate, simultaneous, shared mapping and releaseAll");
    }
}
