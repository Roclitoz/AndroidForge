import com.haze.mapper.VirtualStickController;
import com.haze.mapper.LandscapeSpace;
import java.util.*;

public class ArchitectureSmokeTest {
  static void check(boolean v,String label){if(!v)throw new AssertionError(label);}
  public static void main(String[] args){
    final int W=51, A=29, S=47, D=32;
    Set<Integer> keys=new HashSet<>();
    VirtualStickController.State s=VirtualStickController.evaluate(keys,W,A,S,D);
    check(!s.fingerDown,"neutral releases the single contact");
    keys.add(W); s=VirtualStickController.evaluate(keys,W,A,S,D);
    check(s.fingerDown && s.y==1f && s.x==0f,"W moves one stick upward");
    keys.add(D); s=VirtualStickController.evaluate(keys,W,A,S,D);
    check(s.fingerDown && Math.abs(s.x-.7071067f)<.0001f && Math.abs(s.y-.7071067f)<.0001f,"W+D is one normalized diagonal");
    check(s.pointX>.85f && s.pointY<.15f,"diagonal maps inside joystick circle");
    keys.remove(W); s=VirtualStickController.evaluate(keys,W,A,S,D);
    check(s.fingerDown && s.x==1f && s.y==0f,"releasing W keeps same contact active and updates direction");
    keys.clear(); s=VirtualStickController.evaluate(keys,W,A,S,D);
    check(!s.fingerDown,"releasing all keys ends the contact");
    LandscapeSpace space=new LandscapeSpace(20,10,1000,500);
    LandscapeSpace.Point p=space.normalize(520,260);
    check(Math.abs(p.x-.5f)<.0001f && Math.abs(p.y-.5f)<.0001f,"landscape viewport normalization");
    LandscapeSpace.PixelPoint q=space.toScreen(p.x,p.y);
    check(q.x==520 && q.y==260,"landscape coordinate roundtrip");
    boolean rejected=false;try{new LandscapeSpace(0,0,500,1000);}catch(IllegalArgumentException e){rejected=true;}
    check(rejected,"portrait viewport rejected as game reference");
    System.out.println("PASS: 8 virtual-stick and landscape-space assertions");
  }
}
