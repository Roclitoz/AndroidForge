# Haze Mapper Pro 0.3.3 — Coordinate Calibration

## Objetivo
Medir a cadeia real uinput -> Android InputReader -> MotionEvent, em vez de presumir que a coordenada normalizada do app equivale diretamente ao eixo ABS_MT.

## Como funciona
1. A tela entra em landscape imersivo.
2. O app envia cinco contatos em coordenadas brutas conhecidas (10/90% nos cantos internos e 50% no centro).
3. O próprio Android recebe esses contatos como MotionEvent. O app identifica o dispositivo `HAZE Virtual Touchscreen` e registra as coordenadas efetivamente entregues.
4. Um ajuste afim por mínimos quadrados estima a transformação e sua inversa (tela -> raw).
5. A matriz só é aplicada se houver cinco amostras, matriz não singular e erro máximo <= 2.5% do viewport.
6. A matriz é persistida e restaurada quando o Shizuku UserService reconecta.

## Segurança de regressão
- O vetor WASD, centro, raio, slots e tracking IDs do analógico 0.3.2 não são reescritos.
- Sem calibração válida, o backend mantém o caminho legado (transformação selecionada anteriormente).
- A calibração só é aplicada depois de medir os cinco pontos.
- Se a medição falhar, a calibração anterior permanece salva.

## Limitações a validar no A17
- O Android precisa devolver ao app MotionEvent originado pelo dispositivo virtual.
- A janela de calibração precisa estar em fullscreen landscape, sem mudança de rotação durante o ensaio.
- O teste mede o mapeamento de entrada que o Android realmente aplica ao dispositivo virtual; não afirma antecipadamente que todos os jogos usem viewport idêntico.
- Testar os cinco pontos no A17 e depois validar botões/analógico no Free Fire.

## Referências técnicas
- Android Open Source Project — Touch devices: classificação, `touch.orientationAware` e rotação do display: https://source.android.com/docs/core/interaction/input/touch-devices
- Android InputReader — `TouchInputMapper` e transformação raw-to-display/viewport: https://android.googlesource.com/platform/frameworks/native/+/refs/heads/main/services/inputflinger/reader/mapper/TouchInputMapper.cpp
- Linux Kernel — Multi-touch Protocol Type B, slots e ciclo de vida `ABS_MT_TRACKING_ID`: https://www.kernel.org/doc/html/latest/input/multi-touch-protocol.html
