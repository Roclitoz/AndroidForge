# Haze Mapper Pro 0.3.3.1 — HUD Landscape Hotfix

## Objetivo
Corrigir a edição do HUD que abria dentro da tela principal em orientação retrato, comprimindo o preview e dificultando posicionar os controles para uma partida em landscape.

## Alterações
- Criada `HudEditorActivity`, dedicada ao editor e declarada com `screenOrientation="landscape"`.
- A tela principal continua livre para abrir normalmente; somente o editor de HUD abre deitado.
- Preview ocupa a área central disponível em landscape, mantendo as posições normalizadas já salvas.
- Controles W/A/S/D continuam no lado esquerdo; FIRE, JUMP e RELOAD ficam no lado direito; VISTA permanece reposicionável.
- Mantidos arraste, persistência das posições, escala e opacidade globais.
- Adicionado botão REDEFINIR para restaurar posições padrão sem apagar as teclas configuradas.
- Ao salvar ou voltar, o overlay é atualizado se estiver ativo.
- O motor do analógico, JNI, Shizuku, calibração e serviço de captura global não foram alterados.

## Teste necessário no Galaxy A17
1. Instalar a versão compilada.
2. Abrir o Haze Mapper Pro em retrato e tocar em Editar HUD.
3. Confirmar que apenas o editor muda para landscape.
4. Arrastar W/A/S/D para a área esquerda e FIRE/JUMP/RELOAD/VISTA para as posições desejadas.
5. Salvar, reabrir o editor e confirmar persistência.
6. Ativar o overlay e conferir se os controles aparecem nas mesmas posições no Free Fire.
7. Regressão: confirmar WASD no Free Fire antes de qualquer ajuste adicional.

## Limitações
- Esta entrega é código-fonte; APK não foi compilado neste ambiente porque Android SDK/Gradle não estão disponíveis.
- A prévia é uma área de edição proporcional à tela landscape; não é uma captura real do Free Fire.
- A tela de edição inclui os marcadores WASD para posicionamento visual, enquanto os botões de ação flutuantes são FIRE/JUMP/RELOAD/VISTA.
