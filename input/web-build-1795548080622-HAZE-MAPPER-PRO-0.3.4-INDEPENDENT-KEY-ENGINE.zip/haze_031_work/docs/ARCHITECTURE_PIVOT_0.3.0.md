# Haze Mapper Pro 0.3.0 — Architecture Pivot

## Why this pivot exists
The previous implementation treated WASD as a vector calculator attached to a guessed screen transform. That is not a complete keymapper. A mapper needs a control model, a game-space coordinate system, a persistent touch session, an editable overlay, and a game-session lifecycle.

## Control model: one virtual stick
`VirtualStickController` treats W/A/S/D as four inputs to ONE control area. It produces one normalized direction and one `fingerDown` state. The contract is:

- no key held: release the one virtual contact;
- one key held: move that contact along one cardinal direction;
- two adjacent keys: move the same contact diagonally, normalized to unit length;
- a key released while another remains held: keep the contact down and update its position;
- opposite directions cancel on their axis;
- no key maps to an independent touch point.

This class is a pure model. It does not decide where the Free Fire joystick is on screen and does not claim to fix the native coordinate transform.

## Coordinate model: landscape game viewport
`LandscapeSpace` defines normalized coordinates against a measured landscape viewport (left/top/width/height). Portrait viewports are rejected. The editor's portrait Activity is not a valid coordinate reference for the game. The next implementation must measure the actual game display area and its insets/rotation, then pass those values into this class.

## Game launch
The home screen now has launch actions for Free Fire (`com.dts.freefireth`) and Free Fire MAX (`com.dts.freefiremax`). Android package visibility is declared in `<queries>`. Launching a game does not imply that Shizuku, the touch device, accessibility capture, or overlay permissions are active; those states must be surfaced independently.

## What is deliberately NOT claimed as complete
- Native `hazeinput.c` still contains the old inferred Samsung landscape transform. It is not calibrated and must not be treated as fixed.
- The HUD editor is still an in-app preview, not yet a true in-game live editor.
- The current accessibility overlay still has fixed controls and is not a drag/resize/edit-mode overlay.
- Mouse camera capture, cursor mode, click mapping, and Vista are not complete.
- The native multi-touch backend still needs synchronized per-slot lifecycle, error handling, and calibration against the device's actual input coordinate ranges.

## Target architecture

1. **Display/session layer** — detect game package, current display, rotation, viewport and insets; create a landscape coordinate contract.
2. **Profile layer** — persist per-game layouts, controls, key bindings, sizes, opacity, and calibration.
3. **Control graph** — `VirtualStick`, `TapButton`, `HoldButton`, `MouseLook`, and mode-switch controls. Physical inputs update control state; controls own virtual contacts.
4. **Touch session** — one state machine owns each virtual pointer/slot; DOWN/MOVE/UP are serialized and cleaned up on focus loss, disconnect, disable, and service teardown.
5. **Overlay editor** — edit mode supports drag, resize, select, bind, and save over the running game; play mode changes to pass-through visuals and active mappings. Android 12+ obscured-touch restrictions must be tested rather than assumed away.
6. **Game launcher/session** — launch installed game, verify overlay/accessibility/Shizuku prerequisites, restore selected profile, and offer return-to-mapper controls.
7. **Input research** — validate mouse relative motion and camera look separately from keyboard events; never conflate a cursor with camera movement.

## Test status
`ArchitectureSmokeTest` covers the pure virtual-stick and landscape-space contracts. It does not test JNI, `/dev/uinput`, Android overlays, Free Fire, or physical device behavior. Android build and on-device validation remain required.
