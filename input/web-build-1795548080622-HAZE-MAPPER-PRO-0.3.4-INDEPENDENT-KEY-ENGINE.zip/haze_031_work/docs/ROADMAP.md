# Haze Mapper Pro roadmap — RCL Developments

## 0.3.2 — Analog Lab + Editable HUD
- [x] WASD como vetor único e contato virtual persistente.
- [x] Analógico confirmado pelo usuário como funcional no Free Fire, com bugs ocasionais.
- [x] HUD editável básico e calibração candidata.

## 0.3.3 — Coordinate Calibration
- [x] Calibração experimental baseada em cinco pontos e retorno real de MotionEvent do dispositivo uinput.
- [x] Ajuste afim por mínimos quadrados e matriz inversa display->raw.
- [x] Aplicação da matriz ao analógico e aos toques HUD, mantendo caminho legado se não houver calibração válida.
- [ ] Compilar APK e validar ida/volta no Galaxy A17.
- [ ] Confirmar posições no Free Fire e estabilidade do analógico após aplicar a matriz.

## 0.3.4 — Independent Key Engine
- [x] Contatos multitouch independentes para FIRE, JUMP e RELOAD, separados do slot do analógico.
- [x] Ignorar DOWN repetido e liberar somente o controle associado à tecla.
- [x] Referências compartilhadas quando mais de uma tecla está vinculada ao mesmo controle.
- [x] Limpeza de contatos de ação em interrupção, perda de janela do jogo e remoção do dispositivo de entrada.
- [ ] Build Android/NDK e teste real no Galaxy A17.
- [ ] Testar F, F prolongado, F+R e W+D+F+R.
- [ ] Confirmar que soltar uma ação não interrompe o contato WASD.

## 0.3.5 — Vista System
- [ ] Pesquisa/protótipo de captura de mouse relativo e botões sem interromper a câmera do jogo.
- [ ] Máquina de estados câmera <-> cursor com liberação segura.
- [ ] Preservar o WASD e garantir que Vista não deixe contato preso.

## 0.3.6 — Visual HUD Editor
- [ ] Editor landscape com todos os controles e teclas visíveis.
- [ ] Bola virtual do analógico, arrastar, redimensionar, selecionar e vincular teclas.
- [ ] Modos EDITAR/JOGAR, persistência por perfil e interface sem poluição visual.

## 0.4.0 — Integration & Stability
- [ ] Integrar e testar Analog, Key, Vista e HUD Editor.
- [ ] Testes de simultaneidade, foco, desconexão e regressão no Free Fire.

## Gate de release
Cada versão exige build Android, teste no aparelho, teste real no Free Fire, relatório de regressão e hash do ZIP. Testes matemáticos ou sintaxe C não substituem a validação no A17.
