# Haze Mapper Pro 0.3.4 — Independent Key Engine

## Objetivo
Separar os contatos de FIRE, JUMP e RELOAD do contato persistente do analógico WASD. O motor de teclas não pode liberar nem reposicionar o contato do joystick.

## Mapa de slots do touchscreen virtual
| Slot | Dono |
|---:|---|
| 0 | Teste de toque manual da sessão |
| 1 | Analog Engine (WASD) — reservado e preservado |
| 2 | Toque manual do overlay HUD |
| 3 | FIRE (teclado) |
| 4 | JUMP (teclado) |
| 5 | RELOAD (teclado) |
| 6–9 | Reservados para expansão |

O dispositivo uinput declara ABS_MT_SLOT de 0 a 9. A versão atual do Key Engine usa três controles de ação.

## Comportamento
- ACTION_DOWN cria o contato da ação mapeada.
- Repetições e DOWN duplicados são ignorados.
- ACTION_UP libera apenas o controle correspondente à tecla.
- Mais de uma tecla pode compartilhar um controle; o contato só sobe quando todas as teclas que o mantêm pressionado forem liberadas.
- FIRE, JUMP e RELOAD podem permanecer pressionados simultaneamente.
- BTN_TOUCH é agregado e só muda quando o conjunto completo de contatos passa de vazio para não vazio, ou vice-versa.
- O KeyStateManager não escreve no slot 1. O Analog Engine mantém seu cálculo vetorial e seu contato próprios.
- Eventos de ação não reiniciam o heartbeat nem reenviam vetores do joystick.
- Perda da janela do Free Fire libera contatos de ação. Remoção de dispositivo de entrada libera as teclas associadas; se o dispositivo removido também mantinha WASD, o movimento é recalculado pelo caminho do joystick.

## Alterações principais
- `KeyStateManager.java`: controle de teclas pressionadas, referências por ação, proteção contra repetição e liberação geral.
- `GlobalKeyCaptureService.java`: associa FIRE/JUMP/RELOAD às teclas salvas no perfil e encaminha DOWN/UP ao UserService.
- `MainActivity.java` + `MapperUserService.java`: transação Binder dedicada para contatos de ação.
- `hazeinput.c`: slots 3–5 para ações, estado independente por contato e BTN_TOUCH agregado.

## Testes locais executados
- `KeyStateManagerSmokeTest`: passou para DOWN repetido, DOWN duplicado, F+R simultâneos, duas teclas compartilhando FIRE, uma tecla vinculada a dois controles e releaseAll.
- `gcc -D_GNU_SOURCE -std=c11 -fsyntax-only` no `hazeinput.c`: passou sem erros de sintaxe. O arquivo mantém avisos preexistentes de estilo/parâmetros não usados quando compilado com `-Wall -Wextra`.

## Testes ainda obrigatórios no aparelho
1. F sozinho: um contato down e um up.
2. F prolongado: um único contato contínuo, sem novos tracking IDs.
3. F+R: dois slots ativos; soltar F mantém R ativo.
4. W+D+F+R: joystick e dois contatos de ação simultâneos. Soltar F/R não encerra o slot 1.
5. Perda de foco e desconexão do teclado: contatos de ação liberados; verificar separadamente o comportamento WASD.
6. Regressão: analógico WASD continua respondendo como na versão 0.3.2/0.3.3.1.

## Limitações desta entrega
O ambiente desta execução não possui Android SDK/Gradle configurados; não foi possível gerar APK nem executar NDK build. Os testes locais não comprovam que o kernel do Galaxy A17 e o Free Fire aceitam corretamente todos os contatos simultâneos.

## Observação de coordenadas
Os contatos de teclado reutilizam as posições normalizadas `FIRE_x/y`, `JUMP_x/y` e `RELOAD_x/y` já usadas pelo overlay, com a mesma transformação/calibração nativa. A diferença entre a área interna do preview do editor e as métricas da tela inteira já existia na base 0.3.3.1; a correção definitiva da geometria compartilhada permanece no escopo do Visual HUD Editor 0.3.6.
