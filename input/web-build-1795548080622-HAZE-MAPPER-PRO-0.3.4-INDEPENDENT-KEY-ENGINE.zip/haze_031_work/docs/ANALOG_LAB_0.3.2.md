# Haze Mapper Pro 0.3.2 — Analog Lab + Editable HUD

## Objetivo
Transformar o Coordinate Lab em uma etapa prática de edição e diagnóstico do analógico, sem tratar W/A/S/D como quatro toques. As quatro teclas produzem um único vetor e controlam um único contato virtual persistente no slot 1.

## O que entrou
- Nova tela landscape `AnalogLabActivity`, com preview 16:9 lógico/normalizado e controles arrastáveis.
- Centro do analógico editável por arraste; alcance ajustável por controle deslizante.
- FIRE, JUMP, RELOAD e VISTA editáveis no mesmo preview; posições e opacidade reutilizam as preferências do HUD existente.
- Modo PREVIEW simula o vetor WASD visualmente sem injetar toques na própria tela do editor.
- A injeção real só é ativada no botão global, para evitar que o toque virtual seja recebido pelo próprio editor e gere realimentação.
- Botão de ativação global inicia (ou reutiliza) a sessão uinput e habilita a captura global WASD.
- O transform de touchscreen deixou de ser uma rotação Samsung presumida. Há oito candidatos explícitos: XY/YX e inversões.
- A mesma transformação selecionada é usada pelo analógico e pelos botões do HUD.
- O contato do analógico permanece no slot 1 enquanto qualquer direção estiver pressionada; mudar W+D para W move o mesmo contato, e neutralizar envia UP.

## O que foi removido/substituído
- A transformação nativa fixa `rawX=1-cy; rawY=1-cx` foi substituída por `screen_to_raw()` configurável.
- O menu não direciona mais para a calibração antiga baseada em SeekBars independentes; abre o Analog Lab integrado.
- Não se declara que qualquer um dos oito candidatos é correto para o Galaxy A17: o modo correto precisa ser confirmado no dispositivo.

## Como testar no A17
1. Instale a build gerada pelo projeto e abra `Analog Lab`.
2. Em EDITAR HUD, arraste o centro do stick para coincidir com o círculo de movimento do Free Fire. Ajuste o alcance e mova os botões. Salve.
3. Antes de testar dentro do jogo, conecte Shizuku/UserService.
4. Toque em PREVIEW WASD e teste W, A, S, D e combinações. Essa etapa é apenas visual e não injeta eventos.
5. Escolha uma transformação candidata; não existe um modo presumido como correto.
6. Toque em ATIVAR WASD NO FREE FIRE. Isso inicia/reutiliza a sessão virtual e ativa a captura global. Volte ao menu e abra o Free Fire; o toque será enviado ao jogo, não à tela do editor.
7. Teste W → W+D → W → neutro. O personagem deve mudar de direção sem o contato ser recriado.

## Critérios de aceite
- Preview em landscape e posições salvas.
- 8 transformações matematicamente testadas.
- Mesmo transform aplicado ao stick e aos botões do HUD.
- Backend retorna `JOYSTICK_EVENT_OK` durante movimento e `JOYSTICK_RELEASED` ao neutralizar.
- Diagnóstico global exibe a última resposta do backend (`JOYSTICK_EVENT_OK`, `JOYSTICK_RELEASED` ou erro).
- No jogo: direções corretas, sem deslocamento de câmera, sem contato preso, pelo menos 5 minutos de movimento.

## Limitações conhecidas
- O projeto ainda não foi compilado como APK neste ambiente: Android SDK/Gradle não estão disponíveis.
- Os testes locais cobrem matemática e sintaxe C, não a integração real no A17.
- O preview dentro do app testa apenas o vetor; a resposta JNI aparece no diagnóstico global depois da ativação. Só o Free Fire confirma se o jogo interpretou a posição como joystick.
- Os botões do HUD continuam dependentes do overlay de acessibilidade habilitado. Vista ainda não captura movimento global do mouse.
- `hazeinput.c` ainda usa estado global e precisa receber mutex/gerenciador de slots dedicado na etapa seguinte.
