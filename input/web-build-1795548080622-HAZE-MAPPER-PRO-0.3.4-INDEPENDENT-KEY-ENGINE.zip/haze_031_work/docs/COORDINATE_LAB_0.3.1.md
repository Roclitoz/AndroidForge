# Haze Mapper Pro 0.3.1 — Coordinate Lab

## Objetivo
Criar uma referência mensurável de coordenadas landscape antes de recalibrar o analógico ou alterar o backend uinput.

## O que entrou
- `CoordinateLabActivity`, bloqueada em landscape.
- Medição do viewport útil da Activity com insets de barras do sistema e recorte de tela.
- Registro da rotação do display, densidade, origem e dimensões do viewport.
- Grade 10x10 e cinco alvos de toque; amostras normalizadas salvas em `haze_coordinate_space`.
- `LandscapeSpace` com conversão pixel ↔ normalizado, limites e validação landscape.
- `versionCode=31`, `versionName=0.3.1`.

## O que foi deliberadamente excluído desta etapa
- Não aplicar rotação presumida de Samsung no C/uinput.
- Não declarar que coordenadas da Activity são automaticamente idênticas às do Free Fire.
- Não alterar o engine WASD, slots multitouch ou captura do mouse.
- Não usar o antigo centro do joystick como calibração validada.

## Limite técnico importante
O Coordinate Lab mede a área útil da própria Activity em landscape. A sobreposição sobre o Free Fire pode ter uma área útil, política de barras e recortes diferentes. Por isso, o registro é uma primeira referência de display e não uma calibração final do touchscreen virtual. A próxima integração deve comparar a geometria da janela de overlay e a escala/rotação exposta pelo dispositivo virtual antes de enviar toques.

## Teste executado
`CoordinateSpaceSmokeTest`: 6 asserções puras de normalização, round-trip, limites, cantos e rejeição de viewport portrait.

## Testes ainda necessários no Galaxy A17
1. Instalar e abrir Coordinate Lab; confirmar rotação landscape.
2. Confirmar resolução, rotação e contagem de alvos.
3. Tocar nos cinco alvos e confirmar 5/5 e persistência após fechar/abrir.
4. Enviar screenshot do Lab e os valores exibidos.
5. Ainda não ativar WASD→uinput para inferir correção do analógico com base apenas nesta tela.

## Estado de build
Fonte atualizada. Este ambiente não possui Android SDK/Gradle configurado para validar `assembleDebug`; portanto, APK não foi produzido nem testado aqui.
