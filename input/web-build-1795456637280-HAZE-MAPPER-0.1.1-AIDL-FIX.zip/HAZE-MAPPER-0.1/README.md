# HAZE MAPPER 0.1 — Input Engine Prototype

This is a deliberately plain Android prototype focused on proving the Shizuku bridge and input diagnostics before building a game HUD editor.

## Included
- Shizuku permission check and authorization request.
- Shizuku UserService (ADB/shell identity) through AIDL.
- `id`, `wm size`, `wm density`, and `getevent -lp` diagnostics.
- Input-device listing attempt.
- Explicit test injection using Android shell `input tap` and `input swipe`.
- Foreground-only mouse and keyboard event display while this app is focused.
- A small mapping core with normalized key-to-screen bindings.

## Important limits
- This is NOT yet a complete background/game mapper.
- `getevent -lp` can return permission denied on some Android builds. Shizuku does not automatically grant access to `/dev/input` or `/dev/uinput`.
- `input tap/swipe` are discrete shell commands, not a persistent virtual mouse. They do not provide low-latency continuous camera control.
- The current key/mouse listener only sees events delivered to HAZE MAPPER while it is in the foreground. Android does not let an ordinary app globally intercept all keys/mouse events just because Shizuku is running.
- No anti-cheat bypass, game memory access, or game-file modification is included.

## Build
- Android Gradle Plugin 8.7.3
- Gradle 8.9 (system Gradle supported)
- JDK 17
- compileSdk 35 / minSdk 26
- Shizuku API 13.1.5

Open the project in Android Studio or upload the ZIP to AndroidForge. Build `:app:assembleDebug`.

## Test sequence on device
1. Install and start Shizuku using Wireless debugging.
2. Open HAZE MAPPER and grant its Shizuku permission.
3. Start UserService.
4. Run diagnostics and save the complete log.
5. Run the input-device listing test.
6. Connect a physical mouse and keyboard, focus this app, and test local event display.
7. Only run tap/swipe injection when you are on a safe test screen; the test sends a real system input event at screen coordinates.

## Next engineering gate
Do not implement Free Fire HUD overlay or claim compatibility until the Galaxy A17 test establishes whether the shell identity can read the required input nodes and whether a supported virtual input backend is available. ADB UID 2000 and its permissions vary by Android version/vendor.


## Build fix 0.1.1
Enabled Android AIDL generation (`buildFeatures.aidl = true`) so `IMapperService.aidl` generates the Binder interface used by MainActivity and MapperUserService. This addresses the missing `IMapperService` and cascading override errors reported by AndroidForge.
