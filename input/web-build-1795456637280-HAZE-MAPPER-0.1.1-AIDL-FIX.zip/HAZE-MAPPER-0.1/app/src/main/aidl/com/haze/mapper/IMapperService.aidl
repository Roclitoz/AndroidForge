package com.haze.mapper;
interface IMapperService {
    String runDiagnostic();
    String listInputDevices();
    String injectTap(int x, int y);
    String injectSwipe(int x1, int y1, int x2, int y2, int durationMs);
    void destroy();
}
