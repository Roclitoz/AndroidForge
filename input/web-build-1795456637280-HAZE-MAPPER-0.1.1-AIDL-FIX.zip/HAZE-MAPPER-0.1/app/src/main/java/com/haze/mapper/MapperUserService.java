package com.haze.mapper;

import android.os.RemoteException;
import android.util.Log;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

/** Runs as Shizuku's authorized shell/root identity. */
public final class MapperUserService extends IMapperService.Stub {
    private static final String TAG = "HazeMapperService";

    private String command(String... args) {
        Process process = null;
        try {
            process = new ProcessBuilder(args).redirectErrorStream(true).start();
            StringBuilder out = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (out.length() < 12000) out.append(line).append('\n');
                }
            }
            if (!process.waitFor(5, TimeUnit.SECONDS)) {
                process.destroyForcibly();
                return "TIMEOUT: " + String.join(" ", args);
            }
            String result = out.toString().trim();
            return result.isEmpty() ? "Comando executado (sem saída)." : result;
        } catch (Exception e) {
            Log.e(TAG, "Command failed", e);
            return "ERRO: " + e.getClass().getSimpleName() + ": " + e.getMessage();
        } finally {
            if (process != null) process.destroy();
        }
    }

    @Override public String runDiagnostic() throws RemoteException {
        return "UID / contexto:\n" + command("id") +
               "\n\nAndroid / tela:\n" + command("wm", "size") + "\n" + command("wm", "density") +
               "\n\nInput devices (getevent):\n" + command("getevent", "-lp");
    }

    @Override public String listInputDevices() throws RemoteException {
        return command("getevent", "-lp");
    }

    @Override public String injectTap(int x, int y) throws RemoteException {
        if (x < 0 || y < 0) return "Coordenadas inválidas.";
        return command("input", "tap", String.valueOf(x), String.valueOf(y));
    }

    @Override public String injectSwipe(int x1, int y1, int x2, int y2, int durationMs) throws RemoteException {
        if (x1 < 0 || y1 < 0 || x2 < 0 || y2 < 0) return "Coordenadas inválidas.";
        int duration = Math.max(1, Math.min(durationMs, 5000));
        return command("input", "swipe", String.valueOf(x1), String.valueOf(y1),
                String.valueOf(x2), String.valueOf(y2), String.valueOf(duration));
    }

    @Override public void destroy() throws RemoteException { System.exit(0); }
}
