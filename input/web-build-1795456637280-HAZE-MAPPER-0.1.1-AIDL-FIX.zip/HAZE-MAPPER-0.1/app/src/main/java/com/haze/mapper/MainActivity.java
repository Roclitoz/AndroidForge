package com.haze.mapper;

import android.app.Activity;
import android.os.Bundle;
import android.os.IBinder;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private TextView status, output, liveInput;
    private IMapperService remote;
    private final MappingEngine engine = new MappingEngine();
    private final int requestCode = 4201;

    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder binder) {
            remote = IMapperService.Stub.asInterface(binder);
            status.setText("UserService conectado • UID " + safeUid());
            status.setTextColor(Color.rgb(100, 220, 140));
        }
        @Override public void onServiceDisconnected(ComponentName name) {
            remote = null;
            status.setText("UserService desconectado");
            status.setTextColor(Color.RED);
        }
    };

    private final Shizuku.OnRequestPermissionResultListener permissionListener = (code, result) -> {
        if (code == requestCode && result == android.content.pm.PackageManager.PERMISSION_GRANTED) startUserService();
        else status.setText("Permissão Shizuku negada");
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        Shizuku.addRequestPermissionResultListener(permissionListener);
        buildUi();
        refreshShizuku();
    }

    private int safeUid() { try { return Shizuku.getUid(); } catch (Throwable t) { return -1; } }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 28); root.setBackgroundColor(Color.rgb(16,16,24));
        scroll.addView(root);
        TextView title = text("HAZE MAPPER 0.1", 26, Color.WHITE); root.addView(title);
        root.addView(text("INPUT ENGINE • BUILD DE TESTE", 12, 0xFFB58AFF));
        status = text("Verificando Shizuku…", 15, Color.YELLOW); addGap(root); root.addView(status);
        addButton(root, "1. Verificar / solicitar Shizuku", this::refreshShizuku);
        addButton(root, "2. Iniciar UserService", this::startUserService);
        addButton(root, "3. Diagnóstico ADB + dispositivos", () -> callRemote(0));
        addButton(root, "4. Listar dispositivos de entrada", () -> callRemote(1));
        addButton(root, "5. Testar toque no centro da tela", () -> {
            int x = getResources().getDisplayMetrics().widthPixels / 2;
            int y = getResources().getDisplayMetrics().heightPixels / 2;
            callRemote(2, x, y);
        });
        addButton(root, "6. Testar swipe horizontal", () -> {
            int x = getResources().getDisplayMetrics().widthPixels;
            int y = getResources().getDisplayMetrics().heightPixels / 2;
            callRemote(3, x/4, y, x*3/4, y, 350);
        });
        addGap(root); root.addView(text("CAPTURA LOCAL (com esta tela aberta)", 16, Color.WHITE));
        liveInput = text("Mova o mouse ou pressione uma tecla…", 14, Color.LTGRAY); root.addView(liveInput);
        addGap(root); root.addView(text("LOG", 16, Color.WHITE));
        output = text("Aguardando teste.", 12, 0xFFD0D0D0); root.addView(output);
        setContentView(scroll);
    }

    private TextView text(String value, int size, int color) {
        TextView v = new TextView(this); v.setText(value); v.setTextSize(size); v.setTextColor(color); v.setPadding(0,8,0,8); return v;
    }
    private void addGap(LinearLayout root) { View gap = new View(this); root.addView(gap, new LinearLayout.LayoutParams(1,12)); }
    private void addButton(LinearLayout root, String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0,6,0,6); root.addView(b,p);
    }

    private void refreshShizuku() {
        if (!Shizuku.pingBinder()) { status.setText("Shizuku não está iniciado. Abra o Shizuku e inicie pelo modo depuração sem fio."); return; }
        if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            status.setText("Shizuku encontrado; autorização necessária.");
            Shizuku.requestPermission(requestCode);
        } else { status.setText("Shizuku autorizado • UID " + safeUid()); }
    }

    private void startUserService() {
        if (!Shizuku.pingBinder()) { refreshShizuku(); return; }
        if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) { refreshShizuku(); return; }
        try {
            Shizuku.UserServiceArgs args = new Shizuku.UserServiceArgs(new ComponentName(getPackageName(), MapperUserService.class.getName()))
                    .daemon(false).tag("haze-mapper-engine").version(1);
            Shizuku.bindUserService(args, connection);
            status.setText("Solicitando inicialização do UserService…");
        } catch (Throwable t) { log("Falha ao iniciar UserService: " + t); }
    }

    private void callRemote(int action, int... values) {
        if (remote == null) { log("UserService não conectado. Inicie-o primeiro."); return; }
        new Thread(() -> {
            String result;
            try {
                if (action == 0) result = remote.runDiagnostic();
                else if (action == 1) result = remote.listInputDevices();
                else if (action == 2) result = remote.injectTap(values[0], values[1]);
                else result = remote.injectSwipe(values[0], values[1], values[2], values[3], values[4]);
            } catch (Throwable t) { result = "ERRO IPC: " + t; }
            final String out = result;
            runOnUiThread(() -> log(out));
        }).start();
    }

    private void log(String value) { output.setText(value); }

    @Override public boolean dispatchGenericMotionEvent(MotionEvent event) {
        if ((event.getSource() & InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE) {
            liveInput.setText("MOUSE • x=" + event.getX() + " y=" + event.getY() + " • action=" + event.getAction());
        }
        return super.dispatchGenericMotionEvent(event);
    }
    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        liveInput.setText("TECLADO • " + KeyEvent.keyCodeToString(event.getKeyCode()) + " • " + (event.getAction()==KeyEvent.ACTION_DOWN?"DOWN":"UP"));
        return super.dispatchKeyEvent(event);
    }

    @Override protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        try {
            Shizuku.UserServiceArgs args = new Shizuku.UserServiceArgs(new ComponentName(getPackageName(), MapperUserService.class.getName()))
                    .daemon(false).tag("haze-mapper-engine").version(1);
            Shizuku.unbindUserService(args, connection, true);
        } catch (Throwable ignored) {}
        super.onDestroy();
    }
}
