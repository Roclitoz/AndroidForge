package com.haze.mapper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import android.os.Handler;
import android.os.Looper;
import android.graphics.PixelFormat;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.MotionEvent;
import android.view.View;
import android.util.DisplayMetrics;
import java.util.HashSet;
import java.util.Set;

/** Global physical-key observer and normalized control-state calculator.
 * Events are deliberately not consumed: the foreground game keeps receiving them.
 */
public final class GlobalKeyCaptureService extends AccessibilityService {
    private static final String PREFS = "haze_global_input";
    private static final String PROFILE = "haze_profile";
    private final Set<Integer> held = new HashSet<>();
    private static volatile GlobalKeyCaptureService instance;
    private final Handler heartbeat = new Handler(Looper.getMainLooper());
    private final Runnable heartbeatTask = new Runnable() { @Override public void run() {
        android.content.SharedPreferences p=getSharedPreferences(PREFS,MODE_PRIVATE);
        if(p.getBoolean("joystick_enabled",false) && !p.getBoolean("vista_mode",false)) {
            float x=p.getFloat("global_x",0f), y=p.getFloat("global_y",0f);
            if(x!=0f || y!=0f) {
                android.content.SharedPreferences c=getSharedPreferences("haze_joystick",MODE_PRIVATE);
                MainActivity.pushGlobalJoystick(x,y,true,c.getFloat("cx",.175f),c.getFloat("cy",.105f),c.getFloat("rx",.055f),c.getFloat("ry",.085f));
                heartbeat.postDelayed(this,45);
            }
        }
    }};
    private WindowManager windowManager;
    private final java.util.Map<String,View> hudViews = new java.util.HashMap<>();

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        instance=this;
        AccessibilityServiceInfo info = getServiceInfo();
        if (info != null) {
            info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
            setServiceInfo(info);
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("service_connected", true)
                .putLong("connected_at", System.currentTimeMillis())
                .putFloat("global_x", 0f).putFloat("global_y", 0f)
                .putString("held_keys", "").apply();
        held.clear();
        if(getSharedPreferences("haze_hud",MODE_PRIVATE).getBoolean("overlay_enabled",false)) showHudOverlay();
    }

    public static void setHudOverlayEnabled(boolean enabled) {
        GlobalKeyCaptureService s=instance;
        if(s==null)return;
        s.getSharedPreferences("haze_hud",MODE_PRIVATE).edit().putBoolean("overlay_enabled",enabled).apply();
        if(enabled)s.showHudOverlay();else s.hideHudOverlay();
    }
    public static void refreshHudOverlay() {
        GlobalKeyCaptureService s=instance;
        if(s!=null && s.getSharedPreferences("haze_hud",MODE_PRIVATE).getBoolean("overlay_enabled",false)) {
            s.hideHudOverlay(); s.showHudOverlay();
        }
    }

    private void showHudOverlay() {
        if(windowManager==null)windowManager=(WindowManager)getSystemService(WINDOW_SERVICE);
        if(windowManager==null || !hudViews.isEmpty())return;
        String[] ids={"FIRE","JUMP","RELOAD","VISTA"};
        int[] defaultsX={86,75,88,50}, defaultsY={76,62,48,90};
        DisplayMetrics dm=new DisplayMetrics();windowManager.getDefaultDisplay().getRealMetrics(dm);
        android.content.SharedPreferences p=getSharedPreferences("haze_hud",MODE_PRIVATE);
        float scale=p.getFloat("global_scale",1f), opacity=p.getFloat("global_opacity",.85f);
        for(int i=0;i<ids.length;i++){
            final String id=ids[i];
            float xr=p.getFloat(id+"_x",defaultsX[i]/100f), yr=p.getFloat(id+"_y",defaultsY[i]/100f);
            int size=Math.max(44,Math.round(74*scale));
            TextView v=new TextView(this);v.setText(id);v.setTextColor(Color.WHITE);v.setTextSize(11);v.setGravity(Gravity.CENTER);
            GradientDrawable bg=new GradientDrawable();bg.setShape(GradientDrawable.OVAL);bg.setColor(0xCC252B3A);bg.setStroke(2,0xFFB69AFF);v.setBackground(bg);v.setAlpha(opacity);
            WindowManager.LayoutParams lp=new WindowManager.LayoutParams(size,size,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
            lp.gravity=Gravity.TOP|Gravity.LEFT;lp.x=Math.max(0,Math.min(dm.widthPixels-size,Math.round(xr*dm.widthPixels-size/2f)));lp.y=Math.max(0,Math.min(dm.heightPixels-size,Math.round(yr*dm.heightPixels-size/2f)));
            v.setOnTouchListener((view,event)->{
                int sx=Math.round(lp.x+size/2f), sy=Math.round(lp.y+size/2f);
                if(event.getAction()==MotionEvent.ACTION_DOWN){
                    if("VISTA".equals(id))return true;
                    MainActivity.pushHudTouch(0,sx,sy,dm.widthPixels,dm.heightPixels);return true;
                }
                if(event.getAction()==MotionEvent.ACTION_UP||event.getAction()==MotionEvent.ACTION_CANCEL){
                    if("VISTA".equals(id)){toggleVistaMode();return true;}
                    MainActivity.pushHudTouch(1,sx,sy,dm.widthPixels,dm.heightPixels);return true;
                }
                return true;
            });
            try{windowManager.addView(v,lp);hudViews.put(id,v);}catch(Throwable ignored){}
        }
    }

    private void hideHudOverlay(){
        if(windowManager!=null)for(View v:new java.util.ArrayList<>(hudViews.values()))try{windowManager.removeView(v);}catch(Throwable ignored){}
        hudViews.clear();
    }

    private void toggleVistaMode() {
        android.content.SharedPreferences state=getSharedPreferences(PREFS,MODE_PRIVATE);
        boolean next=!state.getBoolean("vista_mode",false);
        state.edit().putBoolean("vista_mode",next).apply();
        if(next){heartbeat.removeCallbacks(heartbeatTask);MainActivity.pushGlobalJoystick(0f,0f,false);}
        else {
            int w=getSharedPreferences(PROFILE,MODE_PRIVATE).getInt("key_W",KeyEvent.KEYCODE_W);
            int a=getSharedPreferences(PROFILE,MODE_PRIVATE).getInt("key_A",KeyEvent.KEYCODE_A);
            int s=getSharedPreferences(PROFILE,MODE_PRIVATE).getInt("key_S",KeyEvent.KEYCODE_S);
            int d=getSharedPreferences(PROFILE,MODE_PRIVATE).getInt("key_D",KeyEvent.KEYCODE_D);
            float x=(held.contains(d)?1f:0f)-(held.contains(a)?1f:0f);
            float y=(held.contains(w)?1f:0f)-(held.contains(s)?1f:0f);
            float len=(float)Math.hypot(x,y);if(len>1f){x/=len;y/=len;}
            android.content.SharedPreferences c=getSharedPreferences("haze_joystick",MODE_PRIVATE);
            MainActivity.pushGlobalJoystick(x,y,x!=0f||y!=0f,c.getFloat("cx",.175f),c.getFloat("cy",.105f),c.getFloat("rx",.055f),c.getFloat("ry",.085f));
            if(x!=0f||y!=0f)heartbeat.postDelayed(heartbeatTask,45);
        }
    }

    @Override protected boolean onKeyEvent(KeyEvent event) {
        if (event == null || (event.getAction() != KeyEvent.ACTION_DOWN && event.getAction() != KeyEvent.ACTION_UP)) return false;
        final int code = event.getKeyCode();
        final boolean down = event.getAction() == KeyEvent.ACTION_DOWN;
        boolean newlyPressed = false;
        if (down) newlyPressed = held.add(code); else held.remove(code);

        android.content.SharedPreferences profile = getSharedPreferences(PROFILE, MODE_PRIVATE);
        int w = profile.getInt("key_W", KeyEvent.KEYCODE_W);
        int a = profile.getInt("key_A", KeyEvent.KEYCODE_A);
        int s = profile.getInt("key_S", KeyEvent.KEYCODE_S);
        int d = profile.getInt("key_D", KeyEvent.KEYCODE_D);
        int vista = profile.getInt("vista_key", KeyEvent.KEYCODE_F1);

        android.content.SharedPreferences state = getSharedPreferences(PREFS, MODE_PRIVATE);
        android.content.SharedPreferences.Editor edit = state.edit();
        if (down && newlyPressed && code == vista) {
            edit.putBoolean("vista_mode", !state.getBoolean("vista_mode", false));
        }

        float x = (held.contains(d) ? 1f : 0f) - (held.contains(a) ? 1f : 0f);
        float y = (held.contains(w) ? 1f : 0f) - (held.contains(s) ? 1f : 0f);
        float len = (float)Math.hypot(x, y);
        if (len > 1f) { x /= len; y /= len; }

        boolean vistaMode = state.getBoolean("vista_mode", false) ^ (down && newlyPressed && code == vista);
        // Vista/cursor mode suspends the movement finger. Camera mode maps WASD to it.
        boolean joystickEnabled = state.getBoolean("joystick_enabled", false);
        if (joystickEnabled) {
            android.content.SharedPreferences cal=getSharedPreferences("haze_joystick",MODE_PRIVATE);
            float cx=cal.getFloat("cx",.175f), cy=cal.getFloat("cy",.105f);
            float rx=cal.getFloat("rx",.055f), ry=cal.getFloat("ry",.085f);
            MainActivity.pushGlobalJoystick(x,y,!vistaMode && (x!=0f || y!=0f),cx,cy,rx,ry);
            heartbeat.removeCallbacks(heartbeatTask);
            if(!vistaMode && (x!=0f || y!=0f)) heartbeat.postDelayed(heartbeatTask,45);
        }

        StringBuilder keys = new StringBuilder();
        for (Integer key : held) {
            if (keys.length() > 0) keys.append(',');
            keys.append(KeyEvent.keyCodeToString(key));
        }
        int count = state.getInt("event_count", 0) + 1;
        edit.putInt("last_keycode", code)
                .putInt("last_action", event.getAction())
                .putInt("last_device", event.getDeviceId())
                .putInt("event_count", count)
                .putLong("last_event_at", System.currentTimeMillis())
                .putFloat("global_x", x).putFloat("global_y", y)
                .putString("held_keys", keys.toString())
                .putBoolean("movement_active", x != 0f || y != 0f)
                .apply();
        // Observation/calculation only. Do not swallow the physical event.
        return false;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { clearHeldState(); }

    private void clearHeldState() {
        held.clear();
        heartbeat.removeCallbacks(heartbeatTask);
        MainActivity.pushGlobalJoystick(0f, 0f, false);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putFloat("global_x", 0f).putFloat("global_y", 0f)
                .putBoolean("movement_active", false).putString("held_keys", "").apply();
    }

    @Override public void onDestroy() {
        clearHeldState(); hideHudOverlay(); instance=null; super.onDestroy();
    }

    @Override public boolean onUnbind(android.content.Intent intent) {
        clearHeldState(); hideHudOverlay(); instance=null;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("service_connected", false).apply();
        return super.onUnbind(intent);
    }
}
