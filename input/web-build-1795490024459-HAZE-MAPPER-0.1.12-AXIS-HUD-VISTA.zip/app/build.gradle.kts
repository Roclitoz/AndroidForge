plugins { id("com.android.application") }

android {
    namespace = "com.haze.mapper"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.haze.mapper"
        minSdk = 26
        targetSdk = 35
        versionCode = 13
        versionName = "0.1.12"
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    externalNativeBuild {
        cmake { path = file("src/main/cpp/CMakeLists.txt") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
