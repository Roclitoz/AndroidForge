package com.haze.mapper;

import android.content.SharedPreferences;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;

/** Maps the editor preview point through the editor's display geometry into the current display orientation. */
public final class HudCoordinateMapper {
    private HudCoordinateMapper() {}

    public static int[] toScreen(SharedPreferences hud, WindowManager wm, float nx, float ny) {
        DisplayMetrics dm = new DisplayMetrics();
        Display display = wm == null ? null : wm.getDefaultDisplay();
        if (display != null) display.getRealMetrics(dm);
        int screenW = Math.max(1, dm.widthPixels);
        int screenH = Math.max(1, dm.heightPixels);

        float sx = clamp(nx);
        float sy = clamp(ny);
        boolean valid = hud.getBoolean("editor_geometry_valid", false);
        int left = hud.getInt("editor_left", 0);
        int top = hud.getInt("editor_top", 0);
        int width = hud.getInt("editor_width", 0);
        int height = hud.getInt("editor_height", 0);
        int editorScreenW = hud.getInt("editor_screen_width", 0);
        int editorScreenH = hud.getInt("editor_screen_height", 0);

        if (valid && width > 0 && height > 0 && editorScreenW > 0 && editorScreenH > 0) {
            // First convert the preview-local normalized point into the full editor-display space.
            sx = clamp((left + sx * width) / (float) editorScreenW);
            sy = clamp((top + sy * height) / (float) editorScreenH);
            int savedRotation = hud.getInt("editor_rotation", display == null ? 0 : display.getRotation());
            int currentRotation = display == null ? savedRotation : display.getRotation();
            float[] rotated = rotateBetweenDisplayOrientations(sx, sy, savedRotation, currentRotation);
            sx = rotated[0];
            sy = rotated[1];
        }

        int x = Math.round(sx * (screenW - 1));
        int y = Math.round(sy * (screenH - 1));
        return new int[]{clamp(x, 0, screenW - 1), clamp(y, 0, screenH - 1), screenW, screenH};
    }

    /** Rotation_90 is a clockwise quarter-turn relative to Rotation_0. */
    static float[] rotateBetweenDisplayOrientations(float x, float y, int from, int to) {
        int delta = ((to - from) % 4 + 4) % 4;
        switch (delta) {
            case 1: return new float[]{1f - y, x};
            case 2: return new float[]{1f - x, 1f - y};
            case 3: return new float[]{y, 1f - x};
            default: return new float[]{x, y};
        }
    }

    private static float clamp(float v) { return Math.max(0f, Math.min(1f, v)); }
    private static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
}
